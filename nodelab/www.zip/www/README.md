Assets
======

Put static files that do not need to be compiled or manipulated here as as the **contents** of this directory will be copied verbatim to the /public folder.
