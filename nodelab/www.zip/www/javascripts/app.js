(function() {
  'use strict';

  var globals = typeof window === 'undefined' ? global : window;
  if (typeof globals.require === 'function') return;

  var modules = {};
  var cache = {};
  var has = ({}).hasOwnProperty;

  var aliases = {};

  var endsWith = function(str, suffix) {
    return str.indexOf(suffix, str.length - suffix.length) !== -1;
  };

  var unalias = function(alias, loaderPath) {
    var start = 0;
    if (loaderPath) {
      if (loaderPath.indexOf('components/' === 0)) {
        start = 'components/'.length;
      }
      if (loaderPath.indexOf('/', start) > 0) {
        loaderPath = loaderPath.substring(start, loaderPath.indexOf('/', start));
      }
    }
    var result = aliases[alias + '/index.js'] || aliases[loaderPath + '/deps/' + alias + '/index.js'];
    if (result) {
      return 'components/' + result.substring(0, result.length - '.js'.length);
    }
    return alias;
  };

  var expand = (function() {
    var reg = /^\.\.?(\/|$)/;
    return function(root, name) {
      var results = [], parts, part;
      parts = (reg.test(name) ? root + '/' + name : name).split('/');
      for (var i = 0, length = parts.length; i < length; i++) {
        part = parts[i];
        if (part === '..') {
          results.pop();
        } else if (part !== '.' && part !== '') {
          results.push(part);
        }
      }
      return results.join('/');
    };
  })();
  var dirname = function(path) {
    return path.split('/').slice(0, -1).join('/');
  };

  var localRequire = function(path) {
    return function(name) {
      var absolute = expand(dirname(path), name);
      return globals.require(absolute, path);
    };
  };

  var initModule = function(name, definition) {
    var module = {id: name, exports: {}};
    cache[name] = module;
    definition(module.exports, localRequire(name), module);
    return module.exports;
  };

  var require = function(name, loaderPath) {
    var path = expand(name, '.');
    if (loaderPath == null) loaderPath = '/';
    path = unalias(name, loaderPath);

    if (has.call(cache, path)) return cache[path].exports;
    if (has.call(modules, path)) return initModule(path, modules[path]);

    var dirIndex = expand(path, './index');
    if (has.call(cache, dirIndex)) return cache[dirIndex].exports;
    if (has.call(modules, dirIndex)) return initModule(dirIndex, modules[dirIndex]);

    throw new Error('Cannot find module "' + name + '" from '+ '"' + loaderPath + '"');
  };

  require.alias = function(from, to) {
    aliases[to] = from;
  };

  require.register = require.define = function(bundle, fn) {
    if (typeof bundle === 'object') {
      for (var key in bundle) {
        if (has.call(bundle, key)) {
          modules[key] = bundle[key];
        }
      }
    } else {
      modules[bundle] = fn;
    }
  };

  require.list = function() {
    var result = [];
    for (var item in modules) {
      if (has.call(modules, item)) {
        result.push(item);
      }
    }
    return result;
  };

  require.brunch = true;
  globals.require = require;
})();
require.register("brunch", function(exports, require, module) {
module.exports = {"git_commit":"112d52360a6693a64f5844c154b7733f361620d9-local","env":"development","date":"2015-09-28T13:00:03.755Z"};
});

require.register("config.debug", function(exports, require, module) {
module.exports = {
  logging: true
};
});

require.register("config.release", function(exports, require, module) {
module.exports = {
  logging:         false,
  backgroundColor: 0x1a1a1a,
  fontSize:        0.45,
  nodeSearcher: {
    scrollAnimationTime: 100,
    scrollbarOptions: {
      alwaysExpandScrollbar: true,
      alwaysShowScrollbar: 2,
      updateOnSelectorChange: "ul li",
      updateOnContentResize: true
    }
  }
};

});

require.register("features.debug", function(exports, require, module) {
"use strict;";

module.exports = {
};

});

require.register("features.release", function(exports, require, module) {
"use strict";

module.exports = {
// names reserverd for helper functions
  enable:        undefined,
  disable:       undefined,
  clear:         undefined,
// features
  node_labels:   false,
  label_editor:  false,
  node_searcher: true,
  widget_sandbox: false
};

});

require.register("app", function(exports, require, module) {
"use strict";

var $$             = require('common'),
    config         = require('config'),
    features       = require('features'),
    brunch         = require('brunch'),
    raycaster      = require('raycaster'),
    GraphNode      = require('node'),
    NodeSearcher   = require('node_searcher'),
    Connection     = require('connection'),
    SelectionBox   = require('selection_box'),
    websocket      = require('websocket'),
    textEditor     = require('text_editor'),
    connectionPen  = require('connection_pen');

console.info("Current version " + brunch.env + " " + brunch.git_commit);
console.info("Build at " + brunch.date);

$$.nodes             = {};
$$.connections       = {};
$$.currentConnection = null;
$$.selectionBox      = null;
$$.websocket         = websocket();


var nodeZOrderStep  = 0.00001;
var nodeZOrderStart = 0.00000;

var shouldRender = true;

function start() {
  $(document).ready(function(){
    $(document).bind('contextmenu', function() { return false; });
    require('env')();
  });
}

function initializeGl() {
    if(window.already_initialized) {
        location.reload();
    }

    window.already_initialized = true;
    $$.scene                 = new THREE.Scene();
    $$.sceneHUD              = new THREE.Scene();
    $$.camera                = new THREE.OrthographicCamera(-500, 500, -500, 500, 1, 1000);
    $$.cameraHUD             = new THREE.OrthographicCamera(-500, 500, -500, 500, 1, 1000);
    $$.camera.position.z     = 500;
    $$.cameraHUD.position.z  = 500;
    $$.renderer              = new THREE.WebGLRenderer({ antialias: false });
    $$.renderer.autoClear    = false;
    $$.rendererMap           = new THREE.WebGLRenderer({ antialias: false, preserveDrawingBuffer: true });
    $$.rendererMap.autoClear = false;
    $$.rendererMapCtx        = $$.rendererMap.getContext();


    $('body').append('<div id="htmlcanvas-pan"><div id="htmlcanvas"></div></div>');

    $$.htmlCanvasPan = $("#htmlcanvas-pan");
    $$.htmlCanvas    = $("#htmlcanvas");

    $$.renderer.setClearColor(config.backgroundColor, 1);
    $$.rendererMap.setClearColor(new THREE.Color("black"), 1);
    $($$.renderer.domElement).addClass('renderer');
    $($$.rendererMap.domElement).addClass('renderer').css({zIndex: 100});


    $$.canvas2D = $('<canvas id="canvas2d">')[0];
    document.body.appendChild($$.canvas2D);
    $$.canvas2DCtx = $$.canvas2D.getContext('2d');

    document.body.appendChild($$.renderer.domElement);

    // document.body.appendChild($$.rendererMap.domElement);

    initCommonWidgets();
    addVersionToHud();
    textEditor.init();

    $('#log').remove();
    $('#spinner').remove();

}

function addVersionToHud() {
  var createText   = require('bmfont').render;
  var font         = require("font/LatoBlack-sdf");
  var textMaterial = require('font/text_material').hud;

  var geom = createText({
    text: "Build at " + brunch.date,
    font: font,
    align: 'left'
  });

  var obj = new THREE.Mesh(geom, textMaterial);
  obj.scale.multiplyScalar(config.fontSize);
  obj.position.y = 20;
  obj.position.x = 500;

  $$.sceneHUD.add(obj);
}

function initCommonWidgets() {
  $$.currentConnection = new Connection(3, -1);
  $$.selectionBox      = new SelectionBox();

  $$.scene.add($$.currentConnection.mesh);
  $$.scene.add($$.selectionBox.mesh);
}

function render() {
  if(shouldRender) {
    $$.commonUniforms.objectMap.value = 0;
    $$.commonUniforms.antialias.value = 1;

    $$.renderer.clear();
    $$.renderer.render($$.scene, $$.camera);
    $$.renderer.clearDepth();
    $$.renderer.render($$.sceneHUD, $$.cameraHUD);

    raycaster.renderMap();
    shouldRender = false;
  }
  connectionPen.fadeCanvas();
  requestAnimationFrame(render);
}

function updateHtmCanvasPanPos(x, y, factor) {
  $$.htmlCanvasPan.css({left: x, top: y});
  $$.htmlCanvas.css({zoom: factor});
}

function updateScreenSize(width, height) {
  $$.renderer.setSize(width, height);
  $$.rendererMap.setSize(width, height);
  $$.canvas2D.width  = width;
  $$.canvas2D.height = height;
}

function updateCamera(factor, left, right, top, bottom) {
  $$.camFactor.value = factor;
  $$.camera.left     = left;
  $$.camera.right    = right;
  $$.camera.top      = top;
  $$.camera.bottom   = bottom;
}

function updateCameraHUD(left, right, top, bottom) {
  $$.cameraHUD.left     = left;
  $$.cameraHUD.right    = right;
  $$.cameraHUD.top      = top;
  $$.cameraHUD.bottom   = bottom;
}

function updateMouse(x, y) {
  _.values($$.nodes).forEach(function(node) {
    node.updateMouse(x, y);
  });
}

function newNodeAt(id, x, y, expr, widgetId) {
  var pos = new THREE.Vector2(x, y);
  var node = new GraphNode(id, pos, nodeZOrderStart + id * nodeZOrderStep, widgetId);
  $$.nodes[id] = node;
  node.label(expr);
  $$.scene.add(node.mesh);
  $$.registry[widgetId] = node;
}

function removeNode(i) {
  var node = $$.nodes[i];
  $$.scene.remove(node.mesh);
  delete $$.nodes[i];
  // delete $$.registry[65536 + i];
}

// -> HS
function moveToTopZ(nodeId) {
  var nodeToTop = $$.nodes[nodeId];
  var nodeToTopZ = nodeToTop.zPos();
  var maxZ = nodeToTop.zPos();
  _.values($$.nodes).forEach(function(node) {
    var nodeZ = node.zPos();
    if (nodeZ > nodeToTopZ) {
      node.zPos(nodeZ - nodeZOrderStep);
      if (nodeZ > maxZ) {
        maxZ = nodeZ;
      }
    }
  });
  nodeToTop.zPos(maxZ);
}

function createNodeSearcher(expression, left, top) {
  var ns;
  if (features.node_searcher) {
    destroyNodeSearcher();
    ns = new NodeSearcher();
    $$.node_searcher = ns;
    $('body').append(ns.el);
    ns.init();
    ns.el.css({left: left, top: top});
    if(expression)
      ns.setExpression(expression);
    return ns;
  }
}

function destroyNodeSearcher() {
  if ($$.node_searcher !== undefined) {
    $$.node_searcher.destroy();
  }
}

function displaySelectionBox(x0, y0, x1, y1) {
  $$.selectionBox.setPos(x0, y0, x1, y1);
  $$.selectionBox.show();
}

function hideSelectionBox() {
  $$.selectionBox.hide();
}

function displayCurrentConnection(x0, y0, x1, y1) {
  $$.currentConnection.setPos(x0, y0, x1, y1);
  $$.currentConnection.show();
}

function removeCurrentConnection() {
  $$.currentConnection.hide();
}

function displayConnection(widgetId, id, x0, y0, x1, y1) {
  if ($$.connections[id] === undefined) {
    var connection = new Connection(widgetId, id);
    $$.connections[id] = connection;
    $$.scene.add(connection.mesh);
  }
  $$.connections[id].setPos(x0, y0, x1, y1);
  $$.connections[id].show();
}

function removeConnection(id) {
  if ($$.connections[id]) {
    $$.connections[id].hide();
  }
}

var displayRejectedMessage = function () {
  $("canvas").remove();
  $("#htmlcanvas-pan").remove();
  $("#spinner").remove();
  $("#rejected").show();
}

module.exports = {
  start:                    start,
  initializeGl:             initializeGl,
  render:                   render,
  moveToTopZ:               moveToTopZ,
  newNodeAt:                newNodeAt,
  removeNode:               removeNode,
  updateHtmCanvasPanPos:    updateHtmCanvasPanPos,
  updateScreenSize:         updateScreenSize,
  updateCamera:             updateCamera,
  updateCameraHUD:          updateCameraHUD,
  updateMouse:              updateMouse,
  createNodeSearcher:       createNodeSearcher,
  destroyNodeSearcher:      destroyNodeSearcher,
  displaySelectionBox:      displaySelectionBox,
  hideSelectionBox:         hideSelectionBox,
  displayCurrentConnection: displayCurrentConnection,
  removeCurrentConnection:  removeCurrentConnection,
  displayConnection:        displayConnection,
  removeConnection:         removeConnection,
  websocket:                $$.websocket,
  displayRejectedMessage:   displayRejectedMessage,
  getNode:                  function(index) { return $$.nodes[index];    },
  getNodes:                 function()      { return _.values($$.nodes); },
  nodeSearcher:             function()      { return $$.node_searcher;   },
  shouldRender:             function()      { shouldRender = true;       }
};



});

require.register("breadcrumb", function(exports, require, module) {
"use strict";

var font         = require("font/LatoBlack-sdf"),
    layoutText   = require('bmfont').layout;

module.exports.calculateTextWidth = function(txt) {
    return layoutText({font: font, text: txt}).width;
};
});

require.register("common", function(exports, require, module) {
"use strict";

var commonUniforms =  {
  camFactor:  {type: 'f',  value: 1.0},
  antialias:  {type: 'i',  value: 0},
  objectMap:  {type: 'i',  value: 1}
};

module.exports = {
  commonUniforms: commonUniforms,
  camFactor:      commonUniforms.camFactor,
  scene:          undefined,
  camera:         undefined,
  renderer:       undefined,
  htmlCanvasPan:  undefined,
  htmlCanvas:     undefined,
  node_searcher:  undefined,
  websocket:      undefined,
  registry:       {}
};

window.$$ = module.exports;

});

require.register("config", function(exports, require, module) {
"use strict";

var release = require('config.release');
var brunch = require('brunch');
var config;

if(brunch.env !== "production") {
  var local = {};
  var debug = require('config.debug');
  try {
    local   = require('config.local');
  } catch (e) {
    // no local overrides, skipping.
  }

  var browser = {};
  if(localStorage.getItem('logging') !== null) {
    browser.logging = (localStorage.getItem('logging') === "true");
  }
  if (localStorage.getItem("backend") !== null) {
    browser.backend = (localStorage.getItem("backend") === "true");
  }
  browser.backendAddress = localStorage.getItem("backendAddress") || "ws://127.0.0.1:8088"

  config = _({}).defaults(browser, local, debug, release);

  console.info("Backend address is " + browser.backendAddress);

  console.info("Backend connection is " + (config.backend ? "enabled" : "disabled"));

  window.enableBackend = function  () {
    console.info("Backend connection enabled! Please reload the page.");
    localStorage.setItem('backend', "true");
  };
  window.disableBackend = function () {
    console.info("Backend connection disabled! Please reload the page.");
    localStorage.setItem('backend', "false");
  };
  window.setBackendAddress = function (addr) {
    console.log("Backend address set to: " + addr + ". Refresh the page to use your new backend.");
    localStorage.setItem('backendAddress', addr);
  }

  console.info("Logging is " + (config.logging?"enabled":"disabled"));

  window.enableLogging  = function(){
    console.info("Logging enabled! Please reload the page.");
    localStorage.setItem('logging', "true" );
  };
  window.disableLogging = function(){
    console.info("Logging disabled! Please reload the page.");
    localStorage.setItem('logging', "false");
  };
} else {
  config = release;
}

module.exports = config;

});

require.register("connection", function(exports, require, module) {
"use strict";

var $$ = require('common');
var vs = require('shaders/connection.vert')();
var fs = require('shaders/connection.frag')();

var color = new THREE.Vector4(0.5, 0.5, 0.05, 0.6);

function Connection(widgetId, id) {
  var _this = this;
  this.id = id;
  this.geometry = new THREE.PlaneBufferGeometry(1.0, 10.0);

  this.uniforms = {
    color:      { type: 'v4', value: color },
    visible:    { type: 'f',  value: 0 },
    connecting: { type: 'i',  value: (widgetId == 3?1:0) },
    len:        { type: 'f',  value: 0 },
    objectId:   { type: 'v3', value: new THREE.Vector3((widgetId % 256) / 255.0, Math.floor(Math.floor(widgetId % 65536) / 256) / 255.0, Math.floor(widgetId / 65536) / 255.0) }

  };

  Object.keys($$.commonUniforms).forEach(function(k) {
    _this.uniforms[k] = $$.commonUniforms[k];
  });

  this.mesh = new THREE.Mesh(
    this.geometry,
    new THREE.ShaderMaterial({
      uniforms:       this.uniforms,
      vertexShader:   vs,
      fragmentShader: fs,
      transparent:    true,
      blending:       THREE.NormalBlending,
      side:           THREE.DoubleSide
    })
  );

  this.mesh.scale.x = 1;
  this.mesh.rotation.z = 0;
  this.mesh.position.z = 0.02;
}

Connection.prototype.setPos = function(x0, y0, x1, y1) {
  var dist = 0;
  var x = x1 - x0;
  var y = y1 - y0;
  var r = Math.sqrt(x * x + y * y);
  var x_r = x / r;
  var y_r = y / r;

  this.mesh.material.uniforms.len.value = r;

  this.mesh.scale.x = Math.max((r - 2 * dist), 0);
  var scale = this.mesh.scale.x / 2;

  this.mesh.rotation.z = Math.sign(y) * Math.acos(x_r);

  this.mesh.position.x = (dist * x_r) + x0 + x_r * scale;
  this.mesh.position.y = (dist * y_r) + y0 + y_r * scale;
};

Connection.prototype.show = function() {
  this.mesh.material.uniforms.visible.value = 1;
};

Connection.prototype.hide = function() {
  this.mesh.material.uniforms.visible.value = 0;
};

module.exports = Connection;

});

require.register("connection_pen", function(exports, require, module) {
"use strict";

var $$        = require('common'),
    raycaster = require('raycaster');

var iterations = 0;
var tempCanvas = document.createElement('canvas');
var type = false;
var map  = null;


function clearCanvas() {
  $$.canvas2DCtx.clearRect(0, 0, $$.canvas2D.width, $$.canvas2D.height);
};

function beginPath(x, y, _type) {
  type = _type;
  $$.canvas2DCtx.beginPath();
  $$.canvas2DCtx.moveTo(x, y);
  raycaster.cacheMap()
  iterations = -1;
  $$.canvas2DCtx.strokeStyle = (type ? "#00ff00" : "#ff0000");
  $$.canvas2DCtx.lineCap = 'round';
  $$.canvas2DCtx.globalAlpha = 1.0;};

function drawSegment(x, y) {
  $$.canvas2DCtx.lineTo(x, y);
  $$.canvas2DCtx.stroke();
}

function endPath() {
  iterations = 40;
};

function fadeCanvas() {
  if (iterations > 0) {

    tempCanvas.width  = $$.canvas2D.width;
    tempCanvas.height = $$.canvas2D.height;
    tempCanvas.getContext('2d').drawImage($$.canvas2D, 0, 0);
    clearCanvas();
    $$.canvas2DCtx.globalAlpha = 0.90;
    $$.canvas2DCtx.drawImage(tempCanvas, 0, 0, tempCanvas.width, tempCanvas.height, 0, 0, $$.canvas2D.width, $$.canvas2D.height);

    iterations -= 1;
  } else {
    if (iterations == 0) {
      clearCanvas();
      iterations = -1;
    }
  }
}

function colEq(a, b) {
  return (a[0] == b[0]) && (a[1] == b[1]) && (a[2] == b[2]) && (a[3] == b[3]);
}

function getWidgetsBetween(x1, y1, x2, y2) {
    var points = [];
    var apnd = function (px, py) {
          var idAt = raycaster.getMapPixelAtCached(px, py);
          if (points.length == 0 || !colEq(points[points.length-1], idAt))
              points.push(idAt);
          // points.push({"x": px, "y": py});
    };

    var dx = x2 - x1;
    var dy = y2 - y1;

    // Determine how steep the line is
    var is_steep = Math.abs(dy) > Math.abs(dx)

    // Rotate line
    if (is_steep) {
        y1 = [x1, x1 = y1][0];
        y2 = [x2, x2 = y2][0];
    }

    // Swap start and end points if necessary and store swap state
    var swapped = false;
    if (x1 > x2) {
        x2 = [x1, x1 = x2][0];
        y2 = [y1, y1 = y2][0];
        swapped = true;
    }

    // Recalculate differentials
    dx = x2 - x1;
    dy = y2 - y1;

    // Calculate error
    var error = dx / 2;
    var ystep = (y1 < y2) ? 1 : -1;

    // Iterate over bounding box generating points between start and end
    var y = y1;
    for (var x = x1; x < x2 + 1; x += 1) {
        var coord = (is_steep) ? [y, x] : [x, y];
        apnd(coord[0], coord[1]);
        error -= Math.abs(dy);
        if (error < 0) {
            y += ystep;
            error += dx;
        }
    }

    // Reverse the list if the coordinates were swapped
    if (swapped) {
        points.reverse();
    }

    return points;
}

function colorToId(col) {
  return col[0] + 256 * col[1] + 65535 * col[2];
}

function requestWidgetsBetween(x1, y1, x2, y2) {
  var widgets = getWidgetsBetween(x1, y1, x2, y2).map(colorToId);

  module.exports.callback(widgets);
}



module.exports = {
  clearCanvas:        clearCanvas,
  beginPath:          beginPath,
  drawSegment:        drawSegment,
  fadeCanvas:         fadeCanvas,
  getWidgetsBetween:  getWidgetsBetween,
  requestWidgetsBetween: requestWidgetsBetween,
  endPath: endPath,
  callback:           function() { console.error("ConnectionPen: Callback was not registered.") }
};

});

require.register("exampleData", function(exports, require, module) {
module.exports = [{"Date":"01/12/2011","Month":"Dec-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Tau","Pack Size":"12","Pack Type":"Standard","SKU":"Tau 12 Pack Standard","Price Tier":"Regular","Unit Sales":"1331","Sales Value":"94350","Distribution":"96.8","Cost of Sales":"239.71","Price":"70.89","Gross Profit":"94110.29","Indirect Costs":"87865.49","Operating Profit":"6244.8","Unit Sales Monthly Change":"258","Sales Value Monthly Change":"18599","Distribution Monthly Change":"-1.04","Cost of Sales Monthly Change":"47.25","Price Monthly Change":"0.29","Gross Profit Monthly Change":"18551.75","Indirect Costs Monthly Change":"17320.54","Operating Profit Monthly Change":"1231.21"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Delta","Pack Size":"12","Pack Type":"Standard","SKU":"Delta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1765","Sales Value":"95444","Distribution":"97.25","Cost of Sales":"242.48","Price":"54.08","Gross Profit":"95201.52","Indirect Costs":"88884.12","Operating Profit":"6317.4","Unit Sales Monthly Change":"1765","Sales Value Monthly Change":"95444","Distribution Monthly Change":"97.25","Cost of Sales Monthly Change":"242.48","Price Monthly Change":"54.08","Gross Profit Monthly Change":"95201.52","Indirect Costs Monthly Change":"88884.12","Operating Profit Monthly Change":"6317.4"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"8","Pack Type":"Standard","SKU":"Omicron 8 Pack Standard","Price Tier":"Regular","Unit Sales":"1100","Sales Value":"91520","Distribution":"99.16","Cost of Sales":"232.52","Price":"83.2","Gross Profit":"91287.48","Indirect Costs":"85230.37","Operating Profit":"6057.11","Unit Sales Monthly Change":"1100","Sales Value Monthly Change":"91520","Distribution Monthly Change":"99.16","Cost of Sales Monthly Change":"232.52","Price Monthly Change":"83.2","Gross Profit Monthly Change":"91287.48","Indirect Costs Monthly Change":"85230.37","Operating Profit Monthly Change":"6057.11"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Deluxe","SKU":"Omicron 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"548","Sales Value":"48904","Distribution":"89.68","Cost of Sales":"124.24","Price":"89.24","Gross Profit":"48779.76","Indirect Costs":"45542.54","Operating Profit":"3237.22","Unit Sales Monthly Change":"548","Sales Value Monthly Change":"48904","Distribution Monthly Change":"89.68","Cost of Sales Monthly Change":"124.24","Price Monthly Change":"89.24","Gross Profit Monthly Change":"48779.76","Indirect Costs Monthly Change":"45542.54","Operating Profit Monthly Change":"3237.22"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Giftset","SKU":"Omicron 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"3307","Sales Value":"269467","Distribution":"98.19","Cost of Sales":"684.61","Price":"81.48","Gross Profit":"268782.39","Indirect Costs":"250946.65","Operating Profit":"17835.74","Unit Sales Monthly Change":"3307","Sales Value Monthly Change":"269467","Distribution Monthly Change":"98.19","Cost of Sales Monthly Change":"684.61","Price Monthly Change":"81.48","Gross Profit Monthly Change":"268782.39","Indirect Costs Monthly Change":"250946.65","Operating Profit Monthly Change":"17835.74"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Standard","SKU":"Omicron 12 Pack Standard","Price Tier":"Regular","Unit Sales":"9596","Sales Value":"662294","Distribution":"99.52","Cost of Sales":"1682.63","Price":"69.02","Gross Profit":"660611.37","Indirect Costs":"616775.54","Operating Profit":"43835.83","Unit Sales Monthly Change":"9596","Sales Value Monthly Change":"662294","Distribution Monthly Change":"99.52","Cost of Sales Monthly Change":"1682.63","Price Monthly Change":"69.02","Gross Profit Monthly Change":"660611.37","Indirect Costs Monthly Change":"616775.54","Operating Profit Monthly Change":"43835.83"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"18","Pack Type":"Standard","SKU":"Omicron 18 Pack Standard","Price Tier":"Regular","Unit Sales":"6629","Sales Value":"409612","Distribution":"96.28","Cost of Sales":"1040.66","Price":"61.79","Gross Profit":"408571.34","Indirect Costs":"381459.74","Operating Profit":"27111.6","Unit Sales Monthly Change":"6629","Sales Value Monthly Change":"409612","Distribution Monthly Change":"96.28","Cost of Sales Monthly Change":"1040.66","Price Monthly Change":"61.79","Gross Profit Monthly Change":"408571.34","Indirect Costs Monthly Change":"381459.74","Operating Profit Monthly Change":"27111.6"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Giftset","SKU":"Sigma 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"695","Sales Value":"105748","Distribution":"71.18","Cost of Sales":"268.66","Price":"152.16","Gross Profit":"105479.34","Indirect Costs":"98480.32","Operating Profit":"6999.02","Unit Sales Monthly Change":"695","Sales Value Monthly Change":"105748","Distribution Monthly Change":"71.18","Cost of Sales Monthly Change":"268.66","Price Monthly Change":"152.16","Gross Profit Monthly Change":"105479.34","Indirect Costs Monthly Change":"98480.32","Operating Profit Monthly Change":"6999.02"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Standard","SKU":"Sigma 12 Pack Standard","Price Tier":"Premium","Unit Sales":"707","Sales Value":"101950","Distribution":"92.19","Cost of Sales":"259.01","Price":"144.2","Gross Profit":"101690.99","Indirect Costs":"94943.35","Operating Profit":"6747.64","Unit Sales Monthly Change":"707","Sales Value Monthly Change":"101950","Distribution Monthly Change":"92.19","Cost of Sales Monthly Change":"259.01","Price Monthly Change":"144.2","Gross Profit Monthly Change":"101690.99","Indirect Costs Monthly Change":"94943.35","Operating Profit Monthly Change":"6747.64"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Tau","Pack Size":"12","Pack Type":"Standard","SKU":"Tau 12 Pack Standard","Price Tier":"Regular","Unit Sales":"1110","Sales Value":"70955","Distribution":"83.38","Cost of Sales":"180.27","Price":"63.92","Gross Profit":"70774.73","Indirect Costs":"66078.2","Operating Profit":"4696.53","Unit Sales Monthly Change":"1110","Sales Value Monthly Change":"70955","Distribution Monthly Change":"83.38","Cost of Sales Monthly Change":"180.27","Price Monthly Change":"63.92","Gross Profit Monthly Change":"70774.73","Indirect Costs Monthly Change":"66078.2","Operating Profit Monthly Change":"4696.53"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Epsilon","Pack Size":"12","Pack Type":"Standard","SKU":"Epsilon 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1207","Sales Value":"63214","Distribution":"82.07","Cost of Sales":"160.6","Price":"52.37","Gross Profit":"63053.4","Indirect Costs":"58869.6","Operating Profit":"4183.8","Unit Sales Monthly Change":"1207","Sales Value Monthly Change":"63214","Distribution Monthly Change":"82.07","Cost of Sales Monthly Change":"160.6","Price Monthly Change":"52.37","Gross Profit Monthly Change":"63053.4","Indirect Costs Monthly Change":"58869.6","Operating Profit Monthly Change":"4183.8"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Giftset","SKU":"Iota 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"610","Sales Value":"55730","Distribution":"93.91","Cost of Sales":"141.59","Price":"91.36","Gross Profit":"55588.41","Indirect Costs":"51899.59","Operating Profit":"3688.82","Unit Sales Monthly Change":"610","Sales Value Monthly Change":"55730","Distribution Monthly Change":"93.91","Cost of Sales Monthly Change":"141.59","Price Monthly Change":"91.36","Gross Profit Monthly Change":"55588.41","Indirect Costs Monthly Change":"51899.59","Operating Profit Monthly Change":"3688.82"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Standard","SKU":"Iota 12 Pack Standard","Price Tier":"Regular","Unit Sales":"1096","Sales Value":"90079","Distribution":"95.69","Cost of Sales":"228.85","Price":"82.19","Gross Profit":"89850.15","Indirect Costs":"83887.66","Operating Profit":"5962.49","Unit Sales Monthly Change":"1096","Sales Value Monthly Change":"90079","Distribution Monthly Change":"95.69","Cost of Sales Monthly Change":"228.85","Price Monthly Change":"82.19","Gross Profit Monthly Change":"89850.15","Indirect Costs Monthly Change":"83887.66","Operating Profit Monthly Change":"5962.49"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"8","Pack Type":"Standard","SKU":"Lambda 8 Pack Standard","Price Tier":"Budget","Unit Sales":"469","Sales Value":"30940","Distribution":"73.82","Cost of Sales":"78.61","Price":"65.97","Gross Profit":"30861.39","Indirect Costs":"28813.73","Operating Profit":"2047.66","Unit Sales Monthly Change":"469","Sales Value Monthly Change":"30940","Distribution Monthly Change":"73.82","Cost of Sales Monthly Change":"78.61","Price Monthly Change":"65.97","Gross Profit Monthly Change":"30861.39","Indirect Costs Monthly Change":"28813.73","Operating Profit Monthly Change":"2047.66"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"12","Pack Type":"Standard","SKU":"Lambda 12 Pack Standard","Price Tier":"Budget","Unit Sales":"2948","Sales Value":"168473","Distribution":"99.48","Cost of Sales":"428.02","Price":"57.15","Gross Profit":"168044.98","Indirect Costs":"156894.53","Operating Profit":"11150.45","Unit Sales Monthly Change":"2948","Sales Value Monthly Change":"168473","Distribution Monthly Change":"99.48","Cost of Sales Monthly Change":"428.02","Price Monthly Change":"57.15","Gross Profit Monthly Change":"168044.98","Indirect Costs Monthly Change":"156894.53","Operating Profit Monthly Change":"11150.45"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Mu","Pack Size":"12","Pack Type":"Standard","SKU":"Mu 12 Pack Standard","Price Tier":"Premium","Unit Sales":"105","Sales Value":"16874","Distribution":"25.45","Cost of Sales":"42.87","Price":"160.7","Gross Profit":"16831.13","Indirect Costs":"15714.65","Operating Profit":"1116.48","Unit Sales Monthly Change":"105","Sales Value Monthly Change":"16874","Distribution Monthly Change":"25.45","Cost of Sales Monthly Change":"42.87","Price Monthly Change":"160.7","Gross Profit Monthly Change":"16831.13","Indirect Costs Monthly Change":"15714.65","Operating Profit Monthly Change":"1116.48"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"6","Pack Type":"Standard","SKU":"Theta 6 Pack Standard","Price Tier":"Regular","Unit Sales":"133","Sales Value":"12991","Distribution":"16.45","Cost of Sales":"33.01","Price":"97.68","Gross Profit":"12957.99","Indirect Costs":"12098.34","Operating Profit":"859.65","Unit Sales Monthly Change":"133","Sales Value Monthly Change":"12991","Distribution Monthly Change":"16.45","Cost of Sales Monthly Change":"33.01","Price Monthly Change":"97.68","Gross Profit Monthly Change":"12957.99","Indirect Costs Monthly Change":"12098.34","Operating Profit Monthly Change":"859.65"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"8","Pack Type":"Standard","SKU":"Theta 8 Pack Standard","Price Tier":"Regular","Unit Sales":"890","Sales Value":"77897","Distribution":"99.34","Cost of Sales":"197.9","Price":"87.52","Gross Profit":"77699.1","Indirect Costs":"72543.1","Operating Profit":"5156","Unit Sales Monthly Change":"890","Sales Value Monthly Change":"77897","Distribution Monthly Change":"99.34","Cost of Sales Monthly Change":"197.9","Price Monthly Change":"87.52","Gross Profit Monthly Change":"77699.1","Indirect Costs Monthly Change":"72543.1","Operating Profit Monthly Change":"5156"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Theta 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"1693","Sales Value":"130549","Distribution":"94.55","Cost of Sales":"331.67","Price":"77.11","Gross Profit":"130217.33","Indirect Costs":"121576.23","Operating Profit":"8641.1","Unit Sales Monthly Change":"1693","Sales Value Monthly Change":"130549","Distribution Monthly Change":"94.55","Cost of Sales Monthly Change":"331.67","Price Monthly Change":"77.11","Gross Profit Monthly Change":"130217.33","Indirect Costs Monthly Change":"121576.23","Operating Profit Monthly Change":"8641.1"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Giftset","SKU":"Theta 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"6623","Sales Value":"506206","Distribution":"99.42","Cost of Sales":"1286.07","Price":"76.43","Gross Profit":"504919.93","Indirect Costs":"471415.56","Operating Profit":"33504.37","Unit Sales Monthly Change":"6623","Sales Value Monthly Change":"506206","Distribution Monthly Change":"99.42","Cost of Sales Monthly Change":"1286.07","Price Monthly Change":"76.43","Gross Profit Monthly Change":"504919.93","Indirect Costs Monthly Change":"471415.56","Operating Profit Monthly Change":"33504.37"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Standard","SKU":"Theta 12 Pack Standard","Price Tier":"Regular","Unit Sales":"4514","Sales Value":"328711","Distribution":"100","Cost of Sales":"835.12","Price":"72.82","Gross Profit":"327875.88","Indirect Costs":"306118.91","Operating Profit":"21756.97","Unit Sales Monthly Change":"4514","Sales Value Monthly Change":"328711","Distribution Monthly Change":"100","Cost of Sales Monthly Change":"835.12","Price Monthly Change":"72.82","Gross Profit Monthly Change":"327875.88","Indirect Costs Monthly Change":"306118.91","Operating Profit Monthly Change":"21756.97"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"18","Pack Type":"Standard","SKU":"Theta 18 Pack Standard","Price Tier":"Regular","Unit Sales":"16594","Sales Value":"999335","Distribution":"98.39","Cost of Sales":"2538.91","Price":"60.22","Gross Profit":"996796.09","Indirect Costs":"930652.88","Operating Profit":"66143.21","Unit Sales Monthly Change":"16594","Sales Value Monthly Change":"999335","Distribution Monthly Change":"98.39","Cost of Sales Monthly Change":"2538.91","Price Monthly Change":"60.22","Gross Profit Monthly Change":"996796.09","Indirect Costs Monthly Change":"930652.88","Operating Profit Monthly Change":"66143.21"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"LexCorp","Brand":"Gamma","Pack Size":"12","Pack Type":"Standard","SKU":"Gamma 12 Pack Standard","Price Tier":"Budget","Unit Sales":"2600","Sales Value":"162545","Distribution":"98.33","Cost of Sales":"412.96","Price":"62.52","Gross Profit":"162132.04","Indirect Costs":"151373.95","Operating Profit":"10758.09","Unit Sales Monthly Change":"2600","Sales Value Monthly Change":"162545","Distribution Monthly Change":"98.33","Cost of Sales Monthly Change":"412.96","Price Monthly Change":"62.52","Gross Profit Monthly Change":"162132.04","Indirect Costs Monthly Change":"151373.95","Operating Profit Monthly Change":"10758.09"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"12","Pack Type":"Standard","SKU":"Alpha 12 Pack Standard","Price Tier":"Regular","Unit Sales":"396","Sales Value":"35555","Distribution":"70.78","Cost of Sales":"90.33","Price":"89.79","Gross Profit":"35464.67","Indirect Costs":"33111.19","Operating Profit":"2353.48","Unit Sales Monthly Change":"396","Sales Value Monthly Change":"35555","Distribution Monthly Change":"70.78","Cost of Sales Monthly Change":"90.33","Price Monthly Change":"89.79","Gross Profit Monthly Change":"35464.67","Indirect Costs Monthly Change":"33111.19","Operating Profit Monthly Change":"2353.48"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"18","Pack Type":"Standard","SKU":"Alpha 18 Pack Standard","Price Tier":"Regular","Unit Sales":"1575","Sales Value":"114674","Distribution":"92.19","Cost of Sales":"291.34","Price":"72.81","Gross Profit":"114382.66","Indirect Costs":"106792.48","Operating Profit":"7590.18","Unit Sales Monthly Change":"1575","Sales Value Monthly Change":"114674","Distribution Monthly Change":"92.19","Cost of Sales Monthly Change":"291.34","Price Monthly Change":"72.81","Gross Profit Monthly Change":"114382.66","Indirect Costs Monthly Change":"106792.48","Operating Profit Monthly Change":"7590.18"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"8","Pack Type":"Standard","SKU":"Beta 8 Pack Standard","Price Tier":"Premium","Unit Sales":"735","Sales Value":"84024","Distribution":"92.28","Cost of Sales":"213.47","Price":"114.32","Gross Profit":"83810.53","Indirect Costs":"78249.18","Operating Profit":"5561.35","Unit Sales Monthly Change":"735","Sales Value Monthly Change":"84024","Distribution Monthly Change":"92.28","Cost of Sales Monthly Change":"213.47","Price Monthly Change":"114.32","Gross Profit Monthly Change":"83810.53","Indirect Costs Monthly Change":"78249.18","Operating Profit Monthly Change":"5561.35"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Beta 12 Pack Deluxe","Price Tier":"Premium","Unit Sales":"688","Sales Value":"79887","Distribution":"64.09","Cost of Sales":"202.96","Price":"116.11","Gross Profit":"79684.04","Indirect Costs":"74396.51","Operating Profit":"5287.53","Unit Sales Monthly Change":"688","Sales Value Monthly Change":"79887","Distribution Monthly Change":"64.09","Cost of Sales Monthly Change":"202.96","Price Monthly Change":"116.11","Gross Profit Monthly Change":"79684.04","Indirect Costs Monthly Change":"74396.51","Operating Profit Monthly Change":"5287.53"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Giftset","SKU":"Beta 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"1727","Sales Value":"197923","Distribution":"95.62","Cost of Sales":"502.84","Price":"114.61","Gross Profit":"197420.16","Indirect Costs":"184320.3","Operating Profit":"13099.86","Unit Sales Monthly Change":"1727","Sales Value Monthly Change":"197923","Distribution Monthly Change":"95.62","Cost of Sales Monthly Change":"502.84","Price Monthly Change":"114.61","Gross Profit Monthly Change":"197420.16","Indirect Costs Monthly Change":"184320.3","Operating Profit Monthly Change":"13099.86"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Standard","SKU":"Beta 12 Pack Standard","Price Tier":"Premium","Unit Sales":"7383","Sales Value":"713849","Distribution":"99.2","Cost of Sales":"1813.61","Price":"96.69","Gross Profit":"712035.39","Indirect Costs":"664787.82","Operating Profit":"47247.57","Unit Sales Monthly Change":"7383","Sales Value Monthly Change":"713849","Distribution Monthly Change":"99.2","Cost of Sales Monthly Change":"1813.61","Price Monthly Change":"96.69","Gross Profit Monthly Change":"712035.39","Indirect Costs Monthly Change":"664787.82","Operating Profit Monthly Change":"47247.57"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"18","Pack Type":"Standard","SKU":"Beta 18 Pack Standard","Price Tier":"Premium","Unit Sales":"4094","Sales Value":"372800","Distribution":"96.81","Cost of Sales":"947.14","Price":"91.06","Gross Profit":"371852.86","Indirect Costs":"347177.95","Operating Profit":"24674.91","Unit Sales Monthly Change":"4094","Sales Value Monthly Change":"372800","Distribution Monthly Change":"96.81","Cost of Sales Monthly Change":"947.14","Price Monthly Change":"91.06","Gross Profit Monthly Change":"371852.86","Indirect Costs Monthly Change":"347177.95","Operating Profit Monthly Change":"24674.91"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"60","Pack Type":"Standard","SKU":"Beta 60 Pack Standard","Price Tier":"Premium","Unit Sales":"893","Sales Value":"90274","Distribution":"54.39","Cost of Sales":"229.35","Price":"101.09","Gross Profit":"90044.65","Indirect Costs":"84069.26","Operating Profit":"5975.39","Unit Sales Monthly Change":"893","Sales Value Monthly Change":"90274","Distribution Monthly Change":"54.39","Cost of Sales Monthly Change":"229.35","Price Monthly Change":"101.09","Gross Profit Monthly Change":"90044.65","Indirect Costs Monthly Change":"84069.26","Operating Profit Monthly Change":"5975.39"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Stark Ind","Brand":"Omega","Pack Size":"12","Pack Type":"Standard","SKU":"Omega 12 Pack Standard","Price Tier":"Budget","Unit Sales":"979","Sales Value":"56381","Distribution":"72.03","Cost of Sales":"143.24","Price":"57.59","Gross Profit":"56237.76","Indirect Costs":"52505.84","Operating Profit":"3731.92","Unit Sales Monthly Change":"979","Sales Value Monthly Change":"56381","Distribution Monthly Change":"72.03","Cost of Sales Monthly Change":"143.24","Price Monthly Change":"57.59","Gross Profit Monthly Change":"56237.76","Indirect Costs Monthly Change":"52505.84","Operating Profit Monthly Change":"3731.92"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"8","Pack Type":"Standard","SKU":"Kappa 8 Pack Standard","Price Tier":"Regular","Unit Sales":"872","Sales Value":"68483","Distribution":"96.5","Cost of Sales":"173.99","Price":"78.54","Gross Profit":"68309.01","Indirect Costs":"63776.66","Operating Profit":"4532.35","Unit Sales Monthly Change":"872","Sales Value Monthly Change":"68483","Distribution Monthly Change":"96.5","Cost of Sales Monthly Change":"173.99","Price Monthly Change":"78.54","Gross Profit Monthly Change":"68309.01","Indirect Costs Monthly Change":"63776.66","Operating Profit Monthly Change":"4532.35"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"12","Pack Type":"Standard","SKU":"Kappa 12 Pack Standard","Price Tier":"Regular","Unit Sales":"1891","Sales Value":"134746","Distribution":"96.8","Cost of Sales":"342.34","Price":"71.26","Gross Profit":"134403.66","Indirect Costs":"125485.34","Operating Profit":"8918.32","Unit Sales Monthly Change":"1891","Sales Value Monthly Change":"134746","Distribution Monthly Change":"96.8","Cost of Sales Monthly Change":"342.34","Price Monthly Change":"71.26","Gross Profit Monthly Change":"134403.66","Indirect Costs Monthly Change":"125485.34","Operating Profit Monthly Change":"8918.32"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"18","Pack Type":"Standard","SKU":"Kappa 18 Pack Standard","Price Tier":"Regular","Unit Sales":"3067","Sales Value":"203498","Distribution":"96.63","Cost of Sales":"517.01","Price":"66.35","Gross Profit":"202980.99","Indirect Costs":"189512.32","Operating Profit":"13468.67","Unit Sales Monthly Change":"3067","Sales Value Monthly Change":"203498","Distribution Monthly Change":"96.63","Cost of Sales Monthly Change":"517.01","Price Monthly Change":"66.35","Gross Profit Monthly Change":"202980.99","Indirect Costs Monthly Change":"189512.32","Operating Profit Monthly Change":"13468.67"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Hypermarkets","Owner":"Wayne Ent","Brand":"Pi","Pack Size":"12","Pack Type":"Giftset","SKU":"Pi 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"804","Sales Value":"62191","Distribution":"79.48","Cost of Sales":"158","Price":"77.35","Gross Profit":"62033","Indirect Costs":"57916.35","Operating Profit":"4116.65","Unit Sales Monthly Change":"804","Sales Value Monthly Change":"62191","Distribution Monthly Change":"79.48","Cost of Sales Monthly Change":"158","Price Monthly Change":"77.35","Gross Profit Monthly Change":"62033","Indirect Costs Monthly Change":"57916.35","Operating Profit Monthly Change":"4116.65"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Delta","Pack Size":"12","Pack Type":"Standard","SKU":"Delta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"838","Sales Value":"50490","Distribution":"19.08","Cost of Sales":"128.27","Price":"60.25","Gross Profit":"50361.73","Indirect Costs":"47019.91","Operating Profit":"3341.82","Unit Sales Monthly Change":"838","Sales Value Monthly Change":"50490","Distribution Monthly Change":"19.08","Cost of Sales Monthly Change":"128.27","Price Monthly Change":"60.25","Gross Profit Monthly Change":"50361.73","Indirect Costs Monthly Change":"47019.91","Operating Profit Monthly Change":"3341.82"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Eta","Pack Size":"12","Pack Type":"Standard","SKU":"Eta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"752","Sales Value":"35716","Distribution":"4.15","Cost of Sales":"90.74","Price":"47.49","Gross Profit":"35625.26","Indirect Costs":"33261.49","Operating Profit":"2363.77","Unit Sales Monthly Change":"752","Sales Value Monthly Change":"35716","Distribution Monthly Change":"4.15","Cost of Sales Monthly Change":"90.74","Price Monthly Change":"47.49","Gross Profit Monthly Change":"35625.26","Indirect Costs Monthly Change":"33261.49","Operating Profit Monthly Change":"2363.77"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"8","Pack Type":"Standard","SKU":"Omicron 8 Pack Standard","Price Tier":"Regular","Unit Sales":"18593","Sales Value":"1339286","Distribution":"50.48","Cost of Sales":"3402.59","Price":"72.03","Gross Profit":"1335883.41","Indirect Costs":"1247239.11","Operating Profit":"88644.3","Unit Sales Monthly Change":"18593","Sales Value Monthly Change":"1339286","Distribution Monthly Change":"50.48","Cost of Sales Monthly Change":"3402.59","Price Monthly Change":"72.03","Gross Profit Monthly Change":"1335883.41","Indirect Costs Monthly Change":"1247239.11","Operating Profit Monthly Change":"88644.3"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Deluxe","SKU":"Omicron 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"383","Sales Value":"37627","Distribution":"9.96","Cost of Sales":"95.6","Price":"98.24","Gross Profit":"37531.4","Indirect Costs":"35041.15","Operating Profit":"2490.25","Unit Sales Monthly Change":"383","Sales Value Monthly Change":"37627","Distribution Monthly Change":"9.96","Cost of Sales Monthly Change":"95.6","Price Monthly Change":"98.24","Gross Profit Monthly Change":"37531.4","Indirect Costs Monthly Change":"35041.15","Operating Profit Monthly Change":"2490.25"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Giftset","SKU":"Omicron 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"3831","Sales Value":"331785","Distribution":"33.52","Cost of Sales":"842.93","Price":"86.61","Gross Profit":"330942.07","Indirect Costs":"308982.02","Operating Profit":"21960.05","Unit Sales Monthly Change":"3831","Sales Value Monthly Change":"331785","Distribution Monthly Change":"33.52","Cost of Sales Monthly Change":"842.93","Price Monthly Change":"86.61","Gross Profit Monthly Change":"330942.07","Indirect Costs Monthly Change":"308982.02","Operating Profit Monthly Change":"21960.05"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Standard","SKU":"Omicron 12 Pack Standard","Price Tier":"Regular","Unit Sales":"10205","Sales Value":"732823","Distribution":"36.64","Cost of Sales":"1861.81","Price":"71.81","Gross Profit":"730961.19","Indirect Costs":"682457.59","Operating Profit":"48503.6","Unit Sales Monthly Change":"10205","Sales Value Monthly Change":"732823","Distribution Monthly Change":"36.64","Cost of Sales Monthly Change":"1861.81","Price Monthly Change":"71.81","Gross Profit Monthly Change":"730961.19","Indirect Costs Monthly Change":"682457.59","Operating Profit Monthly Change":"48503.6"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"18","Pack Type":"Standard","SKU":"Omicron 18 Pack Standard","Price Tier":"Regular","Unit Sales":"4793","Sales Value":"316745","Distribution":"27.97","Cost of Sales":"804.73","Price":"66.08","Gross Profit":"315940.27","Indirect Costs":"294976.06","Operating Profit":"20964.21","Unit Sales Monthly Change":"4793","Sales Value Monthly Change":"316745","Distribution Monthly Change":"27.97","Cost of Sales Monthly Change":"804.73","Price Monthly Change":"66.08","Gross Profit Monthly Change":"315940.27","Indirect Costs Monthly Change":"294976.06","Operating Profit Monthly Change":"20964.21"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Giftset","SKU":"Sigma 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"346","Sales Value":"59810","Distribution":"10.99","Cost of Sales":"151.96","Price":"172.86","Gross Profit":"59658.04","Indirect Costs":"55699.74","Operating Profit":"3958.3","Unit Sales Monthly Change":"346","Sales Value Monthly Change":"59810","Distribution Monthly Change":"10.99","Cost of Sales Monthly Change":"151.96","Price Monthly Change":"172.86","Gross Profit Monthly Change":"59658.04","Indirect Costs Monthly Change":"55699.74","Operating Profit Monthly Change":"3958.3"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Standard","SKU":"Sigma 12 Pack Standard","Price Tier":"Premium","Unit Sales":"632","Sales Value":"99834","Distribution":"15.6","Cost of Sales":"253.64","Price":"157.97","Gross Profit":"99580.36","Indirect Costs":"92972.59","Operating Profit":"6607.77","Unit Sales Monthly Change":"632","Sales Value Monthly Change":"99834","Distribution Monthly Change":"15.6","Cost of Sales Monthly Change":"253.64","Price Monthly Change":"157.97","Gross Profit Monthly Change":"99580.36","Indirect Costs Monthly Change":"92972.59","Operating Profit Monthly Change":"6607.77"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Tau","Pack Size":"12","Pack Type":"Standard","SKU":"Tau 12 Pack Standard","Price Tier":"Regular","Unit Sales":"461","Sales Value":"32039","Distribution":"11.87","Cost of Sales":"81.4","Price":"69.5","Gross Profit":"31957.6","Indirect Costs":"29836.83","Operating Profit":"2120.77","Unit Sales Monthly Change":"461","Sales Value Monthly Change":"32039","Distribution Monthly Change":"11.87","Cost of Sales Monthly Change":"81.4","Price Monthly Change":"69.5","Gross Profit Monthly Change":"31957.6","Indirect Costs Monthly Change":"29836.83","Operating Profit Monthly Change":"2120.77"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Epsilon","Pack Size":"12","Pack Type":"Standard","SKU":"Epsilon 12 Pack Standard","Price Tier":"Budget","Unit Sales":"767","Sales Value":"43339","Distribution":"11.92","Cost of Sales":"110.11","Price":"56.5","Gross Profit":"43228.89","Indirect Costs":"40360.01","Operating Profit":"2868.88","Unit Sales Monthly Change":"767","Sales Value Monthly Change":"43339","Distribution Monthly Change":"11.92","Cost of Sales Monthly Change":"110.11","Price Monthly Change":"56.5","Gross Profit Monthly Change":"43228.89","Indirect Costs Monthly Change":"40360.01","Operating Profit Monthly Change":"2868.88"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Giftset","SKU":"Iota 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"728","Sales Value":"66959","Distribution":"15.17","Cost of Sales":"170.12","Price":"91.98","Gross Profit":"66788.88","Indirect Costs":"62357.4","Operating Profit":"4431.48","Unit Sales Monthly Change":"728","Sales Value Monthly Change":"66959","Distribution Monthly Change":"15.17","Cost of Sales Monthly Change":"170.12","Price Monthly Change":"91.98","Gross Profit Monthly Change":"66788.88","Indirect Costs Monthly Change":"62357.4","Operating Profit Monthly Change":"4431.48"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Standard","SKU":"Iota 12 Pack Standard","Price Tier":"Regular","Unit Sales":"563","Sales Value":"50699","Distribution":"13.72","Cost of Sales":"128.81","Price":"90.05","Gross Profit":"50570.19","Indirect Costs":"47214.36","Operating Profit":"3355.83","Unit Sales Monthly Change":"563","Sales Value Monthly Change":"50699","Distribution Monthly Change":"13.72","Cost of Sales Monthly Change":"128.81","Price Monthly Change":"90.05","Gross Profit Monthly Change":"50570.19","Indirect Costs Monthly Change":"47214.36","Operating Profit Monthly Change":"3355.83"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"8","Pack Type":"Standard","SKU":"Lambda 8 Pack Standard","Price Tier":"Budget","Unit Sales":"383","Sales Value":"26911","Distribution":"10.71","Cost of Sales":"68.37","Price":"70.26","Gross Profit":"26842.63","Indirect Costs":"25061.64","Operating Profit":"1780.99","Unit Sales Monthly Change":"383","Sales Value Monthly Change":"26911","Distribution Monthly Change":"10.71","Cost of Sales Monthly Change":"68.37","Price Monthly Change":"70.26","Gross Profit Monthly Change":"26842.63","Indirect Costs Monthly Change":"25061.64","Operating Profit Monthly Change":"1780.99"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"12","Pack Type":"Standard","SKU":"Lambda 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1884","Sales Value":"118360","Distribution":"27.35","Cost of Sales":"300.7","Price":"62.82","Gross Profit":"118059.3","Indirect Costs":"110224.96","Operating Profit":"7834.34","Unit Sales Monthly Change":"1884","Sales Value Monthly Change":"118360","Distribution Monthly Change":"27.35","Cost of Sales Monthly Change":"300.7","Price Monthly Change":"62.82","Gross Profit Monthly Change":"118059.3","Indirect Costs Monthly Change":"110224.96","Operating Profit Monthly Change":"7834.34"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Mu","Pack Size":"12","Pack Type":"Standard","SKU":"Mu 12 Pack Standard","Price Tier":"Premium","Unit Sales":"291","Sales Value":"47244","Distribution":"7.97","Cost of Sales":"120.03","Price":"162.35","Gross Profit":"47123.97","Indirect Costs":"43997","Operating Profit":"3126.97","Unit Sales Monthly Change":"291","Sales Value Monthly Change":"47244","Distribution Monthly Change":"7.97","Cost of Sales Monthly Change":"120.03","Price Monthly Change":"162.35","Gross Profit Monthly Change":"47123.97","Indirect Costs Monthly Change":"43997","Operating Profit Monthly Change":"3126.97"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"6","Pack Type":"Standard","SKU":"Theta 6 Pack Standard","Price Tier":"Regular","Unit Sales":"344","Sales Value":"34654","Distribution":"9.04","Cost of Sales":"88.04","Price":"100.74","Gross Profit":"34565.96","Indirect Costs":"32271.92","Operating Profit":"2294.04","Unit Sales Monthly Change":"344","Sales Value Monthly Change":"34654","Distribution Monthly Change":"9.04","Cost of Sales Monthly Change":"88.04","Price Monthly Change":"100.74","Gross Profit Monthly Change":"34565.96","Indirect Costs Monthly Change":"32271.92","Operating Profit Monthly Change":"2294.04"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"8","Pack Type":"Standard","SKU":"Theta 8 Pack Standard","Price Tier":"Regular","Unit Sales":"1871","Sales Value":"173690","Distribution":"27.21","Cost of Sales":"441.28","Price":"92.83","Gross Profit":"173248.72","Indirect Costs":"161752.42","Operating Profit":"11496.3","Unit Sales Monthly Change":"1871","Sales Value Monthly Change":"173690","Distribution Monthly Change":"27.21","Cost of Sales Monthly Change":"441.28","Price Monthly Change":"92.83","Gross Profit Monthly Change":"173248.72","Indirect Costs Monthly Change":"161752.42","Operating Profit Monthly Change":"11496.3"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Theta 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"1461","Sales Value":"115226","Distribution":"13.26","Cost of Sales":"292.75","Price":"78.87","Gross Profit":"114933.25","Indirect Costs":"107307.1","Operating Profit":"7626.15","Unit Sales Monthly Change":"1461","Sales Value Monthly Change":"115226","Distribution Monthly Change":"13.26","Cost of Sales Monthly Change":"292.75","Price Monthly Change":"78.87","Gross Profit Monthly Change":"114933.25","Indirect Costs Monthly Change":"107307.1","Operating Profit Monthly Change":"7626.15"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Giftset","SKU":"Theta 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"2836","Sales Value":"239150","Distribution":"24.5","Cost of Sales":"607.58","Price":"84.33","Gross Profit":"238542.42","Indirect Costs":"222714.03","Operating Profit":"15828.39","Unit Sales Monthly Change":"2836","Sales Value Monthly Change":"239150","Distribution Monthly Change":"24.5","Cost of Sales Monthly Change":"607.58","Price Monthly Change":"84.33","Gross Profit Monthly Change":"238542.42","Indirect Costs Monthly Change":"222714.03","Operating Profit Monthly Change":"15828.39"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Standard","SKU":"Theta 12 Pack Standard","Price Tier":"Regular","Unit Sales":"22206","Sales Value":"1391524","Distribution":"62.89","Cost of Sales":"3535.31","Price":"62.66","Gross Profit":"1387988.69","Indirect Costs":"1295887.25","Operating Profit":"92101.44","Unit Sales Monthly Change":"22206","Sales Value Monthly Change":"1391524","Distribution Monthly Change":"62.89","Cost of Sales Monthly Change":"3535.31","Price Monthly Change":"62.66","Gross Profit Monthly Change":"1387988.69","Indirect Costs Monthly Change":"1295887.25","Operating Profit Monthly Change":"92101.44"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"18","Pack Type":"Standard","SKU":"Theta 18 Pack Standard","Price Tier":"Regular","Unit Sales":"5645","Sales Value":"368566","Distribution":"26.43","Cost of Sales":"936.38","Price":"65.29","Gross Profit":"367629.62","Indirect Costs":"343234.75","Operating Profit":"24394.87","Unit Sales Monthly Change":"5645","Sales Value Monthly Change":"368566","Distribution Monthly Change":"26.43","Cost of Sales Monthly Change":"936.38","Price Monthly Change":"65.29","Gross Profit Monthly Change":"367629.62","Indirect Costs Monthly Change":"343234.75","Operating Profit Monthly Change":"24394.87"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"LexCorp","Brand":"Gamma","Pack Size":"12","Pack Type":"Standard","SKU":"Gamma 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1748","Sales Value":"120541","Distribution":"27.13","Cost of Sales":"306.25","Price":"68.96","Gross Profit":"120234.75","Indirect Costs":"112256.06","Operating Profit":"7978.69","Unit Sales Monthly Change":"1748","Sales Value Monthly Change":"120541","Distribution Monthly Change":"27.13","Cost of Sales Monthly Change":"306.25","Price Monthly Change":"68.96","Gross Profit Monthly Change":"120234.75","Indirect Costs Monthly Change":"112256.06","Operating Profit Monthly Change":"7978.69"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"12","Pack Type":"Standard","SKU":"Alpha 12 Pack Standard","Price Tier":"Regular","Unit Sales":"847","Sales Value":"75568","Distribution":"15.15","Cost of Sales":"191.99","Price":"89.22","Gross Profit":"75376.01","Indirect Costs":"70373.98","Operating Profit":"5002.03","Unit Sales Monthly Change":"847","Sales Value Monthly Change":"75568","Distribution Monthly Change":"15.15","Cost of Sales Monthly Change":"191.99","Price Monthly Change":"89.22","Gross Profit Monthly Change":"75376.01","Indirect Costs Monthly Change":"70373.98","Operating Profit Monthly Change":"5002.03"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"18","Pack Type":"Standard","SKU":"Alpha 18 Pack Standard","Price Tier":"Regular","Unit Sales":"319","Sales Value":"25450","Distribution":"6.42","Cost of Sales":"64.66","Price":"79.78","Gross Profit":"25385.34","Indirect Costs":"23700.5","Operating Profit":"1684.84","Unit Sales Monthly Change":"319","Sales Value Monthly Change":"25450","Distribution Monthly Change":"6.42","Cost of Sales Monthly Change":"64.66","Price Monthly Change":"79.78","Gross Profit Monthly Change":"25385.34","Indirect Costs Monthly Change":"23700.5","Operating Profit Monthly Change":"1684.84"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"8","Pack Type":"Standard","SKU":"Beta 8 Pack Standard","Price Tier":"Premium","Unit Sales":"945","Sales Value":"119762","Distribution":"20.81","Cost of Sales":"304.27","Price":"126.73","Gross Profit":"119457.73","Indirect Costs":"111530.79","Operating Profit":"7926.94","Unit Sales Monthly Change":"945","Sales Value Monthly Change":"119762","Distribution Monthly Change":"20.81","Cost of Sales Monthly Change":"304.27","Price Monthly Change":"126.73","Gross Profit Monthly Change":"119457.73","Indirect Costs Monthly Change":"111530.79","Operating Profit Monthly Change":"7926.94"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Beta 12 Pack Deluxe","Price Tier":"Premium","Unit Sales":"485","Sales Value":"59689","Distribution":"12.16","Cost of Sales":"151.64","Price":"123.07","Gross Profit":"59537.36","Indirect Costs":"55586.31","Operating Profit":"3951.05","Unit Sales Monthly Change":"485","Sales Value Monthly Change":"59689","Distribution Monthly Change":"12.16","Cost of Sales Monthly Change":"151.64","Price Monthly Change":"123.07","Gross Profit Monthly Change":"59537.36","Indirect Costs Monthly Change":"55586.31","Operating Profit Monthly Change":"3951.05"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Giftset","SKU":"Beta 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"930","Sales Value":"120709","Distribution":"18.22","Cost of Sales":"306.67","Price":"129.79","Gross Profit":"120402.33","Indirect Costs":"112413.08","Operating Profit":"7989.25","Unit Sales Monthly Change":"930","Sales Value Monthly Change":"120709","Distribution Monthly Change":"18.22","Cost of Sales Monthly Change":"306.67","Price Monthly Change":"129.79","Gross Profit Monthly Change":"120402.33","Indirect Costs Monthly Change":"112413.08","Operating Profit Monthly Change":"7989.25"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Standard","SKU":"Beta 12 Pack Standard","Price Tier":"Premium","Unit Sales":"6137","Sales Value":"628434","Distribution":"34.02","Cost of Sales":"1596.6","Price":"102.4","Gross Profit":"626837.4","Indirect Costs":"585242.87","Operating Profit":"41594.53","Unit Sales Monthly Change":"6137","Sales Value Monthly Change":"628434","Distribution Monthly Change":"34.02","Cost of Sales Monthly Change":"1596.6","Price Monthly Change":"102.4","Gross Profit Monthly Change":"626837.4","Indirect Costs Monthly Change":"585242.87","Operating Profit Monthly Change":"41594.53"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"18","Pack Type":"Standard","SKU":"Beta 18 Pack Standard","Price Tier":"Premium","Unit Sales":"1915","Sales Value":"185317","Distribution":"17.06","Cost of Sales":"470.81","Price":"96.77","Gross Profit":"184846.19","Indirect Costs":"172580.12","Operating Profit":"12266.07","Unit Sales Monthly Change":"1915","Sales Value Monthly Change":"185317","Distribution Monthly Change":"17.06","Cost of Sales Monthly Change":"470.81","Price Monthly Change":"96.77","Gross Profit Monthly Change":"184846.19","Indirect Costs Monthly Change":"172580.12","Operating Profit Monthly Change":"12266.07"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"60","Pack Type":"Standard","SKU":"Beta 60 Pack Standard","Price Tier":"Premium","Unit Sales":"107","Sales Value":"13445","Distribution":"2.39","Cost of Sales":"34.16","Price":"125.65","Gross Profit":"13410.84","Indirect Costs":"12520.76","Operating Profit":"890.08","Unit Sales Monthly Change":"107","Sales Value Monthly Change":"13445","Distribution Monthly Change":"2.39","Cost of Sales Monthly Change":"34.16","Price Monthly Change":"125.65","Gross Profit Monthly Change":"13410.84","Indirect Costs Monthly Change":"12520.76","Operating Profit Monthly Change":"890.08"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Stark Ind","Brand":"Omega","Pack Size":"12","Pack Type":"Standard","SKU":"Omega 12 Pack Standard","Price Tier":"Budget","Unit Sales":"233","Sales Value":"15511","Distribution":"4.15","Cost of Sales":"39.41","Price":"66.57","Gross Profit":"15471.59","Indirect Costs":"14444.58","Operating Profit":"1027.01","Unit Sales Monthly Change":"233","Sales Value Monthly Change":"15511","Distribution Monthly Change":"4.15","Cost of Sales Monthly Change":"39.41","Price Monthly Change":"66.57","Gross Profit Monthly Change":"15471.59","Indirect Costs Monthly Change":"14444.58","Operating Profit Monthly Change":"1027.01"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"8","Pack Type":"Standard","SKU":"Kappa 8 Pack Standard","Price Tier":"Regular","Unit Sales":"776","Sales Value":"69099","Distribution":"19.87","Cost of Sales":"175.55","Price":"89.05","Gross Profit":"68923.45","Indirect Costs":"64349.95","Operating Profit":"4573.5","Unit Sales Monthly Change":"776","Sales Value Monthly Change":"69099","Distribution Monthly Change":"19.87","Cost of Sales Monthly Change":"175.55","Price Monthly Change":"89.05","Gross Profit Monthly Change":"68923.45","Indirect Costs Monthly Change":"64349.95","Operating Profit Monthly Change":"4573.5"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"12","Pack Type":"Standard","SKU":"Kappa 12 Pack Standard","Price Tier":"Regular","Unit Sales":"2216","Sales Value":"166212","Distribution":"26.44","Cost of Sales":"422.28","Price":"75.01","Gross Profit":"165789.72","Indirect Costs":"154788.55","Operating Profit":"11001.17","Unit Sales Monthly Change":"2216","Sales Value Monthly Change":"166212","Distribution Monthly Change":"26.44","Cost of Sales Monthly Change":"422.28","Price Monthly Change":"75.01","Gross Profit Monthly Change":"165789.72","Indirect Costs Monthly Change":"154788.55","Operating Profit Monthly Change":"11001.17"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"18","Pack Type":"Standard","SKU":"Kappa 18 Pack Standard","Price Tier":"Regular","Unit Sales":"927","Sales Value":"68194","Distribution":"12.49","Cost of Sales":"173.26","Price":"73.56","Gross Profit":"68020.74","Indirect Costs":"63507.34","Operating Profit":"4513.4","Unit Sales Monthly Change":"927","Sales Value Monthly Change":"68194","Distribution Monthly Change":"12.49","Cost of Sales Monthly Change":"173.26","Price Monthly Change":"73.56","Gross Profit Monthly Change":"68020.74","Indirect Costs Monthly Change":"63507.34","Operating Profit Monthly Change":"4513.4"}
,{"Date":"01/01/2011","Month":"Jan-11","Channel":"Supermarkets","Owner":"Wayne Ent","Brand":"Pi","Pack Size":"12","Pack Type":"Giftset","SKU":"Pi 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"188","Sales Value":"15899","Distribution":"5.74","Cost of Sales":"40.39","Price":"84.57","Gross Profit":"15858.61","Indirect Costs":"14806.66","Operating Profit":"1051.95","Unit Sales Monthly Change":"188","Sales Value Monthly Change":"15899","Distribution Monthly Change":"5.74","Cost of Sales Monthly Change":"40.39","Price Monthly Change":"84.57","Gross Profit Monthly Change":"15858.61","Indirect Costs Monthly Change":"14806.66","Operating Profit Monthly Change":"1051.95"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Delta","Pack Size":"12","Pack Type":"Standard","SKU":"Delta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1997","Sales Value":"110395","Distribution":"96.71","Cost of Sales":"280.47","Price":"55.28","Gross Profit":"110114.53","Indirect Costs":"102807.94","Operating Profit":"7306.59","Unit Sales Monthly Change":"232","Sales Value Monthly Change":"14951","Distribution Monthly Change":"-0.54","Cost of Sales Monthly Change":"37.99","Price Monthly Change":"1.2","Gross Profit Monthly Change":"14913.01","Indirect Costs Monthly Change":"13923.82","Operating Profit Monthly Change":"989.19"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Eta","Pack Size":"12","Pack Type":"Standard","SKU":"Eta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"698","Sales Value":"33109","Distribution":"15.11","Cost of Sales":"84.11","Price":"47.43","Gross Profit":"33024.89","Indirect Costs":"30833.11","Operating Profit":"2191.78","Unit Sales Monthly Change":"25","Sales Value Monthly Change":"1179","Distribution Monthly Change":"1.7","Cost of Sales Monthly Change":"2.99","Price Monthly Change":"-0.01","Gross Profit Monthly Change":"1176.01","Indirect Costs Monthly Change":"1097.97","Operating Profit Monthly Change":"78.04"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"8","Pack Type":"Standard","SKU":"Omicron 8 Pack Standard","Price Tier":"Regular","Unit Sales":"1194","Sales Value":"99437","Distribution":"99.63","Cost of Sales":"252.63","Price":"83.28","Gross Profit":"99184.37","Indirect Costs":"92602.69","Operating Profit":"6581.68","Unit Sales Monthly Change":"94","Sales Value Monthly Change":"7917","Distribution Monthly Change":"0.47","Cost of Sales Monthly Change":"20.11","Price Monthly Change":"0.08","Gross Profit Monthly Change":"7896.89","Indirect Costs Monthly Change":"7372.32","Operating Profit Monthly Change":"524.57"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Deluxe","SKU":"Omicron 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"513","Sales Value":"44993","Distribution":"92.4","Cost of Sales":"114.31","Price":"87.71","Gross Profit":"44878.69","Indirect Costs":"41901.08","Operating Profit":"2977.61","Unit Sales Monthly Change":"-35","Sales Value Monthly Change":"-3911","Distribution Monthly Change":"2.72","Cost of Sales Monthly Change":"-9.93","Price Monthly Change":"-1.53","Gross Profit Monthly Change":"-3901.07","Indirect Costs Monthly Change":"-3641.46","Operating Profit Monthly Change":"-259.61"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Giftset","SKU":"Omicron 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"2622","Sales Value":"232062","Distribution":"99.33","Cost of Sales":"589.58","Price":"88.51","Gross Profit":"231472.42","Indirect Costs":"216112.8","Operating Profit":"15359.62","Unit Sales Monthly Change":"-685","Sales Value Monthly Change":"-37405","Distribution Monthly Change":"1.14","Cost of Sales Monthly Change":"-95.03","Price Monthly Change":"7.03","Gross Profit Monthly Change":"-37309.97","Indirect Costs Monthly Change":"-34833.85","Operating Profit Monthly Change":"-2476.12"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Standard","SKU":"Omicron 12 Pack Standard","Price Tier":"Regular","Unit Sales":"6954","Sales Value":"506628","Distribution":"99.95","Cost of Sales":"1287.14","Price":"72.85","Gross Profit":"505340.86","Indirect Costs":"471808.37","Operating Profit":"33532.49","Unit Sales Monthly Change":"-2642","Sales Value Monthly Change":"-155666","Distribution Monthly Change":"0.43","Cost of Sales Monthly Change":"-395.49","Price Monthly Change":"3.83","Gross Profit Monthly Change":"-155270.51","Indirect Costs Monthly Change":"-144967.17","Operating Profit Monthly Change":"-10303.34"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"18","Pack Type":"Standard","SKU":"Omicron 18 Pack Standard","Price Tier":"Regular","Unit Sales":"5454","Sales Value":"370063","Distribution":"97.59","Cost of Sales":"940.18","Price":"67.85","Gross Profit":"369122.82","Indirect Costs":"344628.86","Operating Profit":"24493.96","Unit Sales Monthly Change":"-1175","Sales Value Monthly Change":"-39549","Distribution Monthly Change":"1.31","Cost of Sales Monthly Change":"-100.48","Price Monthly Change":"6.06","Gross Profit Monthly Change":"-39448.52","Indirect Costs Monthly Change":"-36830.88","Operating Profit Monthly Change":"-2617.64"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Giftset","SKU":"Sigma 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"736","Sales Value":"120790","Distribution":"93.77","Cost of Sales":"306.88","Price":"164.12","Gross Profit":"120483.12","Indirect Costs":"112487.95","Operating Profit":"7995.17","Unit Sales Monthly Change":"41","Sales Value Monthly Change":"15042","Distribution Monthly Change":"22.59","Cost of Sales Monthly Change":"38.22","Price Monthly Change":"11.96","Gross Profit Monthly Change":"15003.78","Indirect Costs Monthly Change":"14007.63","Operating Profit Monthly Change":"996.15"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Standard","SKU":"Sigma 12 Pack Standard","Price Tier":"Premium","Unit Sales":"763","Sales Value":"111529","Distribution":"95.87","Cost of Sales":"283.35","Price":"146.17","Gross Profit":"111245.65","Indirect Costs":"103864","Operating Profit":"7381.65","Unit Sales Monthly Change":"56","Sales Value Monthly Change":"9579","Distribution Monthly Change":"3.68","Cost of Sales Monthly Change":"24.34","Price Monthly Change":"1.97","Gross Profit Monthly Change":"9554.66","Indirect Costs Monthly Change":"8920.65","Operating Profit Monthly Change":"634.01"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Aperture","Brand":"Tau","Pack Size":"12","Pack Type":"Standard","SKU":"Tau 12 Pack Standard","Price Tier":"Regular","Unit Sales":"1164","Sales Value":"78391","Distribution":"81.15","Cost of Sales":"199.16","Price":"67.35","Gross Profit":"78191.84","Indirect Costs":"73003.52","Operating Profit":"5188.32","Unit Sales Monthly Change":"54","Sales Value Monthly Change":"7436","Distribution Monthly Change":"-2.23","Cost of Sales Monthly Change":"18.89","Price Monthly Change":"3.43","Gross Profit Monthly Change":"7417.11","Indirect Costs Monthly Change":"6925.32","Operating Profit Monthly Change":"491.79"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Epsilon","Pack Size":"12","Pack Type":"Standard","SKU":"Epsilon 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1213","Sales Value":"63185","Distribution":"81.12","Cost of Sales":"160.53","Price":"52.09","Gross Profit":"63024.47","Indirect Costs":"58842.22","Operating Profit":"4182.25","Unit Sales Monthly Change":"6","Sales Value Monthly Change":"-29","Distribution Monthly Change":"-0.95","Cost of Sales Monthly Change":"-0.07","Price Monthly Change":"-0.28","Gross Profit Monthly Change":"-28.93","Indirect Costs Monthly Change":"-27.38","Operating Profit Monthly Change":"-1.55"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Giftset","SKU":"Iota 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"1253","Sales Value":"109962","Distribution":"93.01","Cost of Sales":"279.37","Price":"87.76","Gross Profit":"109682.63","Indirect Costs":"102404.51","Operating Profit":"7278.12","Unit Sales Monthly Change":"643","Sales Value Monthly Change":"54232","Distribution Monthly Change":"-0.9","Cost of Sales Monthly Change":"137.78","Price Monthly Change":"-3.6","Gross Profit Monthly Change":"54094.22","Indirect Costs Monthly Change":"50504.92","Operating Profit Monthly Change":"3589.3"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Standard","SKU":"Iota 12 Pack Standard","Price Tier":"Regular","Unit Sales":"840","Sales Value":"71146","Distribution":"92.9","Cost of Sales":"180.75","Price":"84.7","Gross Profit":"70965.25","Indirect Costs":"66255.89","Operating Profit":"4709.36","Unit Sales Monthly Change":"-256","Sales Value Monthly Change":"-18933","Distribution Monthly Change":"-2.79","Cost of Sales Monthly Change":"-48.1","Price Monthly Change":"2.51","Gross Profit Monthly Change":"-18884.9","Indirect Costs Monthly Change":"-17631.77","Operating Profit Monthly Change":"-1253.13"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"8","Pack Type":"Standard","SKU":"Lambda 8 Pack Standard","Price Tier":"Budget","Unit Sales":"758","Sales Value":"46438","Distribution":"70.69","Cost of Sales":"117.98","Price":"61.26","Gross Profit":"46320.02","Indirect Costs":"43246.03","Operating Profit":"3073.99","Unit Sales Monthly Change":"289","Sales Value Monthly Change":"15498","Distribution Monthly Change":"-3.13","Cost of Sales Monthly Change":"39.37","Price Monthly Change":"-4.71","Gross Profit Monthly Change":"15458.63","Indirect Costs Monthly Change":"14432.3","Operating Profit Monthly Change":"1026.33"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"12","Pack Type":"Standard","SKU":"Lambda 12 Pack Standard","Price Tier":"Budget","Unit Sales":"4202","Sales Value":"226134","Distribution":"99.53","Cost of Sales":"574.52","Price":"53.82","Gross Profit":"225559.48","Indirect Costs":"210592.22","Operating Profit":"14967.26","Unit Sales Monthly Change":"1254","Sales Value Monthly Change":"57661","Distribution Monthly Change":"0.05","Cost of Sales Monthly Change":"146.5","Price Monthly Change":"-3.33","Gross Profit Monthly Change":"57514.5","Indirect Costs Monthly Change":"53697.69","Operating Profit Monthly Change":"3816.81"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Mu","Pack Size":"12","Pack Type":"Standard","SKU":"Mu 12 Pack Standard","Price Tier":"Premium","Unit Sales":"206","Sales Value":"30985","Distribution":"49.79","Cost of Sales":"78.72","Price":"150.41","Gross Profit":"30906.28","Indirect Costs":"28855.09","Operating Profit":"2051.19","Unit Sales Monthly Change":"101","Sales Value Monthly Change":"14111","Distribution Monthly Change":"24.34","Cost of Sales Monthly Change":"35.85","Price Monthly Change":"-10.29","Gross Profit Monthly Change":"14075.15","Indirect Costs Monthly Change":"13140.44","Operating Profit Monthly Change":"934.71"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"6","Pack Type":"Standard","SKU":"Theta 6 Pack Standard","Price Tier":"Regular","Unit Sales":"176","Sales Value":"17145","Distribution":"20.39","Cost of Sales":"43.56","Price":"97.41","Gross Profit":"17101.44","Indirect Costs":"15966.65","Operating Profit":"1134.79","Unit Sales Monthly Change":"43","Sales Value Monthly Change":"4154","Distribution Monthly Change":"3.94","Cost of Sales Monthly Change":"10.55","Price Monthly Change":"-0.27","Gross Profit Monthly Change":"4143.45","Indirect Costs Monthly Change":"3868.31","Operating Profit Monthly Change":"275.14"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"8","Pack Type":"Standard","SKU":"Theta 8 Pack Standard","Price Tier":"Regular","Unit Sales":"832","Sales Value":"73745","Distribution":"98.46","Cost of Sales":"187.36","Price":"88.64","Gross Profit":"73557.64","Indirect Costs":"68676.46","Operating Profit":"4881.18","Unit Sales Monthly Change":"-58","Sales Value Monthly Change":"-4152","Distribution Monthly Change":"-0.88","Cost of Sales Monthly Change":"-10.54","Price Monthly Change":"1.12","Gross Profit Monthly Change":"-4141.46","Indirect Costs Monthly Change":"-3866.64","Operating Profit Monthly Change":"-274.82"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Theta 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"1184","Sales Value":"93041","Distribution":"94.29","Cost of Sales":"236.38","Price":"78.58","Gross Profit":"92804.62","Indirect Costs":"86646.83","Operating Profit":"6157.79","Unit Sales Monthly Change":"-509","Sales Value Monthly Change":"-37508","Distribution Monthly Change":"-0.26","Cost of Sales Monthly Change":"-95.29","Price Monthly Change":"1.47","Gross Profit Monthly Change":"-37412.71","Indirect Costs Monthly Change":"-34929.4","Operating Profit Monthly Change":"-2483.31"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Giftset","SKU":"Theta 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"4069","Sales Value":"338565","Distribution":"98.44","Cost of Sales":"860.16","Price":"83.21","Gross Profit":"337704.84","Indirect Costs":"315296.04","Operating Profit":"22408.8","Unit Sales Monthly Change":"-2554","Sales Value Monthly Change":"-167641","Distribution Monthly Change":"-0.98","Cost of Sales Monthly Change":"-425.91","Price Monthly Change":"6.78","Gross Profit Monthly Change":"-167215.09","Indirect Costs Monthly Change":"-156119.52","Operating Profit Monthly Change":"-11095.57"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Standard","SKU":"Theta 12 Pack Standard","Price Tier":"Regular","Unit Sales":"7652","Sales Value":"545132","Distribution":"99.58","Cost of Sales":"1384.97","Price":"71.24","Gross Profit":"543747.03","Indirect Costs":"507666.43","Operating Profit":"36080.6","Unit Sales Monthly Change":"3138","Sales Value Monthly Change":"216421","Distribution Monthly Change":"-0.42","Cost of Sales Monthly Change":"549.85","Price Monthly Change":"-1.58","Gross Profit Monthly Change":"215871.15","Indirect Costs Monthly Change":"201547.52","Operating Profit Monthly Change":"14323.63"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"18","Pack Type":"Standard","SKU":"Theta 18 Pack Standard","Price Tier":"Regular","Unit Sales":"17552","Sales Value":"1059934","Distribution":"98.94","Cost of Sales":"2692.87","Price":"60.39","Gross Profit":"1057241.13","Indirect Costs":"987086.28","Operating Profit":"70154.85","Unit Sales Monthly Change":"958","Sales Value Monthly Change":"60599","Distribution Monthly Change":"0.55","Cost of Sales Monthly Change":"153.96","Price Monthly Change":"0.17","Gross Profit Monthly Change":"60445.04","Indirect Costs Monthly Change":"56433.4","Operating Profit Monthly Change":"4011.64"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"LexCorp","Brand":"Gamma","Pack Size":"12","Pack Type":"Standard","SKU":"Gamma 12 Pack Standard","Price Tier":"Budget","Unit Sales":"3179","Sales Value":"197648","Distribution":"99.02","Cost of Sales":"502.15","Price":"62.17","Gross Profit":"197145.85","Indirect Costs":"184063.82","Operating Profit":"13082.03","Unit Sales Monthly Change":"579","Sales Value Monthly Change":"35103","Distribution Monthly Change":"0.69","Cost of Sales Monthly Change":"89.19","Price Monthly Change":"-0.35","Gross Profit Monthly Change":"35013.81","Indirect Costs Monthly Change":"32689.87","Operating Profit Monthly Change":"2323.94"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"12","Pack Type":"Standard","SKU":"Alpha 12 Pack Standard","Price Tier":"Regular","Unit Sales":"413","Sales Value":"39449","Distribution":"67.07","Cost of Sales":"100.22","Price":"95.52","Gross Profit":"39348.78","Indirect Costs":"36738.11","Operating Profit":"2610.67","Unit Sales Monthly Change":"17","Sales Value Monthly Change":"3894","Distribution Monthly Change":"-3.71","Cost of Sales Monthly Change":"9.89","Price Monthly Change":"5.73","Gross Profit Monthly Change":"3884.11","Indirect Costs Monthly Change":"3626.92","Operating Profit Monthly Change":"257.19"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"18","Pack Type":"Standard","SKU":"Alpha 18 Pack Standard","Price Tier":"Regular","Unit Sales":"1602","Sales Value":"119902","Distribution":"93.4","Cost of Sales":"304.63","Price":"74.85","Gross Profit":"119597.37","Indirect Costs":"111661.54","Operating Profit":"7935.83","Unit Sales Monthly Change":"27","Sales Value Monthly Change":"5228","Distribution Monthly Change":"1.21","Cost of Sales Monthly Change":"13.29","Price Monthly Change":"2.04","Gross Profit Monthly Change":"5214.71","Indirect Costs Monthly Change":"4869.06","Operating Profit Monthly Change":"345.65"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"8","Pack Type":"Standard","SKU":"Beta 8 Pack Standard","Price Tier":"Premium","Unit Sales":"1004","Sales Value":"112577","Distribution":"99.61","Cost of Sales":"286.01","Price":"112.13","Gross Profit":"112290.99","Indirect Costs":"104840.16","Operating Profit":"7450.83","Unit Sales Monthly Change":"269","Sales Value Monthly Change":"28553","Distribution Monthly Change":"7.33","Cost of Sales Monthly Change":"72.54","Price Monthly Change":"-2.19","Gross Profit Monthly Change":"28480.46","Indirect Costs Monthly Change":"26590.98","Operating Profit Monthly Change":"1889.48"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Beta 12 Pack Deluxe","Price Tier":"Premium","Unit Sales":"617","Sales Value":"72914","Distribution":"67.73","Cost of Sales":"185.24","Price":"118.18","Gross Profit":"72728.76","Indirect Costs":"67902.57","Operating Profit":"4826.19","Unit Sales Monthly Change":"-71","Sales Value Monthly Change":"-6973","Distribution Monthly Change":"3.64","Cost of Sales Monthly Change":"-17.72","Price Monthly Change":"2.07","Gross Profit Monthly Change":"-6955.28","Indirect Costs Monthly Change":"-6493.94","Operating Profit Monthly Change":"-461.34"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Giftset","SKU":"Beta 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"1919","Sales Value":"224247","Distribution":"95.87","Cost of Sales":"569.72","Price":"116.86","Gross Profit":"223677.28","Indirect Costs":"208834.91","Operating Profit":"14842.37","Unit Sales Monthly Change":"192","Sales Value Monthly Change":"26324","Distribution Monthly Change":"0.25","Cost of Sales Monthly Change":"66.88","Price Monthly Change":"2.25","Gross Profit Monthly Change":"26257.12","Indirect Costs Monthly Change":"24514.61","Operating Profit Monthly Change":"1742.51"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"12","Pack Type":"Standard","SKU":"Beta 12 Pack Standard","Price Tier":"Premium","Unit Sales":"4353","Sales Value":"438765","Distribution":"99.02","Cost of Sales":"1114.73","Price":"100.8","Gross Profit":"437650.27","Indirect Costs":"408609.47","Operating Profit":"29040.8","Unit Sales Monthly Change":"-3030","Sales Value Monthly Change":"-275084","Distribution Monthly Change":"-0.18","Cost of Sales Monthly Change":"-698.88","Price Monthly Change":"4.11","Gross Profit Monthly Change":"-274385.12","Indirect Costs Monthly Change":"-256178.35","Operating Profit Monthly Change":"-18206.77"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"18","Pack Type":"Standard","SKU":"Beta 18 Pack Standard","Price Tier":"Premium","Unit Sales":"3677","Sales Value":"348833","Distribution":"95.31","Cost of Sales":"886.25","Price":"94.87","Gross Profit":"347946.75","Indirect Costs":"324858.15","Operating Profit":"23088.6","Unit Sales Monthly Change":"-417","Sales Value Monthly Change":"-23967","Distribution Monthly Change":"-1.5","Cost of Sales Monthly Change":"-60.89","Price Monthly Change":"3.81","Gross Profit Monthly Change":"-23906.11","Indirect Costs Monthly Change":"-22319.8","Operating Profit Monthly Change":"-1586.31"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Rekall","Brand":"Beta","Pack Size":"60","Pack Type":"Standard","SKU":"Beta 60 Pack Standard","Price Tier":"Premium","Unit Sales":"679","Sales Value":"70635","Distribution":"46.41","Cost of Sales":"179.45","Price":"104.03","Gross Profit":"70455.55","Indirect Costs":"65780.39","Operating Profit":"4675.16","Unit Sales Monthly Change":"-214","Sales Value Monthly Change":"-19639","Distribution Monthly Change":"-7.98","Cost of Sales Monthly Change":"-49.9","Price Monthly Change":"2.94","Gross Profit Monthly Change":"-19589.1","Indirect Costs Monthly Change":"-18288.87","Operating Profit Monthly Change":"-1300.23"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Stark Ind","Brand":"Omega","Pack Size":"12","Pack Type":"Standard","SKU":"Omega 12 Pack Standard","Price Tier":"Budget","Unit Sales":"928","Sales Value":"54749","Distribution":"67.19","Cost of Sales":"139.1","Price":"59","Gross Profit":"54609.9","Indirect Costs":"50986.57","Operating Profit":"3623.33","Unit Sales Monthly Change":"-51","Sales Value Monthly Change":"-1632","Distribution Monthly Change":"-4.84","Cost of Sales Monthly Change":"-4.14","Price Monthly Change":"1.41","Gross Profit Monthly Change":"-1627.86","Indirect Costs Monthly Change":"-1519.27","Operating Profit Monthly Change":"-108.59"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"8","Pack Type":"Standard","SKU":"Kappa 8 Pack Standard","Price Tier":"Regular","Unit Sales":"886","Sales Value":"71740","Distribution":"97.31","Cost of Sales":"182.26","Price":"80.97","Gross Profit":"71557.74","Indirect Costs":"66809.06","Operating Profit":"4748.68","Unit Sales Monthly Change":"14","Sales Value Monthly Change":"3257","Distribution Monthly Change":"0.81","Cost of Sales Monthly Change":"8.27","Price Monthly Change":"2.43","Gross Profit Monthly Change":"3248.73","Indirect Costs Monthly Change":"3032.4","Operating Profit Monthly Change":"216.33"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"12","Pack Type":"Standard","SKU":"Kappa 12 Pack Standard","Price Tier":"Regular","Unit Sales":"2183","Sales Value":"155881","Distribution":"98.73","Cost of Sales":"396.03","Price":"71.41","Gross Profit":"155484.97","Indirect Costs":"145167.21","Operating Profit":"10317.76","Unit Sales Monthly Change":"292","Sales Value Monthly Change":"21135","Distribution Monthly Change":"1.93","Cost of Sales Monthly Change":"53.69","Price Monthly Change":"0.15","Gross Profit Monthly Change":"21081.31","Indirect Costs Monthly Change":"19681.87","Operating Profit Monthly Change":"1399.44"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Tyrell Corp","Brand":"Kappa","Pack Size":"18","Pack Type":"Standard","SKU":"Kappa 18 Pack Standard","Price Tier":"Regular","Unit Sales":"3071","Sales Value":"203151","Distribution":"96.97","Cost of Sales":"516.13","Price":"66.15","Gross Profit":"202634.87","Indirect Costs":"189188.8","Operating Profit":"13446.07","Unit Sales Monthly Change":"4","Sales Value Monthly Change":"-347","Distribution Monthly Change":"0.34","Cost of Sales Monthly Change":"-0.88","Price Monthly Change":"-0.2","Gross Profit Monthly Change":"-346.12","Indirect Costs Monthly Change":"-323.52","Operating Profit Monthly Change":"-22.6"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Hypermarkets","Owner":"Wayne Ent","Brand":"Pi","Pack Size":"12","Pack Type":"Giftset","SKU":"Pi 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"818","Sales Value":"63784","Distribution":"61.2","Cost of Sales":"162.05","Price":"77.98","Gross Profit":"63621.95","Indirect Costs":"59399.87","Operating Profit":"4222.08","Unit Sales Monthly Change":"14","Sales Value Monthly Change":"1593","Distribution Monthly Change":"-18.28","Cost of Sales Monthly Change":"4.05","Price Monthly Change":"0.63","Gross Profit Monthly Change":"1588.95","Indirect Costs Monthly Change":"1483.52","Operating Profit Monthly Change":"105.43"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Delta","Pack Size":"12","Pack Type":"Standard","SKU":"Delta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"726","Sales Value":"45149","Distribution":"22.07","Cost of Sales":"114.71","Price":"62.19","Gross Profit":"45034.29","Indirect Costs":"42045.8","Operating Profit":"2988.49","Unit Sales Monthly Change":"-112","Sales Value Monthly Change":"-5341","Distribution Monthly Change":"2.99","Cost of Sales Monthly Change":"-13.56","Price Monthly Change":"1.94","Gross Profit Monthly Change":"-5327.44","Indirect Costs Monthly Change":"-4974.11","Operating Profit Monthly Change":"-353.33"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Eta","Pack Size":"12","Pack Type":"Standard","SKU":"Eta 12 Pack Standard","Price Tier":"Budget","Unit Sales":"791","Sales Value":"37562","Distribution":"5.06","Cost of Sales":"95.43","Price":"47.49","Gross Profit":"37466.57","Indirect Costs":"34980.25","Operating Profit":"2486.32","Unit Sales Monthly Change":"39","Sales Value Monthly Change":"1846","Distribution Monthly Change":"0.91","Cost of Sales Monthly Change":"4.69","Price Monthly Change":"0","Gross Profit Monthly Change":"1841.31","Indirect Costs Monthly Change":"1718.76","Operating Profit Monthly Change":"122.55"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"8","Pack Type":"Standard","SKU":"Omicron 8 Pack Standard","Price Tier":"Regular","Unit Sales":"15457","Sales Value":"1122737","Distribution":"49.26","Cost of Sales":"2852.43","Price":"72.64","Gross Profit":"1119884.57","Indirect Costs":"1045573.69","Operating Profit":"74310.88","Unit Sales Monthly Change":"-3136","Sales Value Monthly Change":"-216549","Distribution Monthly Change":"-1.22","Cost of Sales Monthly Change":"-550.16","Price Monthly Change":"0.61","Gross Profit Monthly Change":"-215998.84","Indirect Costs Monthly Change":"-201665.42","Operating Profit Monthly Change":"-14333.42"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Deluxe","SKU":"Omicron 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"527","Sales Value":"51760","Distribution":"14.9","Cost of Sales":"131.5","Price":"98.22","Gross Profit":"51628.5","Indirect Costs":"48202.25","Operating Profit":"3426.25","Unit Sales Monthly Change":"144","Sales Value Monthly Change":"14133","Distribution Monthly Change":"4.94","Cost of Sales Monthly Change":"35.9","Price Monthly Change":"-0.02","Gross Profit Monthly Change":"14097.1","Indirect Costs Monthly Change":"13161.1","Operating Profit Monthly Change":"936"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Giftset","SKU":"Omicron 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"2852","Sales Value":"256844","Distribution":"37.57","Cost of Sales":"652.54","Price":"90.06","Gross Profit":"256191.46","Indirect Costs":"239191.94","Operating Profit":"16999.52","Unit Sales Monthly Change":"-979","Sales Value Monthly Change":"-74941","Distribution Monthly Change":"4.05","Cost of Sales Monthly Change":"-190.39","Price Monthly Change":"3.45","Gross Profit Monthly Change":"-74750.61","Indirect Costs Monthly Change":"-69790.08","Operating Profit Monthly Change":"-4960.53"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"12","Pack Type":"Standard","SKU":"Omicron 12 Pack Standard","Price Tier":"Regular","Unit Sales":"8693","Sales Value":"667219","Distribution":"44.16","Cost of Sales":"1695.14","Price":"76.75","Gross Profit":"665523.86","Indirect Costs":"621361.87","Operating Profit":"44161.99","Unit Sales Monthly Change":"-1512","Sales Value Monthly Change":"-65604","Distribution Monthly Change":"7.52","Cost of Sales Monthly Change":"-166.67","Price Monthly Change":"4.94","Gross Profit Monthly Change":"-65437.33","Indirect Costs Monthly Change":"-61095.72","Operating Profit Monthly Change":"-4341.61"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Omicron","Pack Size":"18","Pack Type":"Standard","SKU":"Omicron 18 Pack Standard","Price Tier":"Regular","Unit Sales":"4454","Sales Value":"324632","Distribution":"36.72","Cost of Sales":"824.76","Price":"72.89","Gross Profit":"323807.24","Indirect Costs":"302320.45","Operating Profit":"21486.79","Unit Sales Monthly Change":"-339","Sales Value Monthly Change":"7887","Distribution Monthly Change":"8.75","Cost of Sales Monthly Change":"20.03","Price Monthly Change":"6.81","Gross Profit Monthly Change":"7866.97","Indirect Costs Monthly Change":"7344.39","Operating Profit Monthly Change":"522.58"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Giftset","SKU":"Sigma 12 Pack Giftset","Price Tier":"Premium","Unit Sales":"478","Sales Value":"83969","Distribution":"17.33","Cost of Sales":"213.33","Price":"175.67","Gross Profit":"83755.67","Indirect Costs":"78197.78","Operating Profit":"5557.89","Unit Sales Monthly Change":"132","Sales Value Monthly Change":"24159","Distribution Monthly Change":"6.34","Cost of Sales Monthly Change":"61.37","Price Monthly Change":"2.81","Gross Profit Monthly Change":"24097.63","Indirect Costs Monthly Change":"22498.04","Operating Profit Monthly Change":"1599.59"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Sigma","Pack Size":"12","Pack Type":"Standard","SKU":"Sigma 12 Pack Standard","Price Tier":"Premium","Unit Sales":"475","Sales Value":"74834","Distribution":"16.68","Cost of Sales":"190.12","Price":"157.55","Gross Profit":"74643.88","Indirect Costs":"69690.61","Operating Profit":"4953.27","Unit Sales Monthly Change":"-157","Sales Value Monthly Change":"-25000","Distribution Monthly Change":"1.08","Cost of Sales Monthly Change":"-63.52","Price Monthly Change":"-0.42","Gross Profit Monthly Change":"-24936.48","Indirect Costs Monthly Change":"-23281.98","Operating Profit Monthly Change":"-1654.5"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Aperture","Brand":"Tau","Pack Size":"12","Pack Type":"Standard","SKU":"Tau 12 Pack Standard","Price Tier":"Regular","Unit Sales":"347","Sales Value":"25478","Distribution":"13.98","Cost of Sales":"64.73","Price":"73.42","Gross Profit":"25413.27","Indirect Costs":"23726.76","Operating Profit":"1686.51","Unit Sales Monthly Change":"-114","Sales Value Monthly Change":"-6561","Distribution Monthly Change":"2.11","Cost of Sales Monthly Change":"-16.67","Price Monthly Change":"3.92","Gross Profit Monthly Change":"-6544.33","Indirect Costs Monthly Change":"-6110.07","Operating Profit Monthly Change":"-434.26"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Epsilon","Pack Size":"12","Pack Type":"Standard","SKU":"Epsilon 12 Pack Standard","Price Tier":"Budget","Unit Sales":"715","Sales Value":"40157","Distribution":"15.27","Cost of Sales":"102.02","Price":"56.16","Gross Profit":"40054.98","Indirect Costs":"37396.9","Operating Profit":"2658.08","Unit Sales Monthly Change":"-52","Sales Value Monthly Change":"-3182","Distribution Monthly Change":"3.35","Cost of Sales Monthly Change":"-8.09","Price Monthly Change":"-0.34","Gross Profit Monthly Change":"-3173.91","Indirect Costs Monthly Change":"-2963.11","Operating Profit Monthly Change":"-210.8"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Giftset","SKU":"Iota 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"1342","Sales Value":"117680","Distribution":"18.82","Cost of Sales":"298.98","Price":"87.69","Gross Profit":"117381.02","Indirect Costs":"109591.88","Operating Profit":"7789.14","Unit Sales Monthly Change":"614","Sales Value Monthly Change":"50721","Distribution Monthly Change":"3.65","Cost of Sales Monthly Change":"128.86","Price Monthly Change":"-4.29","Gross Profit Monthly Change":"50592.14","Indirect Costs Monthly Change":"47234.48","Operating Profit Monthly Change":"3357.66"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Iota","Pack Size":"12","Pack Type":"Standard","SKU":"Iota 12 Pack Standard","Price Tier":"Regular","Unit Sales":"601","Sales Value":"53853","Distribution":"15.41","Cost of Sales":"136.82","Price":"89.61","Gross Profit":"53716.18","Indirect Costs":"50151.78","Operating Profit":"3564.4","Unit Sales Monthly Change":"38","Sales Value Monthly Change":"3154","Distribution Monthly Change":"1.69","Cost of Sales Monthly Change":"8.01","Price Monthly Change":"-0.44","Gross Profit Monthly Change":"3145.99","Indirect Costs Monthly Change":"2937.42","Operating Profit Monthly Change":"208.57"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"8","Pack Type":"Standard","SKU":"Lambda 8 Pack Standard","Price Tier":"Budget","Unit Sales":"418","Sales Value":"29113","Distribution":"13.07","Cost of Sales":"73.97","Price":"69.65","Gross Profit":"29039.03","Indirect Costs":"27112.3","Operating Profit":"1926.73","Unit Sales Monthly Change":"35","Sales Value Monthly Change":"2202","Distribution Monthly Change":"2.36","Cost of Sales Monthly Change":"5.6","Price Monthly Change":"-0.61","Gross Profit Monthly Change":"2196.4","Indirect Costs Monthly Change":"2050.66","Operating Profit Monthly Change":"145.74"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Lambda","Pack Size":"12","Pack Type":"Standard","SKU":"Lambda 12 Pack Standard","Price Tier":"Budget","Unit Sales":"2742","Sales Value":"166940","Distribution":"34.29","Cost of Sales":"424.13","Price":"60.88","Gross Profit":"166515.87","Indirect Costs":"155466.33","Operating Profit":"11049.54","Unit Sales Monthly Change":"858","Sales Value Monthly Change":"48580","Distribution Monthly Change":"6.94","Cost of Sales Monthly Change":"123.43","Price Monthly Change":"-1.94","Gross Profit Monthly Change":"48456.57","Indirect Costs Monthly Change":"45241.37","Operating Profit Monthly Change":"3215.2"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Mu","Pack Size":"12","Pack Type":"Standard","SKU":"Mu 12 Pack Standard","Price Tier":"Premium","Unit Sales":"413","Sales Value":"65739","Distribution":"17.54","Cost of Sales":"167.02","Price":"159.17","Gross Profit":"65571.98","Indirect Costs":"61220.88","Operating Profit":"4351.1","Unit Sales Monthly Change":"122","Sales Value Monthly Change":"18495","Distribution Monthly Change":"9.57","Cost of Sales Monthly Change":"46.99","Price Monthly Change":"-3.18","Gross Profit Monthly Change":"18448.01","Indirect Costs Monthly Change":"17223.88","Operating Profit Monthly Change":"1224.13"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"6","Pack Type":"Standard","SKU":"Theta 6 Pack Standard","Price Tier":"Regular","Unit Sales":"415","Sales Value":"41884","Distribution":"11.25","Cost of Sales":"106.41","Price":"100.93","Gross Profit":"41777.59","Indirect Costs":"39005.02","Operating Profit":"2772.57","Unit Sales Monthly Change":"71","Sales Value Monthly Change":"7230","Distribution Monthly Change":"2.21","Cost of Sales Monthly Change":"18.37","Price Monthly Change":"0.19","Gross Profit Monthly Change":"7211.63","Indirect Costs Monthly Change":"6733.1","Operating Profit Monthly Change":"478.53"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"8","Pack Type":"Standard","SKU":"Theta 8 Pack Standard","Price Tier":"Regular","Unit Sales":"2135","Sales Value":"198419","Distribution":"32.63","Cost of Sales":"504.1","Price":"92.94","Gross Profit":"197914.9","Indirect Costs":"184781.84","Operating Profit":"13133.06","Unit Sales Monthly Change":"264","Sales Value Monthly Change":"24729","Distribution Monthly Change":"5.42","Cost of Sales Monthly Change":"62.82","Price Monthly Change":"0.11","Gross Profit Monthly Change":"24666.18","Indirect Costs Monthly Change":"23029.42","Operating Profit Monthly Change":"1636.76"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Deluxe","SKU":"Theta 12 Pack Deluxe","Price Tier":"Regular","Unit Sales":"1115","Sales Value":"88853","Distribution":"13.82","Cost of Sales":"225.74","Price":"79.69","Gross Profit":"88627.26","Indirect Costs":"82746.67","Operating Profit":"5880.59","Unit Sales Monthly Change":"-346","Sales Value Monthly Change":"-26373","Distribution Monthly Change":"0.56","Cost of Sales Monthly Change":"-67.01","Price Monthly Change":"0.82","Gross Profit Monthly Change":"-26305.99","Indirect Costs Monthly Change":"-24560.43","Operating Profit Monthly Change":"-1745.56"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Giftset","SKU":"Theta 12 Pack Giftset","Price Tier":"Regular","Unit Sales":"2300","Sales Value":"213728","Distribution":"27.87","Cost of Sales":"543","Price":"92.93","Gross Profit":"213185","Indirect Costs":"199039.23","Operating Profit":"14145.77","Unit Sales Monthly Change":"-536","Sales Value Monthly Change":"-25422","Distribution Monthly Change":"3.37","Cost of Sales Monthly Change":"-64.58","Price Monthly Change":"8.6","Gross Profit Monthly Change":"-25357.42","Indirect Costs Monthly Change":"-23674.8","Operating Profit Monthly Change":"-1682.62"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"12","Pack Type":"Standard","SKU":"Theta 12 Pack Standard","Price Tier":"Regular","Unit Sales":"26261","Sales Value":"1673476","Distribution":"68.24","Cost of Sales":"4251.64","Price":"63.72","Gross Profit":"1669224.36","Indirect Costs":"1558460.65","Operating Profit":"110763.71","Unit Sales Monthly Change":"4055","Sales Value Monthly Change":"281952","Distribution Monthly Change":"5.35","Cost of Sales Monthly Change":"716.33","Price Monthly Change":"1.06","Gross Profit Monthly Change":"281235.67","Indirect Costs Monthly Change":"262573.4","Operating Profit Monthly Change":"18662.27"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"Black Mesa","Brand":"Theta","Pack Size":"18","Pack Type":"Standard","SKU":"Theta 18 Pack Standard","Price Tier":"Regular","Unit Sales":"6533","Sales Value":"425285","Distribution":"30.77","Cost of Sales":"1080.48","Price":"65.1","Gross Profit":"424204.52","Indirect Costs":"396056.3","Operating Profit":"28148.22","Unit Sales Monthly Change":"888","Sales Value Monthly Change":"56719","Distribution Monthly Change":"4.34","Cost of Sales Monthly Change":"144.1","Price Monthly Change":"-0.19","Gross Profit Monthly Change":"56574.9","Indirect Costs Monthly Change":"52821.55","Operating Profit Monthly Change":"3753.35"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"LexCorp","Brand":"Gamma","Pack Size":"12","Pack Type":"Standard","SKU":"Gamma 12 Pack Standard","Price Tier":"Budget","Unit Sales":"1937","Sales Value":"136766","Distribution":"32.25","Cost of Sales":"347.47","Price":"70.61","Gross Profit":"136418.53","Indirect Costs":"127366.69","Operating Profit":"9051.84","Unit Sales Monthly Change":"189","Sales Value Monthly Change":"16225","Distribution Monthly Change":"5.12","Cost of Sales Monthly Change":"41.22","Price Monthly Change":"1.65","Gross Profit Monthly Change":"16183.78","Indirect Costs Monthly Change":"15110.63","Operating Profit Monthly Change":"1073.15"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"12","Pack Type":"Standard","SKU":"Alpha 12 Pack Standard","Price Tier":"Regular","Unit Sales":"5394","Sales Value":"402587","Distribution":"40.62","Cost of Sales":"1022.81","Price":"74.64","Gross Profit":"401564.19","Indirect Costs":"374918.3","Operating Profit":"26645.89","Unit Sales Monthly Change":"4547","Sales Value Monthly Change":"327019","Distribution Monthly Change":"25.47","Cost of Sales Monthly Change":"830.82","Price Monthly Change":"-14.58","Gross Profit Monthly Change":"326188.18","Indirect Costs Monthly Change":"304544.32","Operating Profit Monthly Change":"21643.86"}
,{"Date":"01/02/2011","Month":"Feb-11","Channel":"Supermarkets","Owner":"MomCorp","Brand":"Alpha","Pack Size":"18","Pack Type":"Standard","SKU":"Alpha 18 Pack Standard","Price Tier":"Regular","Unit Sales":"376","Sales Value":"29900","Distribution":"7.36","Cost of Sales":"75.97","Price":"79.52","Gross Profit":"29824.03","Indirect Costs":"27845.4","Operating Profit":"1978.63","Unit Sales Monthly Change":"57","Sales Value Monthly Change":"4450","Distribution Monthly Change":"0.94","Cost of Sales Monthly Change":"11.31","Price Monthly Change":"-0.26","Gross Profit Monthly Change":"4438.69","Indirect Costs Monthly Change":"4144.9","Operating Profit Monthly Change":"293.79"}
];

});

require.register("features", function(exports, require, module) {
"use strict";

var release        = require('features.release');
var brunch = require('brunch');
var features;

if(brunch.env !== "production") {
  var local = {};
  var debug = require('features.debug');
  try {
    local   = require('features.local');
  } catch (e) {
    // no local overrides, skipping.
  }
  var browser =  _.chain(release)
                  .mapObject(function(value, feature) { return localStorage.getItem(feature); })
                  .pick     (function(value) { return value !== null; })
                  .mapObject(function(value) { return value === "true"; })
                  .value();

  features = _({}).defaults(browser, local, debug, release);

  var displayWarning = function(feature) {
    console.error("Unknown feature " + feature);
    console.error("Possible features " + Object.keys(release).join(", "));
  };
  features.enable  = function(feature) {
    if (release[feature] === undefined) {
      displayWarning(feature);
    } else {
      console.info("OK, enabling feature " + feature + " for you! Please reload the page.");
      localStorage.setItem(feature, "true" );
    }
  };
  features.disable = function(feature) {
    if (release[feature] === undefined) {
      displayWarning(feature);
    } else {
      console.info("OK, disabling feature " + feature + " for you! Please reload the page.");
      localStorage.setItem(feature, "true" );
    }
  };
  features.clear = function() {
    console.info("Clearing feature overrides. Please reload the page.");
    localStorage.clear();
  };
  window.features  = features;
} else {
  features = release;
}

module.exports = features;
});

require.register("font/LatoBlack-sdf", function(exports, require, module) {
module.exports = {"pages":["LatoBlack-sdf.png"],"chars":[{"id":32,"x":0,"y":0,"width":0,"height":0,"xoffset":0,"yoffset":32,"xadvance":6,"page":0,"chnl":0},{"id":41,"x":0,"y":0,"width":17,"height":41,"xoffset":-3,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":40,"x":17,"y":0,"width":17,"height":41,"xoffset":-3,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":36,"x":34,"y":0,"width":27,"height":40,"xoffset":-4,"yoffset":0,"xadvance":19,"page":0,"chnl":0},{"id":124,"x":61,"y":0,"width":14,"height":40,"xoffset":-2,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":125,"x":75,"y":0,"width":19,"height":40,"xoffset":-4,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":123,"x":94,"y":0,"width":18,"height":40,"xoffset":-4,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":93,"x":112,"y":0,"width":18,"height":40,"xoffset":-4,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":91,"x":130,"y":0,"width":17,"height":40,"xoffset":-3,"yoffset":2,"xadvance":10,"page":0,"chnl":0},{"id":106,"x":147,"y":0,"width":18,"height":38,"xoffset":-5,"yoffset":4,"xadvance":9,"page":0,"chnl":0},{"id":81,"x":165,"y":0,"width":36,"height":38,"xoffset":-4,"yoffset":3,"xadvance":26,"page":0,"chnl":0},{"id":92,"x":201,"y":0,"width":24,"height":36,"xoffset":-5,"yoffset":3,"xadvance":13,"page":0,"chnl":0},{"id":64,"x":225,"y":0,"width":35,"height":36,"xoffset":-4,"yoffset":5,"xadvance":26,"page":0,"chnl":0},{"id":47,"x":260,"y":0,"width":24,"height":36,"xoffset":-5,"yoffset":3,"xadvance":13,"page":0,"chnl":0},{"id":127,"x":284,"y":0,"width":27,"height":34,"xoffset":-4,"yoffset":3,"xadvance":18,"page":0,"chnl":0},{"id":38,"x":311,"y":0,"width":33,"height":34,"xoffset":-4,"yoffset":3,"xadvance":23,"page":0,"chnl":0},{"id":35,"x":344,"y":0,"width":28,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":37,"x":372,"y":0,"width":35,"height":34,"xoffset":-4,"yoffset":3,"xadvance":26,"page":0,"chnl":0},{"id":63,"x":407,"y":0,"width":23,"height":34,"xoffset":-4,"yoffset":3,"xadvance":14,"page":0,"chnl":0},{"id":33,"x":430,"y":0,"width":15,"height":34,"xoffset":-1,"yoffset":3,"xadvance":12,"page":0,"chnl":0},{"id":48,"x":445,"y":0,"width":27,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":56,"x":472,"y":0,"width":27,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":55,"x":0,"y":41,"width":26,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":54,"x":26,"y":41,"width":26,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":53,"x":52,"y":41,"width":26,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":52,"x":78,"y":41,"width":28,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":51,"x":106,"y":41,"width":26,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":50,"x":132,"y":41,"width":26,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":49,"x":158,"y":41,"width":25,"height":34,"xoffset":-2,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":108,"x":183,"y":41,"width":15,"height":34,"xoffset":-2,"yoffset":3,"xadvance":9,"page":0,"chnl":0},{"id":107,"x":198,"y":41,"width":27,"height":34,"xoffset":-3,"yoffset":3,"xadvance":18,"page":0,"chnl":0},{"id":104,"x":225,"y":41,"width":25,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":100,"x":250,"y":41,"width":26,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":98,"x":276,"y":41,"width":26,"height":34,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":90,"x":302,"y":41,"width":28,"height":34,"xoffset":-4,"yoffset":3,"xadvance":20,"page":0,"chnl":0},{"id":89,"x":330,"y":41,"width":32,"height":34,"xoffset":-5,"yoffset":3,"xadvance":22,"page":0,"chnl":0},{"id":88,"x":362,"y":41,"width":32,"height":34,"xoffset":-4,"yoffset":3,"xadvance":23,"page":0,"chnl":0},{"id":87,"x":394,"y":41,"width":44,"height":34,"xoffset":-4,"yoffset":3,"xadvance":34,"page":0,"chnl":0},{"id":86,"x":438,"y":41,"width":33,"height":34,"xoffset":-4,"yoffset":3,"xadvance":24,"page":0,"chnl":0},{"id":85,"x":471,"y":41,"width":30,"height":34,"xoffset":-3,"yoffset":3,"xadvance":23,"page":0,"chnl":0},{"id":84,"x":0,"y":75,"width":28,"height":34,"xoffset":-4,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":83,"x":28,"y":75,"width":26,"height":34,"xoffset":-4,"yoffset":3,"xadvance":17,"page":0,"chnl":0},{"id":82,"x":54,"y":75,"width":29,"height":34,"xoffset":-3,"yoffset":3,"xadvance":21,"page":0,"chnl":0},{"id":80,"x":83,"y":75,"width":28,"height":34,"xoffset":-3,"yoffset":3,"xadvance":20,"page":0,"chnl":0},{"id":79,"x":111,"y":75,"width":34,"height":34,"xoffset":-4,"yoffset":3,"xadvance":26,"page":0,"chnl":0},{"id":78,"x":145,"y":75,"width":31,"height":34,"xoffset":-3,"yoffset":3,"xadvance":24,"page":0,"chnl":0},{"id":77,"x":176,"y":75,"width":37,"height":34,"xoffset":-3,"yoffset":3,"xadvance":30,"page":0,"chnl":0},{"id":76,"x":213,"y":75,"width":24,"height":34,"xoffset":-3,"yoffset":3,"xadvance":17,"page":0,"chnl":0},{"id":75,"x":237,"y":75,"width":31,"height":34,"xoffset":-3,"yoffset":3,"xadvance":23,"page":0,"chnl":0},{"id":74,"x":268,"y":75,"width":21,"height":34,"xoffset":-4,"yoffset":3,"xadvance":14,"page":0,"chnl":0},{"id":73,"x":289,"y":75,"width":15,"height":34,"xoffset":-2,"yoffset":3,"xadvance":10,"page":0,"chnl":0},{"id":72,"x":304,"y":75,"width":31,"height":34,"xoffset":-3,"yoffset":3,"xadvance":24,"page":0,"chnl":0},{"id":71,"x":335,"y":75,"width":31,"height":34,"xoffset":-4,"yoffset":3,"xadvance":23,"page":0,"chnl":0},{"id":70,"x":366,"y":75,"width":25,"height":34,"xoffset":-3,"yoffset":3,"xadvance":18,"page":0,"chnl":0},{"id":69,"x":391,"y":75,"width":25,"height":34,"xoffset":-3,"yoffset":3,"xadvance":18,"page":0,"chnl":0},{"id":68,"x":416,"y":75,"width":32,"height":34,"xoffset":-3,"yoffset":3,"xadvance":24,"page":0,"chnl":0},{"id":67,"x":448,"y":75,"width":30,"height":34,"xoffset":-4,"yoffset":3,"xadvance":21,"page":0,"chnl":0},{"id":66,"x":478,"y":75,"width":28,"height":34,"xoffset":-3,"yoffset":3,"xadvance":21,"page":0,"chnl":0},{"id":65,"x":0,"y":109,"width":33,"height":34,"xoffset":-4,"yoffset":3,"xadvance":24,"page":0,"chnl":0},{"id":57,"x":33,"y":109,"width":27,"height":33,"xoffset":-3,"yoffset":4,"xadvance":19,"page":0,"chnl":0},{"id":105,"x":60,"y":109,"width":16,"height":33,"xoffset":-3,"yoffset":4,"xadvance":9,"page":0,"chnl":0},{"id":102,"x":76,"y":109,"width":21,"height":33,"xoffset":-4,"yoffset":4,"xadvance":12,"page":0,"chnl":0},{"id":121,"x":97,"y":109,"width":27,"height":32,"xoffset":-4,"yoffset":10,"xadvance":18,"page":0,"chnl":0},{"id":116,"x":124,"y":109,"width":22,"height":32,"xoffset":-4,"yoffset":5,"xadvance":13,"page":0,"chnl":0},{"id":113,"x":146,"y":109,"width":26,"height":32,"xoffset":-4,"yoffset":10,"xadvance":19,"page":0,"chnl":0},{"id":112,"x":172,"y":109,"width":26,"height":32,"xoffset":-3,"yoffset":10,"xadvance":19,"page":0,"chnl":0},{"id":103,"x":198,"y":109,"width":26,"height":32,"xoffset":-4,"yoffset":10,"xadvance":17,"page":0,"chnl":0},{"id":59,"x":224,"y":109,"width":16,"height":31,"xoffset":-3,"yoffset":11,"xadvance":9,"page":0,"chnl":0},{"id":122,"x":240,"y":109,"width":23,"height":27,"xoffset":-3,"yoffset":10,"xadvance":15,"page":0,"chnl":0},{"id":120,"x":263,"y":109,"width":27,"height":27,"xoffset":-4,"yoffset":10,"xadvance":18,"page":0,"chnl":0},{"id":119,"x":290,"y":109,"width":35,"height":27,"xoffset":-4,"yoffset":10,"xadvance":26,"page":0,"chnl":0},{"id":118,"x":325,"y":109,"width":27,"height":27,"xoffset":-4,"yoffset":10,"xadvance":18,"page":0,"chnl":0},{"id":117,"x":352,"y":109,"width":25,"height":27,"xoffset":-3,"yoffset":10,"xadvance":19,"page":0,"chnl":0},{"id":115,"x":377,"y":109,"width":23,"height":27,"xoffset":-4,"yoffset":10,"xadvance":14,"page":0,"chnl":0},{"id":114,"x":400,"y":109,"width":21,"height":27,"xoffset":-3,"yoffset":10,"xadvance":13,"page":0,"chnl":0},{"id":110,"x":421,"y":109,"width":25,"height":27,"xoffset":-3,"yoffset":10,"xadvance":19,"page":0,"chnl":0},{"id":109,"x":446,"y":109,"width":34,"height":27,"xoffset":-3,"yoffset":10,"xadvance":28,"page":0,"chnl":0},{"id":101,"x":480,"y":109,"width":26,"height":27,"xoffset":-4,"yoffset":10,"xadvance":17,"page":0,"chnl":0},{"id":99,"x":0,"y":143,"width":25,"height":27,"xoffset":-4,"yoffset":10,"xadvance":16,"page":0,"chnl":0},{"id":97,"x":25,"y":143,"width":24,"height":27,"xoffset":-3,"yoffset":10,"xadvance":17,"page":0,"chnl":0},{"id":43,"x":49,"y":143,"width":26,"height":26,"xoffset":-3,"yoffset":8,"xadvance":19,"page":0,"chnl":0},{"id":58,"x":75,"y":143,"width":16,"height":26,"xoffset":-3,"yoffset":11,"xadvance":9,"page":0,"chnl":0},{"id":111,"x":91,"y":143,"width":27,"height":26,"xoffset":-4,"yoffset":11,"xadvance":19,"page":0,"chnl":0},{"id":62,"x":118,"y":143,"width":23,"height":25,"xoffset":-1,"yoffset":9,"xadvance":19,"page":0,"chnl":0},{"id":60,"x":141,"y":143,"width":23,"height":25,"xoffset":-2,"yoffset":9,"xadvance":19,"page":0,"chnl":0},{"id":42,"x":164,"y":143,"width":21,"height":21,"xoffset":-4,"yoffset":3,"xadvance":13,"page":0,"chnl":0},{"id":94,"x":185,"y":143,"width":25,"height":21,"xoffset":-3,"yoffset":3,"xadvance":19,"page":0,"chnl":0},{"id":44,"x":210,"y":143,"width":15,"height":20,"xoffset":-3,"yoffset":22,"xadvance":8,"page":0,"chnl":0},{"id":61,"x":225,"y":143,"width":25,"height":19,"xoffset":-3,"yoffset":12,"xadvance":19,"page":0,"chnl":0},{"id":39,"x":250,"y":143,"width":15,"height":19,"xoffset":-3,"yoffset":3,"xadvance":8,"page":0,"chnl":0},{"id":34,"x":265,"y":143,"width":21,"height":19,"xoffset":-3,"yoffset":3,"xadvance":14,"page":0,"chnl":0},{"id":126,"x":286,"y":143,"width":26,"height":17,"xoffset":-3,"yoffset":14,"xadvance":19,"page":0,"chnl":0},{"id":46,"x":312,"y":143,"width":16,"height":16,"xoffset":-4,"yoffset":21,"xadvance":8,"page":0,"chnl":0},{"id":96,"x":328,"y":143,"width":18,"height":15,"xoffset":-5,"yoffset":3,"xadvance":11,"page":0,"chnl":0},{"id":95,"x":346,"y":143,"width":22,"height":13,"xoffset":-4,"yoffset":29,"xadvance":13,"page":0,"chnl":0},{"id":45,"x":368,"y":143,"width":19,"height":13,"xoffset":-3,"yoffset":16,"xadvance":12,"page":0,"chnl":0}],"kernings":[{"first":40,"second":64,"amount":-1},{"first":40,"second":67,"amount":-1},{"first":40,"second":71,"amount":-1},{"first":40,"second":79,"amount":-1},{"first":40,"second":81,"amount":-1},{"first":40,"second":99,"amount":-1},{"first":40,"second":100,"amount":-1},{"first":40,"second":101,"amount":-1},{"first":40,"second":111,"amount":-1},{"first":40,"second":113,"amount":-1},{"first":123,"second":64,"amount":-1},{"first":123,"second":67,"amount":-1},{"first":123,"second":71,"amount":-1},{"first":123,"second":79,"amount":-1},{"first":123,"second":81,"amount":-1},{"first":123,"second":99,"amount":-1},{"first":123,"second":100,"amount":-1},{"first":123,"second":101,"amount":-1},{"first":123,"second":111,"amount":-1},{"first":123,"second":113,"amount":-1},{"first":91,"second":64,"amount":-1},{"first":91,"second":67,"amount":-1},{"first":91,"second":71,"amount":-1},{"first":91,"second":79,"amount":-1},{"first":91,"second":81,"amount":-1},{"first":91,"second":99,"amount":-1},{"first":91,"second":100,"amount":-1},{"first":91,"second":101,"amount":-1},{"first":91,"second":111,"amount":-1},{"first":91,"second":113,"amount":-1},{"first":81,"second":34,"amount":-1},{"first":81,"second":38,"amount":-1},{"first":81,"second":39,"amount":-1},{"first":81,"second":41,"amount":-1},{"first":81,"second":42,"amount":-1},{"first":81,"second":44,"amount":-1},{"first":81,"second":46,"amount":-1},{"first":81,"second":47,"amount":-1},{"first":81,"second":65,"amount":-1},{"first":81,"second":84,"amount":-1},{"first":81,"second":86,"amount":-1},{"first":81,"second":89,"amount":-1},{"first":81,"second":90,"amount":-1},{"first":81,"second":92,"amount":-1},{"first":81,"second":93,"amount":-1},{"first":81,"second":125,"amount":-1},{"first":92,"second":34,"amount":-3},{"first":92,"second":39,"amount":-3},{"first":92,"second":42,"amount":-3},{"first":92,"second":45,"amount":-1},{"first":92,"second":63,"amount":-1},{"first":92,"second":64,"amount":-1},{"first":92,"second":67,"amount":-1},{"first":92,"second":71,"amount":-1},{"first":92,"second":74,"amount":1},{"first":92,"second":79,"amount":-1},{"first":92,"second":81,"amount":-1},{"first":92,"second":84,"amount":-3},{"first":92,"second":85,"amount":-1},{"first":92,"second":86,"amount":-3},{"first":92,"second":87,"amount":-2},{"first":92,"second":89,"amount":-3},{"first":92,"second":92,"amount":-3},{"first":92,"second":118,"amount":-2},{"first":92,"second":121,"amount":-2},{"first":64,"second":34,"amount":-1},{"first":64,"second":38,"amount":-1},{"first":64,"second":39,"amount":-1},{"first":64,"second":41,"amount":-1},{"first":64,"second":42,"amount":-1},{"first":64,"second":44,"amount":-1},{"first":64,"second":46,"amount":-1},{"first":64,"second":47,"amount":-1},{"first":64,"second":65,"amount":-1},{"first":64,"second":84,"amount":-1},{"first":64,"second":86,"amount":-1},{"first":64,"second":89,"amount":-1},{"first":64,"second":90,"amount":-1},{"first":64,"second":92,"amount":-1},{"first":64,"second":93,"amount":-1},{"first":64,"second":125,"amount":-1},{"first":47,"second":34,"amount":1},{"first":47,"second":38,"amount":-3},{"first":47,"second":39,"amount":1},{"first":47,"second":42,"amount":1},{"first":47,"second":44,"amount":-3},{"first":47,"second":45,"amount":-2},{"first":47,"second":46,"amount":-3},{"first":47,"second":47,"amount":-3},{"first":47,"second":58,"amount":-2},{"first":47,"second":59,"amount":-2},{"first":47,"second":64,"amount":-1},{"first":47,"second":65,"amount":-3},{"first":47,"second":67,"amount":-1},{"first":47,"second":71,"amount":-1},{"first":47,"second":74,"amount":-3},{"first":47,"second":79,"amount":-1},{"first":47,"second":81,"amount":-1},{"first":47,"second":97,"amount":-2},{"first":47,"second":99,"amount":-2},{"first":47,"second":100,"amount":-2},{"first":47,"second":101,"amount":-2},{"first":47,"second":103,"amount":-2},{"first":47,"second":109,"amount":-2},{"first":47,"second":110,"amount":-2},{"first":47,"second":111,"amount":-2},{"first":47,"second":112,"amount":-2},{"first":47,"second":113,"amount":-2},{"first":47,"second":114,"amount":-2},{"first":47,"second":115,"amount":-2},{"first":47,"second":116,"amount":-1},{"first":47,"second":117,"amount":-2},{"first":47,"second":118,"amount":-1},{"first":47,"second":120,"amount":-1},{"first":47,"second":121,"amount":-1},{"first":47,"second":122,"amount":-2},{"first":107,"second":99,"amount":-1},{"first":107,"second":100,"amount":-1},{"first":107,"second":101,"amount":-1},{"first":107,"second":111,"amount":-1},{"first":107,"second":113,"amount":-1},{"first":104,"second":34,"amount":-1},{"first":104,"second":39,"amount":-1},{"first":104,"second":42,"amount":-1},{"first":104,"second":118,"amount":-1},{"first":104,"second":121,"amount":-1},{"first":98,"second":34,"amount":-2},{"first":98,"second":39,"amount":-2},{"first":98,"second":41,"amount":-1},{"first":98,"second":42,"amount":-2},{"first":98,"second":86,"amount":-2},{"first":98,"second":87,"amount":-1},{"first":98,"second":92,"amount":-2},{"first":98,"second":93,"amount":-1},{"first":98,"second":118,"amount":-1},{"first":98,"second":120,"amount":-1},{"first":98,"second":121,"amount":-1},{"first":98,"second":125,"amount":-1},{"first":90,"second":45,"amount":-1},{"first":90,"second":64,"amount":-1},{"first":90,"second":67,"amount":-1},{"first":90,"second":71,"amount":-1},{"first":90,"second":79,"amount":-1},{"first":90,"second":81,"amount":-1},{"first":89,"second":34,"amount":1},{"first":89,"second":38,"amount":-3},{"first":89,"second":39,"amount":1},{"first":89,"second":42,"amount":1},{"first":89,"second":44,"amount":-3},{"first":89,"second":45,"amount":-3},{"first":89,"second":46,"amount":-3},{"first":89,"second":47,"amount":-3},{"first":89,"second":58,"amount":-2},{"first":89,"second":59,"amount":-2},{"first":89,"second":64,"amount":-1},{"first":89,"second":65,"amount":-3},{"first":89,"second":67,"amount":-1},{"first":89,"second":71,"amount":-1},{"first":89,"second":74,"amount":-3},{"first":89,"second":79,"amount":-1},{"first":89,"second":81,"amount":-1},{"first":89,"second":97,"amount":-3},{"first":89,"second":99,"amount":-3},{"first":89,"second":100,"amount":-3},{"first":89,"second":101,"amount":-3},{"first":89,"second":103,"amount":-3},{"first":89,"second":109,"amount":-2},{"first":89,"second":110,"amount":-2},{"first":89,"second":111,"amount":-3},{"first":89,"second":112,"amount":-2},{"first":89,"second":113,"amount":-3},{"first":89,"second":114,"amount":-2},{"first":89,"second":115,"amount":-2},{"first":89,"second":117,"amount":-2},{"first":89,"second":118,"amount":-2},{"first":89,"second":119,"amount":-2},{"first":89,"second":120,"amount":-2},{"first":89,"second":121,"amount":-2},{"first":88,"second":45,"amount":-1},{"first":88,"second":99,"amount":-1},{"first":88,"second":100,"amount":-1},{"first":88,"second":101,"amount":-1},{"first":88,"second":102,"amount":-1},{"first":88,"second":111,"amount":-1},{"first":88,"second":113,"amount":-1},{"first":88,"second":116,"amount":-2},{"first":88,"second":118,"amount":-1},{"first":88,"second":119,"amount":-1},{"first":88,"second":121,"amount":-1},{"first":87,"second":34,"amount":1},{"first":87,"second":38,"amount":-2},{"first":87,"second":39,"amount":1},{"first":87,"second":42,"amount":1},{"first":87,"second":44,"amount":-2},{"first":87,"second":45,"amount":-1},{"first":87,"second":46,"amount":-2},{"first":87,"second":47,"amount":-2},{"first":87,"second":65,"amount":-2},{"first":87,"second":74,"amount":-2},{"first":87,"second":97,"amount":-2},{"first":87,"second":99,"amount":-1},{"first":87,"second":100,"amount":-1},{"first":87,"second":101,"amount":-1},{"first":87,"second":103,"amount":-2},{"first":87,"second":111,"amount":-1},{"first":87,"second":113,"amount":-1},{"first":87,"second":115,"amount":-1},{"first":86,"second":34,"amount":1},{"first":86,"second":38,"amount":-3},{"first":86,"second":39,"amount":1},{"first":86,"second":42,"amount":1},{"first":86,"second":44,"amount":-3},{"first":86,"second":45,"amount":-2},{"first":86,"second":46,"amount":-3},{"first":86,"second":47,"amount":-3},{"first":86,"second":58,"amount":-2},{"first":86,"second":59,"amount":-2},{"first":86,"second":64,"amount":-1},{"first":86,"second":65,"amount":-3},{"first":86,"second":67,"amount":-1},{"first":86,"second":71,"amount":-1},{"first":86,"second":74,"amount":-3},{"first":86,"second":79,"amount":-1},{"first":86,"second":81,"amount":-1},{"first":86,"second":97,"amount":-2},{"first":86,"second":99,"amount":-2},{"first":86,"second":100,"amount":-2},{"first":86,"second":101,"amount":-2},{"first":86,"second":103,"amount":-2},{"first":86,"second":109,"amount":-2},{"first":86,"second":110,"amount":-2},{"first":86,"second":111,"amount":-2},{"first":86,"second":112,"amount":-2},{"first":86,"second":113,"amount":-2},{"first":86,"second":114,"amount":-2},{"first":86,"second":115,"amount":-2},{"first":86,"second":116,"amount":-1},{"first":86,"second":117,"amount":-2},{"first":86,"second":118,"amount":-1},{"first":86,"second":120,"amount":-1},{"first":86,"second":121,"amount":-1},{"first":86,"second":122,"amount":-2},{"first":85,"second":38,"amount":-1},{"first":85,"second":44,"amount":-1},{"first":85,"second":46,"amount":-1},{"first":85,"second":47,"amount":-1},{"first":85,"second":65,"amount":-1},{"first":84,"second":38,"amount":-3},{"first":84,"second":44,"amount":-3},{"first":84,"second":45,"amount":-3},{"first":84,"second":46,"amount":-3},{"first":84,"second":47,"amount":-3},{"first":84,"second":58,"amount":-3},{"first":84,"second":59,"amount":-3},{"first":84,"second":64,"amount":-1},{"first":84,"second":65,"amount":-3},{"first":84,"second":67,"amount":-1},{"first":84,"second":71,"amount":-1},{"first":84,"second":74,"amount":-3},{"first":84,"second":79,"amount":-1},{"first":84,"second":81,"amount":-1},{"first":84,"second":97,"amount":-4},{"first":84,"second":99,"amount":-3},{"first":84,"second":100,"amount":-3},{"first":84,"second":101,"amount":-3},{"first":84,"second":103,"amount":-3},{"first":84,"second":109,"amount":-3},{"first":84,"second":110,"amount":-3},{"first":84,"second":111,"amount":-3},{"first":84,"second":112,"amount":-3},{"first":84,"second":113,"amount":-3},{"first":84,"second":114,"amount":-3},{"first":84,"second":115,"amount":-2},{"first":84,"second":117,"amount":-3},{"first":84,"second":118,"amount":-3},{"first":84,"second":119,"amount":-2},{"first":84,"second":120,"amount":-2},{"first":84,"second":121,"amount":-3},{"first":84,"second":122,"amount":-2},{"first":82,"second":64,"amount":-1},{"first":82,"second":67,"amount":-1},{"first":82,"second":71,"amount":-1},{"first":82,"second":79,"amount":-1},{"first":82,"second":81,"amount":-1},{"first":82,"second":84,"amount":-1},{"first":82,"second":85,"amount":-1},{"first":80,"second":38,"amount":-3},{"first":80,"second":44,"amount":-4},{"first":80,"second":46,"amount":-4},{"first":80,"second":47,"amount":-3},{"first":80,"second":65,"amount":-3},{"first":80,"second":74,"amount":-3},{"first":80,"second":97,"amount":-1},{"first":79,"second":34,"amount":-1},{"first":79,"second":38,"amount":-1},{"first":79,"second":39,"amount":-1},{"first":79,"second":41,"amount":-1},{"first":79,"second":42,"amount":-1},{"first":79,"second":44,"amount":-1},{"first":79,"second":46,"amount":-1},{"first":79,"second":47,"amount":-1},{"first":79,"second":65,"amount":-1},{"first":79,"second":84,"amount":-1},{"first":79,"second":86,"amount":-1},{"first":79,"second":89,"amount":-1},{"first":79,"second":90,"amount":-1},{"first":79,"second":92,"amount":-1},{"first":79,"second":93,"amount":-1},{"first":79,"second":125,"amount":-1},{"first":76,"second":34,"amount":-4},{"first":76,"second":39,"amount":-4},{"first":76,"second":42,"amount":-4},{"first":76,"second":44,"amount":1},{"first":76,"second":45,"amount":-3},{"first":76,"second":46,"amount":1},{"first":76,"second":63,"amount":-1},{"first":76,"second":64,"amount":-1},{"first":76,"second":67,"amount":-1},{"first":76,"second":71,"amount":-1},{"first":76,"second":79,"amount":-1},{"first":76,"second":81,"amount":-1},{"first":76,"second":84,"amount":-3},{"first":76,"second":86,"amount":-3},{"first":76,"second":87,"amount":-3},{"first":76,"second":89,"amount":-4},{"first":76,"second":92,"amount":-3},{"first":76,"second":99,"amount":-1},{"first":76,"second":100,"amount":-1},{"first":76,"second":101,"amount":-1},{"first":76,"second":111,"amount":-1},{"first":76,"second":113,"amount":-1},{"first":76,"second":118,"amount":-2},{"first":76,"second":119,"amount":-1},{"first":76,"second":121,"amount":-2},{"first":75,"second":45,"amount":-1},{"first":75,"second":99,"amount":-1},{"first":75,"second":100,"amount":-1},{"first":75,"second":101,"amount":-1},{"first":75,"second":102,"amount":-1},{"first":75,"second":111,"amount":-1},{"first":75,"second":113,"amount":-1},{"first":75,"second":116,"amount":-2},{"first":75,"second":118,"amount":-1},{"first":75,"second":119,"amount":-1},{"first":75,"second":121,"amount":-1},{"first":74,"second":38,"amount":-1},{"first":74,"second":44,"amount":-1},{"first":74,"second":46,"amount":-1},{"first":74,"second":47,"amount":-1},{"first":74,"second":65,"amount":-1},{"first":70,"second":38,"amount":-3},{"first":70,"second":44,"amount":-3},{"first":70,"second":46,"amount":-3},{"first":70,"second":47,"amount":-3},{"first":70,"second":58,"amount":-1},{"first":70,"second":59,"amount":-1},{"first":70,"second":65,"amount":-3},{"first":70,"second":74,"amount":-3},{"first":70,"second":99,"amount":-1},{"first":70,"second":100,"amount":-1},{"first":70,"second":101,"amount":-1},{"first":70,"second":109,"amount":-1},{"first":70,"second":110,"amount":-1},{"first":70,"second":111,"amount":-1},{"first":70,"second":112,"amount":-1},{"first":70,"second":113,"amount":-1},{"first":70,"second":114,"amount":-1},{"first":70,"second":117,"amount":-1},{"first":68,"second":34,"amount":-1},{"first":68,"second":38,"amount":-1},{"first":68,"second":39,"amount":-1},{"first":68,"second":41,"amount":-1},{"first":68,"second":42,"amount":-1},{"first":68,"second":44,"amount":-1},{"first":68,"second":46,"amount":-1},{"first":68,"second":47,"amount":-1},{"first":68,"second":65,"amount":-1},{"first":68,"second":84,"amount":-1},{"first":68,"second":86,"amount":-1},{"first":68,"second":89,"amount":-1},{"first":68,"second":90,"amount":-1},{"first":68,"second":92,"amount":-1},{"first":68,"second":93,"amount":-1},{"first":68,"second":125,"amount":-1},{"first":67,"second":45,"amount":-2},{"first":65,"second":34,"amount":-3},{"first":65,"second":39,"amount":-3},{"first":65,"second":42,"amount":-3},{"first":65,"second":45,"amount":-1},{"first":65,"second":63,"amount":-1},{"first":65,"second":64,"amount":-1},{"first":65,"second":67,"amount":-1},{"first":65,"second":71,"amount":-1},{"first":65,"second":74,"amount":1},{"first":65,"second":79,"amount":-1},{"first":65,"second":81,"amount":-1},{"first":65,"second":84,"amount":-3},{"first":65,"second":85,"amount":-1},{"first":65,"second":86,"amount":-3},{"first":65,"second":87,"amount":-2},{"first":65,"second":89,"amount":-3},{"first":65,"second":92,"amount":-3},{"first":65,"second":118,"amount":-2},{"first":65,"second":121,"amount":-2},{"first":102,"second":34,"amount":1},{"first":102,"second":39,"amount":1},{"first":102,"second":42,"amount":1},{"first":102,"second":44,"amount":-2},{"first":102,"second":46,"amount":-2},{"first":121,"second":38,"amount":-2},{"first":121,"second":44,"amount":-2},{"first":121,"second":46,"amount":-2},{"first":121,"second":47,"amount":-2},{"first":121,"second":65,"amount":-2},{"first":121,"second":99,"amount":-1},{"first":121,"second":100,"amount":-1},{"first":121,"second":101,"amount":-1},{"first":121,"second":111,"amount":-1},{"first":121,"second":113,"amount":-1},{"first":112,"second":34,"amount":-2},{"first":112,"second":39,"amount":-2},{"first":112,"second":41,"amount":-1},{"first":112,"second":42,"amount":-2},{"first":112,"second":86,"amount":-2},{"first":112,"second":87,"amount":-1},{"first":112,"second":92,"amount":-2},{"first":112,"second":93,"amount":-1},{"first":112,"second":118,"amount":-1},{"first":112,"second":120,"amount":-1},{"first":112,"second":121,"amount":-1},{"first":112,"second":125,"amount":-1},{"first":120,"second":99,"amount":-1},{"first":120,"second":100,"amount":-1},{"first":120,"second":101,"amount":-1},{"first":120,"second":111,"amount":-1},{"first":120,"second":113,"amount":-1},{"first":119,"second":44,"amount":-1},{"first":119,"second":46,"amount":-1},{"first":118,"second":38,"amount":-2},{"first":118,"second":44,"amount":-2},{"first":118,"second":46,"amount":-2},{"first":118,"second":47,"amount":-2},{"first":118,"second":65,"amount":-2},{"first":118,"second":99,"amount":-1},{"first":118,"second":100,"amount":-1},{"first":118,"second":101,"amount":-1},{"first":118,"second":111,"amount":-1},{"first":118,"second":113,"amount":-1},{"first":114,"second":44,"amount":-2},{"first":114,"second":46,"amount":-2},{"first":110,"second":34,"amount":-1},{"first":110,"second":39,"amount":-1},{"first":110,"second":42,"amount":-1},{"first":110,"second":118,"amount":-1},{"first":110,"second":121,"amount":-1},{"first":109,"second":34,"amount":-1},{"first":109,"second":39,"amount":-1},{"first":109,"second":42,"amount":-1},{"first":109,"second":118,"amount":-1},{"first":109,"second":121,"amount":-1},{"first":101,"second":34,"amount":-2},{"first":101,"second":39,"amount":-2},{"first":101,"second":41,"amount":-1},{"first":101,"second":42,"amount":-2},{"first":101,"second":86,"amount":-2},{"first":101,"second":87,"amount":-1},{"first":101,"second":92,"amount":-2},{"first":101,"second":93,"amount":-1},{"first":101,"second":118,"amount":-1},{"first":101,"second":120,"amount":-1},{"first":101,"second":121,"amount":-1},{"first":101,"second":125,"amount":-1},{"first":97,"second":34,"amount":-1},{"first":97,"second":39,"amount":-1},{"first":97,"second":42,"amount":-1},{"first":97,"second":118,"amount":-1},{"first":97,"second":121,"amount":-1},{"first":111,"second":34,"amount":-2},{"first":111,"second":39,"amount":-2},{"first":111,"second":41,"amount":-1},{"first":111,"second":42,"amount":-2},{"first":111,"second":86,"amount":-2},{"first":111,"second":87,"amount":-1},{"first":111,"second":92,"amount":-2},{"first":111,"second":93,"amount":-1},{"first":111,"second":118,"amount":-1},{"first":111,"second":120,"amount":-1},{"first":111,"second":121,"amount":-1},{"first":111,"second":125,"amount":-1},{"first":42,"second":38,"amount":-3},{"first":42,"second":44,"amount":-3},{"first":42,"second":45,"amount":-3},{"first":42,"second":46,"amount":-3},{"first":42,"second":47,"amount":-3},{"first":42,"second":64,"amount":-1},{"first":42,"second":65,"amount":-3},{"first":42,"second":67,"amount":-1},{"first":42,"second":71,"amount":-1},{"first":42,"second":79,"amount":-1},{"first":42,"second":81,"amount":-1},{"first":42,"second":86,"amount":1},{"first":42,"second":87,"amount":1},{"first":42,"second":89,"amount":1},{"first":42,"second":92,"amount":1},{"first":42,"second":97,"amount":-1},{"first":42,"second":99,"amount":-2},{"first":42,"second":100,"amount":-2},{"first":42,"second":101,"amount":-2},{"first":42,"second":111,"amount":-2},{"first":42,"second":113,"amount":-2},{"first":44,"second":34,"amount":-3},{"first":44,"second":39,"amount":-3},{"first":44,"second":42,"amount":-3},{"first":44,"second":45,"amount":-2},{"first":44,"second":64,"amount":-1},{"first":44,"second":67,"amount":-1},{"first":44,"second":71,"amount":-1},{"first":44,"second":79,"amount":-1},{"first":44,"second":81,"amount":-1},{"first":44,"second":84,"amount":-3},{"first":44,"second":86,"amount":-3},{"first":44,"second":87,"amount":-2},{"first":44,"second":89,"amount":-3},{"first":44,"second":92,"amount":-3},{"first":44,"second":118,"amount":-2},{"first":44,"second":119,"amount":-1},{"first":44,"second":121,"amount":-2},{"first":39,"second":38,"amount":-3},{"first":39,"second":44,"amount":-3},{"first":39,"second":45,"amount":-3},{"first":39,"second":46,"amount":-3},{"first":39,"second":47,"amount":-3},{"first":39,"second":64,"amount":-1},{"first":39,"second":65,"amount":-3},{"first":39,"second":67,"amount":-1},{"first":39,"second":71,"amount":-1},{"first":39,"second":79,"amount":-1},{"first":39,"second":81,"amount":-1},{"first":39,"second":86,"amount":1},{"first":39,"second":87,"amount":1},{"first":39,"second":89,"amount":1},{"first":39,"second":92,"amount":1},{"first":39,"second":97,"amount":-1},{"first":39,"second":99,"amount":-2},{"first":39,"second":100,"amount":-2},{"first":39,"second":101,"amount":-2},{"first":39,"second":111,"amount":-2},{"first":39,"second":113,"amount":-2},{"first":34,"second":38,"amount":-3},{"first":34,"second":44,"amount":-3},{"first":34,"second":45,"amount":-3},{"first":34,"second":46,"amount":-3},{"first":34,"second":47,"amount":-3},{"first":34,"second":64,"amount":-1},{"first":34,"second":65,"amount":-3},{"first":34,"second":67,"amount":-1},{"first":34,"second":71,"amount":-1},{"first":34,"second":79,"amount":-1},{"first":34,"second":81,"amount":-1},{"first":34,"second":86,"amount":1},{"first":34,"second":87,"amount":1},{"first":34,"second":89,"amount":1},{"first":34,"second":92,"amount":1},{"first":34,"second":97,"amount":-1},{"first":34,"second":99,"amount":-2},{"first":34,"second":100,"amount":-2},{"first":34,"second":101,"amount":-2},{"first":34,"second":111,"amount":-2},{"first":34,"second":113,"amount":-2},{"first":46,"second":34,"amount":-3},{"first":46,"second":39,"amount":-3},{"first":46,"second":42,"amount":-3},{"first":46,"second":45,"amount":-2},{"first":46,"second":64,"amount":-1},{"first":46,"second":67,"amount":-1},{"first":46,"second":71,"amount":-1},{"first":46,"second":79,"amount":-1},{"first":46,"second":81,"amount":-1},{"first":46,"second":84,"amount":-3},{"first":46,"second":86,"amount":-3},{"first":46,"second":87,"amount":-2},{"first":46,"second":89,"amount":-3},{"first":46,"second":92,"amount":-3},{"first":46,"second":118,"amount":-2},{"first":46,"second":119,"amount":-1},{"first":46,"second":121,"amount":-2},{"first":45,"second":34,"amount":-3},{"first":45,"second":38,"amount":-1},{"first":45,"second":39,"amount":-3},{"first":45,"second":42,"amount":-3},{"first":45,"second":44,"amount":-2},{"first":45,"second":46,"amount":-2},{"first":45,"second":47,"amount":-1},{"first":45,"second":65,"amount":-1},{"first":45,"second":84,"amount":-3},{"first":45,"second":86,"amount":-2},{"first":45,"second":87,"amount":-1},{"first":45,"second":88,"amount":-1},{"first":45,"second":89,"amount":-3},{"first":45,"second":90,"amount":-1},{"first":45,"second":92,"amount":-2}],"info":{"face":"Lato Black","size":32,"bold":0,"italic":0,"charset":"","unicode":0,"stretchH":100,"smooth":1,"aa":1,"padding":[4,4,4,4],"spacing":[-8,-8]},"common":{"lineHeight":39,"base":32,"scaleW":512,"scaleH":512,"pages":1,"packed":0}};
});

require.register("font/text_material", function(exports, require, module) {
"use strict";

var $$ = require('common')
  , fs = require('shaders/font.frag')()
  , vs = require('shaders/font.vert')();

var defaults = function(){
  return {
    uniforms: {
      opacity:   { type: 'f', value: 1 },
      smooth:    { type: 'f', value: 1/6 },
      map:       { type: 't', value: THREE.ImageUtils.loadTexture('/font/LatoBlack-sdf.png') },
      color:     { type: 'c', value: new THREE.Color(0x999999) },
      width:     { type: 'f', value: 0 },
      objectMap: $$.commonUniforms.objectMap,
      camFactor: $$.commonUniforms.camFactor,
      zoomScaling: { type: 'i', value: 0}
    },
    vertexShader:   vs,
    fragmentShader: fs,
    transparent:    true,
    side:           THREE.DoubleSide,
    blending:       THREE.NormalBlending
  };
};

var graphOpts = defaults();
graphOpts.uniforms.zoomScaling.value = 1;

var graph = new THREE.ShaderMaterial(graphOpts);
var hud   = new THREE.ShaderMaterial(defaults());

module.exports = {hud: hud, graph: graph};

});

require.register("geometries/port", function(exports, require, module) {
"use strict";

var triangleRatio = 1.5;
var size          = 9;

var distFromRim   = 3;
var nodeRadius    = 30.0;

var triangleHeight = size * Math.sqrt(3.0) / 2.0;
var halfHeight = triangleHeight / 2.0;
var dist  = nodeRadius + halfHeight + distFromRim;

var inPortGeometry, outPortGeometry;

var posL = new THREE.BufferAttribute(new Float32Array(9), 3);
posL.setXYZ(0, 0.0, 1.0, 1.0);
posL.setXYZ(1, 0.0, 1.0, 1.0);
posL.setXYZ(2, 1.0, 1.0, 0.0);

var posR = new THREE.BufferAttribute(new Float32Array(9), 3);
posR.setXYZ(0, 0.0, 1.0, 1.0);
posR.setXYZ(1, 1.0, 1.0, 0.0);
posR.setXYZ(2, 0.0, 1.0, 1.0);

var posB = new THREE.BufferAttribute(new Float32Array(9), 3);
posB.setXYZ(0, 1.0, 1.0, 0.0);
posB.setXYZ(1, 0.0, 1.0, 1.0);
posB.setXYZ(2, 0.0, 1.0, 1.0);


var pos = new Float32Array(9);
pos[0] = -halfHeight;
pos[1] = 0.0;
pos[2] = 0.0;
pos[3] = halfHeight;
pos[4] = size *  triangleRatio * 0.5;
pos[5] = 0.0;
pos[6] = halfHeight;
pos[7] = size * -triangleRatio * 0.5;
pos[8] = 0.0;

var position = new THREE.BufferAttribute(pos, 3);
var indicies = new THREE.BufferAttribute(new Uint16Array([0, 1, 2]), 1);

inPortGeometry = new THREE.BufferGeometry();

inPortGeometry.addAttribute('position', position);
inPortGeometry.addAttribute('index', indicies );
inPortGeometry.addAttribute('posL', posL);
inPortGeometry.addAttribute('posR', posR);
inPortGeometry.addAttribute('posB', posB);

outPortGeometry = inPortGeometry.clone();
outPortGeometry.applyMatrix( new THREE.Matrix4().makeRotationZ(Math.PI) );

module.exports = {
  in: inPortGeometry,
  out: outPortGeometry,
  dist: dist,
};

});

require.register("node", function(exports, require, module) {
"use strict";

var $$       = require('common');
var config   = require('config');
var features = require('features');

var createText   = require('bmfont').render;
var font         = require("font/LatoBlack-sdf");
var textMaterial = require('font/text_material').graph;

var vs = require('shaders/node.vert')();
var fs = require('shaders/node.frag')();

var evs = require('shaders/expandedNode.vert')();
var efs = require('shaders/expandedNode.frag')();

var Port = require('port');
// var Port = require('triangle_port');

var insideColor     = new THREE.Color(0x1a1a1a);
var unselectedColor = new THREE.Color(0x3a3a3a);
var expandedColor   = new THREE.Color(0x202020);
var selectedColor   = new THREE.Color(0xb87410).multiplyScalar(0.8);
var focusedColor    = new THREE.Color(0xc85808).multiplyScalar(0.8);

var nodeGeometry    = new THREE.PlaneBufferGeometry(1.0, 1.0);
nodeGeometry.applyMatrix( new THREE.Matrix4().makeTranslation(0.5, 0.5, 0.0) );


var expandedRadius  = 20.0;
var collapsedRadius = 30.0

function Node(id, position, z, widgetId) {
  var _this = this;

  this.id = id;
  this.position = position;

  this.labelText = ":" + id;
  this.valueText = "";
  this.inputPorts  = [];
  this.outputPorts = [];


  this.uniforms = {
    selected:          { type: 'i',  value:                            0    },
    mouseDist:         { type: 'f',  value:                       100000.0  },
    expanded:          { type: 'f',  value:                             0.0 },
    nodeSize:          { type: 'v2', value: new THREE.Vector2( 2 * collapsedRadius, 2 * collapsedRadius) },
    radiusTop:         { type: 'f',  value:                            collapsedRadius },
    radiusBottom:      { type: 'f',  value:                            collapsedRadius },
    insideColor:       { type: 'c',  value:                     insideColor },
    unselectedColor:   { type: 'c',  value:                 unselectedColor },
    selectedColor:     { type: 'c',  value:                   selectedColor },
    focusedColor:      { type: 'c',  value:                    focusedColor },
    objectId:          { type: 'v3', value: new THREE.Vector3((widgetId % 256) / 255.0, Math.floor(Math.floor(widgetId % 65536) / 256) / 255.0, Math.floor(widgetId / 65536) / 255.0) }
  };

  this.expandedUniforms = {
    selected: this.uniforms.selected,
    expanded: this.uniforms.expanded,
    nodeSize: { type: 'v2', value: new THREE.Vector2( 60.0,  60.0) },
    expandedColor: { type: 'c', value: expandedColor},
    objectId: this.uniforms.objectId,
    radiusTop:         { type: 'f',  value:                            collapsedRadius },
    radiusBottom:      { type: 'f',  value:                            collapsedRadius },
  };

  Object.keys($$.commonUniforms).forEach(function(k) {
    _this.uniforms[k] = $$.commonUniforms[k];
  });

  this.mesh = new THREE.Group();
  this.node = new THREE.Mesh(
    nodeGeometry,
    new THREE.ShaderMaterial( {
      uniforms:       this.uniforms,
      vertexShader:   vs,
      fragmentShader: fs,
      transparent:    true,
      blending:       THREE.NormalBlending,
      side:           THREE.DoubleSide
    })
  );
  this.node.position.set(-30, -30, 0);

  this.expandedNode = new THREE.Group();

  this.expandedNodeBkg = new THREE.Mesh(
    nodeGeometry,
    new THREE.ShaderMaterial( {
      uniforms:       this.expandedUniforms,
      vertexShader:   evs,
      fragmentShader: efs,
      transparent:    true,
      blending:       THREE.NormalBlending,
      side:           THREE.DoubleSide
    })
  );
  this.expandedNode.position.set(-30, -30, 0);
  this.expandedNodeBkg.position.set(0, 0, -0.000005);

  this.mesh.add(this.node);
  this.mesh.add(this.expandedNode);
  this.expandedNode.add(this.expandedNodeBkg);
  this.mesh.userData.id = id;
  this.htmlContainer = document.createElement("div");
  $$.htmlCanvas.append(this.htmlContainer);

  this.htmlElements = {};
  this.moveTo(position.x, position.y);
  this.zPos(z);
  this.updateMouse(position.x, position.y);

  this.collapsedNodeSize = new THREE.Vector2( 2 * collapsedRadius,  2 * collapsedRadius);
  this.expandedNodeSize  = new THREE.Vector2(200.0, 180.0);

  this.node.scale.x = this.collapsedNodeSize.x;
  this.node.scale.y = this.collapsedNodeSize.y;

  if (features.node_labels) this.updateLabel();
  this.updateValue();

  this.setExpandedState(0.0);
}

Node.prototype.setExpandedState = function(expanded) {
  this.expandedState = expanded;
  this.expandedNode.visible = (expanded > 0.0);

  var nodeSize = new THREE.Vector2();
  nodeSize.x = (1.0 - expanded) * this.collapsedNodeSize.x + expanded * this.expandedNodeSize.x;
  nodeSize.y = (1.0 - expanded) * this.collapsedNodeSize.y + expanded * this.expandedNodeSize.y;

  var radius = (1.0 - expanded) * collapsedRadius + expanded * expandedRadius;
  this.expandedUniforms.nodeSize.value.copy(nodeSize);
  this.expandedUniforms.radiusTop.value    = collapsedRadius;
  this.expandedUniforms.radiusBottom.value = radius;
  this.expandedNodeBkg.scale.x = nodeSize.x;
  this.expandedNodeBkg.scale.y = nodeSize.y;
};

Node.prototype.toggleExpandState = function() {
  if(this.expandedState == 0) {
    this.setExpandedState(1.0);
  } else {
    this.setExpandedState(0.0);
  }
};

Node.prototype.selected = function(val) {
  if (val !== undefined) {
    this.uniforms.selected.value = val;
    if(features.label_editor) {
      if(val === 2) {
        this.showLabelEditor();
      }
    }
  }
  return this.uniforms.selected.value;
};

Node.prototype.moveTo = function(a, b) {
  var vec = new THREE.Vector2(a, b);

  this.position.x = vec.x;
  this.position.y = vec.y;

  this.mesh.position.x = vec.x;
  this.mesh.position.y = vec.y;

  $(this.htmlContainer).css({left: vec.x, top: vec.y});
};

Node.prototype.zPos = function(z) {
  if (z !== undefined) {
    this.mesh.position.z = z;
  }
  return this.mesh.position.z;
};

Node.prototype.updateMouse = function(x, y) {
  var xd = (this.mesh.position.x - this.mesh.scale.x / 2.0)- x;
  var yd = (this.mesh.position.y - this.mesh.scale.y / 2.0)- y;
  var mouseDist = Math.sqrt(xd * xd + yd * yd);
  this.uniforms.mouseDist.value = mouseDist;
  this.inputPorts.forEach(function(port) {
    port.updateMouseDist(mouseDist);
  });
  this.outputPorts.forEach(function(port) {
    port.updateMouseDist(mouseDist);
  });
};

Node.prototype.addInputPort = function(oid, id, angle) {
  var p = new Port(id, oid, angle, false, this.mesh.position.z);
  this.inputPorts.push(p);
  this.mesh.add(p.mesh);
  this.updateMouse(this.mesh.position.x, this.mesh.position.y);
  $$.registry[oid] = p;
};

Node.prototype.addOutputPort = function(oid, id, angle) {
  var p = new Port(id, oid, angle, true, this.mesh.position.z);
  this.outputPorts.push(p);
  this.mesh.add(p.mesh);
  this.updateMouse(this.mesh.position.x, this.mesh.position.y);
  $$.registry[oid] = p;
};

Node.prototype.findInputPort = function(id) {
  return _.find(this.inputPorts, function(port) { return port.id === id; });
};

Node.prototype.findOutputPort = function(id) {
  return _.find(this.outputPorts, function(port) { return port.id === id; });
};

Node.prototype.setInputPortAngle = function(id, angle) {
  this.findInputPort(id).setAngle(angle);
};

Node.prototype.setOutputPortAngle = function(id, angle) {
  this.findOutputPort(id).setAngle(angle);
};

Node.prototype.setInputPortColor = function(id, r, g, b, a) {
  this.findInputPort(id).setColor(new THREE.Vector4(r, g, b, a));
};

Node.prototype.setOutputPortColor = function(id, r, g, b, a) {
  this.findOutputPort(id).setColor(new THREE.Vector4(r, g, b, a));
};

Node.prototype.label = function(text) {
  if (text !== undefined) {
    this.labelText = text;
    this.updateLabel();
  }
  return this.labelText;
};

Node.prototype.updateLabel = function() {
  if (this.labelObject) this.mesh.remove(this.labelObject);

  var size = 150 / config.fontSize;

  var geometry = createText({
    text:  this.labelText,
    font:  font,
    width: size,
    align: 'center'
  });

  textMaterial.uniforms.width.value = size;
  this.labelObject = new THREE.Mesh(geometry, textMaterial);
  this.labelObject.scale.multiplyScalar(config.fontSize);
  this.labelObject.position.x = -45 - 30;
  this.labelObject.position.y = -12 - 30;
  this.labelObject.position.z =   0;

  this.mesh.add(this.labelObject);
};

Node.prototype.setValue = function(text) {
  this.valueText = text;
  this.updateValue();
  return this.valueText;
};

Node.prototype.updateValue = function() {
  if (this.valueObject) this.mesh.remove(this.valueObject);

  var size = 150 / config.fontSize;

  var geometry = createText({
    text:  this.valueText,
    font:  font,
    width: size,
    align: 'center'
  });

  textMaterial.uniforms.width.value = size;
  this.valueObject = new THREE.Mesh(geometry, textMaterial);
  this.valueObject.scale.multiplyScalar(config.fontSize);
  this.valueObject.position.x = -45 - 30;
  this.valueObject.position.y = 12 + 30;
  this.valueObject.position.z = 0;

  this.mesh.add(this.valueObject);
};

Node.prototype.showLabelEditor = function() {
  if (this.htmlElements.labelEditor) return;
  var editor = $('<input/>').css({left: -50, top: -52, width: 100, textAlign: 'center'});
  editor.val(this.labelText);
  this.htmlElements.labelEditor = editor;
  this.htmlContainer.append(editor);

  this.mesh.remove(this.labelObject);
  this.labelObject = null;
  var _this = this;
  setTimeout(function(){
    editor.focus();
    editor.blur(function(){
        _this.label(_this.hideLabelEditor());
    });
  }, 50);
};

Node.prototype.renderExamplePlot = function() {
  var svg = d3.select(this.htmlContainer[0])
      .append("svg")
      .attr("width", 400)
      .attr("height", 250);
  var i;
  var data = [];
  for (i = 0; i < 12; i++) {
    data[2*i]   = { "Month": i, "Unit Sales": Math.random() * 30, "Channel": "direct" };
    data[2*i+1] = { "Month": i, "Unit Sales": Math.random() * 30, "Channel": "web"    };
  }

  var myChart = new dimple.chart(svg, data);
  var x = myChart.addCategoryAxis("x", "Month");
  x.addOrderRule("Date");
  myChart.addMeasureAxis("y", "Unit Sales");
  myChart.addSeries("Channel", dimple.plot.bubble);
  myChart.addLegend(180, 10, 360, 20, "right");
  myChart.draw();
};

Node.prototype.hideLabelEditor = function() {
  var editor = this.htmlElements.labelEditor;
  var value = editor[0].value;
  console.log("Entered: " + value);
  editor.off();
  editor.remove();
  this.htmlElements.labelEditor = null;
  return value;
};

module.exports = Node;

});

require.register("node_searcher", function(exports, require, module) {
"use strict";

var $$     = require('./common')
  , config = require('./config')
;


function highlightText(name, highlight) {
  highlight.push({start: name.length, length: 0});

  return _(highlight).foldl(function(acc, el) {
    if(acc.pos < el.start) {
      acc.elems.push(name.substring(acc.pos, el.start));
    }

    var part = name.substring(el.start, el.start+el.length);
    if(part.length > 0) {
      acc.elems.push($("<em/>").text(part));
    }

    acc.pos = el.start + el.length;

    return acc;
  }, {pos: 0, elems: []});
}

function shouldSplit(query) {
  return (query.indexOf('.') > -1 || query.indexOf(' ') > -1);
}

function splitExpression(expr) {
  var prefix, query;
  var idx = Math.max(expr.lastIndexOf('.'), expr.lastIndexOf(' '));
  prefix = expr.substring(0, idx+1);
  query  = expr.substring(idx+1);
  return {prefix: prefix, query: query};
}

function NodeSearcher() {
  this.el = $('<div/>').addClass('node-searcher');
}

NodeSearcher.prototype.init = function() {
  this.prefix = "";
  this.initSearchbox();
  this.setExpression("");
  this.searchbox.focus();
};

NodeSearcher.prototype.initSearchbox = function() {
  var _this = this;

  var firstColumn = $('<div/>').addClass('column').addClass('current').addClass('first-column');
  this.searchrow = $('<div class="item active query"><span class="query-ns"></span><input autofocus="on" type="text" class="query"/></div>');
  firstColumn.items = $('<ul/>');
  firstColumn.itemsDiv = $('<div class="ul-container"/>');
  firstColumn.append(this.searchrow);
  firstColumn.itemsDiv.append(firstColumn.items);
  firstColumn.append(firstColumn.itemsDiv);

  this.searchbox = this.searchrow.find('input.query');
  this.searchns  = this.searchrow.find('span.query-ns');

  this.el.append(firstColumn);
  this.currentColumn = firstColumn;
  this.firstColumn = firstColumn;

  this.updatePrefixWidth();

  firstColumn.itemsDiv.mCustomScrollbar(config.nodeSearcher.scrollbarOptions);

  this.searchbox.on('input', function() {
    _this.onInput();
  });
  this.searchbox.on('blur', function() {
    _this.searchbox.focus();
  });

  this.searchbox.on('keydown', function(ev) {
    switch(ev.keyCode){
      case 9:  /* tab         */ _this.onTab(ev);       break;
      case 27: /* esc         */ _this.onEsc(ev);       break;
      case 8:  /* backspace   */ _this.onBackspace(ev); break;
      case 38: /* arrow-up    */ _this.onKeyUp(ev);     break;
      case 40: /* arrow-down  */ _this.onKeyDown(ev);   break;
      case 37: /* arrow-left  */ _this.onKeyLeft(ev);   break;
      case 39: /* arrow-right */ _this.onKeyRight(ev);  break;
      case 13: /* enter       */ _this.onEnter(ev);     break;
      case 33: /* page-up     */ _this.onKeyPgUp(ev);   break;
      case 34: /* page-down   */ _this.onKeyPgDn(ev);   break;
      case 36: /* home        */ _this.onKeyHome(ev);   break;
      case 35: /* end         */ _this.onKeyEnd(ev);    break;
    }
    ev.stopPropagation();
  });

  this.searchbox.on('keypress', function(ev) { // prevent Haskell handlers
    ev.stopPropagation();
  });

  this.searchbox.on('keyup', function(ev) { // prevent Haskell handlers
    ev.stopPropagation();
  });

  var x, y;
  this.el.on("mousemove", ".column .item", function(ev) {
    if(x !== ev.pageX || y !== ev.pageY) {
      x = ev.pageX;
      y = ev.pageY;
      _this.select($(ev.currentTarget));
    }
  });
  this.el.on("click", ".column ul li.result", function(ev) {
    _this.select($(ev.currentTarget));
    _this.onEnter(ev);
  });
};

NodeSearcher.prototype.expression = function() {
  return this.prefix + this.searchbox.val();
};

NodeSearcher.prototype.setExpression = function(expr) {
  var split = splitExpression(expr);
  this.prefix = split.prefix;
  this.searchbox.val(split.query);
  this.searchns.text(split.prefix);
  this.updatePrefixWidth();
  this.performSearch();
};

NodeSearcher.prototype.appendExpression = function(expr) {
  this.setExpression(this.prefix + expr);
};


NodeSearcher.prototype.performSearch = function() {
  var ev;
  if(this.prefix === "" && this.searchbox.val() === "") {
    this.firstColumn.removeClass('types');
    this.clearResults();
    ev = new CustomEvent('ns_event', {
      detail: {
        action: 'tree',
        expression: ""
      }
    });
    window.dispatchEvent(ev);
  } else {
    this.firstColumn.addClass('types');
    ev = new CustomEvent('ns_event', {
      detail: {
        action: 'query',
        expression: this.expression()
      }
    });
    window.dispatchEvent(ev);
  }

};

NodeSearcher.prototype.returnSearchResult = function(results) {
  this.searchrow.addClass('active');
  this.displaySearchResults(results);
};

NodeSearcher.prototype.currentSelection = function() {
  return this.currentColumn.find('.item.active');
};

NodeSearcher.prototype.select = function(newSelection) {
  if(newSelection.length === 0) return;
  if(this.currentSelection().is(newSelection)) return;

  var inSameColumn = this.currentSelection().parents('.column').is(newSelection.parents('.column'));

  if(!inSameColumn) {
    this.selectColumn(newSelection.parents('.column'));
  }

  this.currentSelection().removeClass('active');
  newSelection.addClass('active');

  newSelection.parents(".column").nextAll().remove();

  if(!this.isSearchboxActive() && newSelection.data('match').type === 'module') {
    this.openColumn();
  }
};

NodeSearcher.prototype.scrollToSelected = function() {
  var currentSelection  = this.currentSelection();

  var selectedBottom = currentSelection.position().top + this.currentColumn.find('.mCSB_container').position().top + this.currentSelection().height();

  if(selectedBottom > this.currentColumn.find(".ul-container").height()) {
    this.currentColumn.find('.ul-container').mCustomScrollbar("scrollTo", currentSelection.position().top - this.currentColumn.find('.ul-container').innerHeight() + 30, {scrollInertia: config.nodeSearcher.scrollAnimationTime});
  }

  var selectedTop = currentSelection.position().top + this.currentColumn.find('.mCSB_container').position().top;
  if(selectedTop < 0) {
    this.currentColumn.find('.ul-container').mCustomScrollbar("scrollTo", Math.max(0, currentSelection.position().top - currentSelection.height()), {scrollInertia: config.nodeSearcher.scrollAnimationTime});
  }
};

NodeSearcher.prototype.isSearchboxActive = function() {
  return this.searchrow.hasClass('active');
};

NodeSearcher.prototype.createNode = function() {
  var ev = new CustomEvent('ns_event', {
    detail: {
      action: 'create',
      expression: this.expression()
    }
  });
  window.dispatchEvent(ev);
  this.destroy();
};

NodeSearcher.prototype.selectColumn = function(column) {
  this.currentColumn.removeClass('current');
  this.currentColumn = column;
  this.currentColumn.addClass('current');
  this.currentColumn.nextAll().find("li").removeClass("active");
  if(this.currentColumn.find("li.active").length === 0) {
    this.currentColumn.find("li:first-child").addClass("active");
  }
};

NodeSearcher.prototype.openColumn = function() {
  var column = $('<div/>').addClass('column');
  column.items = $('<ul/>');
  column.itemsDiv = $('<div class="ul-container"/>');
  column.itemsDiv.append(column.items);
  column.append(column.itemsDiv);

  this.el.append(column);
  column.itemsDiv.mCustomScrollbar(config.nodeSearcher.scrollbarOptions);

  column.data('items', column.items);

  var ev = new CustomEvent('ns_event', {
    detail: {
      action: 'tree',
      expression: this.currentSelection().data('match').fullname
    }
  });
  window.dispatchEvent(ev);
};

NodeSearcher.prototype.updatePrefixWidth = function() {
  this.prefixWidth = 90+this.searchns.width();
  this.firstColumn.find('.ns').css({idth: this.prefixWidth});
};


NodeSearcher.prototype.clearResults = function() {
  this.firstColumn.nextAll().remove();
  this.currentColumn = this.firstColumn;
  this.firstColumn.find('li.result').remove();
  this.searchrow.addClass('active');
};

NodeSearcher.prototype.addResult = function(prefix, name, fullname, highlight, type) {
  var ul = this.firstColumn.find('ul');

  var li = $('<li/>').addClass('result').addClass('item');
  var ns = $("<span/>").addClass('ns').text(prefix).css({minWidth: this.prefixWidth});
  var namespan = $("<span/>").addClass('fname');

  li.data('match', {module: prefix, name: name, fullname: fullname, highlight: highlight, type: type});
  li.addClass(type);

  ul.append(li);
  li.append(ns);
  li.append(namespan);

  _(highlightText(name, highlight).elems).each(function(part){
    namespan.append(part);
  });
};



// -> HS
NodeSearcher.prototype.displaySearchResults = function(results) {
  this.firstColumn.nextAll().remove();
  this.currentColumn = this.firstColumn;
  this.displayResults(results, this.firstColumn.items);
};

// -> HS
NodeSearcher.prototype.displayResults = function(results, ul) {
  var _this = this;
  ul.find('li.result').remove();

  _(results).each(function(item) { // -> inside stays in JS
    var li = $('<li/>').addClass('result').addClass('item');
    var ns = $("<span/>").addClass('ns').text(item.module).css({minWidth: _this.prefixWidth});
    var name = $("<span/>").addClass('fname');

    li.data('match', item);
    li.addClass(item.type);

    ul.append(li);
    li.append(ns);
    li.append(name);

    _(highlightText(item.name, item.highlight).elems).each(function(part){
      name.append(part);
    });
  });
};



NodeSearcher.prototype.addTreeResult = function(prefix, name, fullname, type) {
  var ul = this.el.find('.column:last-child ul');

  var li = $('<li/>').addClass('result').addClass('item');
  var namespan = $("<span/>").addClass('fname').text(name);
  li.append(namespan);

  li.data('match', {module: prefix, name: name, fullname: fullname, type: type});
  li.addClass(type);

  ul.append(li);
};

// input event handlers

NodeSearcher.prototype.onInput = function() {
  var query = this.searchbox.val();
  if(shouldSplit(query)) {
    this.appendExpression(query);
  } else {
    this.performSearch();
  }
};

NodeSearcher.prototype.onBackspace = function(event) {
  var val = this.searchbox.val();
  var expr = this.expression();

  if(val === "") {
    this.setExpression(expr.slice(0, expr.length-1));
    event.preventDefault();
  }

  event.stopPropagation();
};

NodeSearcher.prototype.onEnter = function(ev) {
  var current, data;

  if(this.searchrow.hasClass('active')) {
    this.createNode(this.prefix + this.searchbox.val());
  } else {
    current = this.currentSelection();
    data    = current.data('match');

    if(data.type === 'module') {
      this.appendExpression(data.fullname + ".");
    } else {
      this.appendExpression(data.fullname);
      this.createNode();
    }
  }

  ev.preventDefault();
};

NodeSearcher.prototype.onTab = function(ev) {
  var current, data;
  ev.preventDefault();

  if(!this.searchrow.hasClass('active')) {
    current = this.currentSelection();
  } else {
    current = this.currentColumn.find("li:first-child");
  }

  if(current.length === 0) return;

  data    = current.data('match');

  if(data.type === 'module') {
    this.appendExpression(data.fullname + ".");
  } else {
    this.appendExpression(data.fullname );
  }

};

NodeSearcher.prototype.onEsc = function(ev) {
  // TODO: Close searcher and send 'search-cancelled' event
  ev.preventDefault();
  this.destroy();
};

NodeSearcher.prototype.onKeyDown = function(event) {
  var currentSelection, nextSelection;

  currentSelection  = this.currentSelection();
  nextSelection = currentSelection.next();

  if(this.isSearchboxActive()) {
    nextSelection = this.firstColumn.find('li:first-child');
  }

  if(nextSelection.length > 0) {
    this.select(nextSelection);
    this.scrollToSelected();
  }

  event.preventDefault();
  event.stopPropagation();
};

NodeSearcher.prototype.onKeyUp = function(event) {
  var currentSelection, nextSelection, shouldSelectSearchbox;
  currentSelection  = this.currentSelection();
  nextSelection = currentSelection.prev();

  shouldSelectSearchbox = this.currentColumn.is(this.firstColumn) && nextSelection.length === 0;

  if(shouldSelectSearchbox) {
    nextSelection = this.searchrow;
  }

  if(nextSelection.length > 0) {
    this.select(nextSelection);
    this.scrollToSelected();
  }

  event.preventDefault();
  event.stopPropagation();
};

NodeSearcher.prototype.onKeyLeft = function(event) {
  if(!this.isSearchboxActive()) {
    if(!this.currentColumn.is(this.firstColumn)){
      this.currentColumn.nextAll().remove();
      this.selectColumn(this.currentColumn.prev());
    }
    event.preventDefault();
  }
  event.stopPropagation();
};

NodeSearcher.prototype.onKeyRight = function(event) {
  var next;
  if(!this.isSearchboxActive()) {
    next = this.currentColumn.next();
    if(next.length > 0) {
      this.select(next.find("li:first-child"));
    }
    event.preventDefault();
  }
  event.stopPropagation();
};

NodeSearcher.prototype.onKeyHome = function(ev) {
  if(!this.searchrow.hasClass('active')) {
    this.select(this.currentColumn.find('li:first-child'));
    this.currentColumn.find('.ul-container').mCustomScrollbar("scrollTo", 'top', {scrollInertia: config.nodeSearcher.scrollAnimationTime});
    ev.preventDefault();
  }
};

NodeSearcher.prototype.onKeyEnd = function(ev) {
  if(!this.searchrow.hasClass('active')) {
    this.select(this.currentColumn.find('li:last-child'));
    this.currentColumn.find('.ul-container').mCustomScrollbar("scrollTo", 'bottom', {scrollInertia: config.nodeSearcher.scrollAnimationTime});
    ev.preventDefault();
  }
};

NodeSearcher.prototype.onKeyPgUp = function(ev) {
  var targetScroll = this.currentSelection().position().top - this.currentColumn.find(".ul-container").height();

  if(!this.searchrow.hasClass('active')) {
    var lastVisible = _(this.currentColumn.find('li').get()).find(function(el) { return $(el).position().top >= targetScroll;});
    if(lastVisible) {
      this.select($(lastVisible));
    }
    this.scrollToSelected();
    ev.preventDefault();
  }
};

NodeSearcher.prototype.onKeyPgDn = function(ev) {
  var targetScroll = this.currentSelection().position().top + this.currentColumn.find(".ul-container").height();

  if(!this.searchrow.hasClass('active')) {
    var lastVisible = _(this.currentColumn.find('li').get().reverse()).find(function(el) { return $(el).position().top + $(el).height() <= targetScroll;});
    if(lastVisible) {
      this.select($(lastVisible));
    }
    this.scrollToSelected();
    ev.preventDefault();
  }
};

NodeSearcher.prototype.destroy = function() {
  this.el.remove();
  $$.node_searcher = undefined;
};

module.exports = NodeSearcher;

});

require.register("port", function(exports, require, module) {
"use strict";

var $$ = require('common');
var vs = require('shaders/port.vert')();
var fs = require('shaders/port.frag')();

var nodeRadius    = 30.0;

// var inputColor  = new THREE.Vector4(0xFF, 0x99, 0x33, 0xAA).divideScalar(0xFF);
var inputColor   = new THREE.Vector4(0x00, 0x99, 0x99, 0xAA).divideScalar(0xFF);
var outputColor  = new THREE.Vector4(0xBB, 0x33, 0x00, 0xAA).divideScalar(0xFF);
var colorFar     = new THREE.Vector4(0.2, 0.2, 0.2, 0.6);

var height = 30.0;
var width  = 30.0;
var halfWidth = width / 2.0;
var margin = 0.0;
var dist = nodeRadius + halfWidth + margin;

var nodeSize = 30.0;

function Port(id, widgetId, angle, out) {
  var _this = this;
  this.id = id;
  this.out = out;

  var color    = out ? outputColor : inputColor;

  this.uniforms = {
    color:     { type: 'v4', value: color    },
    colorFar:  { type: 'v4', value: colorFar },
    mouseDist: { type: 'f',  value: 100000.0 },
    nodeSize:  { type: 'f',  value: nodeSize },
    portSize:  { type: 'f',  value: height   },
    objectId:  { type: 'v3', value: new THREE.Vector3((widgetId % 256) / 255.0, Math.floor(Math.floor(widgetId % 65536) / 256) / 255.0, Math.floor(widgetId / 65536) / 255.0) }
  };

  Object.keys($$.commonUniforms).forEach(function(k) {
    _this.uniforms[k] = $$.commonUniforms[k];
  });

  this.mesh = new THREE.Mesh(
      new THREE.PlaneBufferGeometry(width, height),
			new THREE.ShaderMaterial( {
        uniforms:       this.uniforms,
				vertexShader:   vs,
				fragmentShader: fs,
				transparent:    true,
				blending:       THREE.NormalBlending,
        side:           THREE.DoubleSide
  	})
	);

  this.mesh.position.z = 0;
  this.setAngle(angle);
}

Port.prototype.setAngle = function(angle) {
  this.angle = angle;

  this.mesh.position.x = Math.cos(angle) * dist;
  this.mesh.position.y = Math.sin(angle) * dist;

  this.mesh.rotation.z = angle;
};

Port.prototype.setExpandedPosition = function(left, top) {
  this.mesh.rotation.z = 0;
  this.mesh.position.x = left;
  this.mesh.position.y = top;
}

Port.prototype.setColor = function(color) {
  this.uniforms.color.value = color;
};

Port.prototype.updateMouseDist = function(mouseDist) {
  this.uniforms.mouseDist.value = mouseDist;
};

module.exports = Port;

});

require.register("raycaster", function(exports, require, module) {
"use strict";

var $$           = require('common');

function renderMap() {
  $$.commonUniforms.objectMap.value = 1;
  $$.commonUniforms.antialias.value = 0;
  $$.rendererMap.clear();
  $$.rendererMap.render($$.scene, $$.camera);
  $$.rendererMap.clearDepth();
  $$.rendererMap.render($$.sceneHUD, $$.cameraHUD);
}

function getMapPixelAt(x, y) {
  var buf = new Uint8Array(4);
  y = $$.rendererMap.domElement.height - y;
  $$.rendererMapCtx.readPixels(x, y, 1, 1, $$.rendererMapCtx.RGBA, $$.rendererMapCtx.UNSIGNED_BYTE, buf);
  return buf;
}

var cachedMap = null;
var cachedWidth = 0;
var cachedHeight = 0;

function cacheMap() {
  var width  = $$.rendererMap.domElement.width,
      height = $$.rendererMap.domElement.height;
  cachedWidth  = width;
  cachedHeight = height;
  cachedMap = new Uint8Array(4 * width * height);
  $$.rendererMapCtx.readPixels(0, 0, width, height, $$.rendererMapCtx.RGBA, $$.rendererMapCtx.UNSIGNED_BYTE, cachedMap);
}

function getMapPixelAtCached(x, y) {
  var offset = 4 * (cachedWidth * (cachedHeight - y) + x);
  return [ cachedMap[offset + 0]
         , cachedMap[offset + 1]
         , cachedMap[offset + 2]
         , cachedMap[offset + 3]
         ];
}

function getTopParent(w) {
  var p = w;
  while (p !== undefined) {
    w = p;
    p = w.parent;
  }
  return w;
}

function isWorkspace(id) {
  var widget = $$.registry[id];
  if (widget) {
    return (getTopParent(widget.mesh) !== $$.sceneHUD);
  } else {
    return false;
  }
}

function widgetMatrix(id) {
  var widget = $$.registry[id];
  var m = new THREE.Matrix4();
  if (widget) {
    m.getInverse(widget.mesh.matrixWorld);
    return m.elements;
  } else {
    return null;
  }
}

module.exports = {
  renderMap:     renderMap,
  cacheMap: cacheMap,
  getMapPixelAt: getMapPixelAt,
  getMapPixelAtCached: getMapPixelAtCached,
  widgetMatrix:  widgetMatrix,
  isWorkspace:   isWorkspace
};

});

require.register("selection_box", function(exports, require, module) {
"use strict";

var $$ = require('common');
var vs = require('shaders/select.vert')();
var fs = require('shaders/select.frag')();

var color = new THREE.Vector4(0.85, 0.55, 0.1, 0.2);

function SelectionBox() {
  var _this = this;
  var geometry = new THREE.PlaneBufferGeometry(1,1);

  geometry.applyMatrix( new THREE.Matrix4().makeTranslation(0.5, 0.5, 0.0) );

  this.uniforms = {
    visible: { type: 'f',  value: 0 },
    size:    { type: 'v3', value: new THREE.Vector3(0,0,1) },
    color:   { type: 'v4', value: color }
  };

  Object.keys($$.commonUniforms).forEach(function(k) {
    _this.uniforms[k] = $$.commonUniforms[k];
  });

  this.mesh = new THREE.Mesh(
      geometry,
      new THREE.ShaderMaterial( {
        uniforms:       this.uniforms,
        vertexShader:   vs,
        fragmentShader: fs,
        transparent:    true,
        blending:       THREE.NormalBlending,
        side:           THREE.DoubleSide
    })
  );
  this.mesh.position.z = 1;
}

SelectionBox.prototype.setPos = function(x0, y0, x1, y1) {
  this.mesh.position.x = x0;
  this.mesh.position.y = y0;
  this.mesh.material.uniforms.size.value.x = x1 - x0;
  this.mesh.material.uniforms.size.value.y = y1 - y0;
};

SelectionBox.prototype.show = function() {
  this.mesh.material.uniforms.visible.value = 1;
};

SelectionBox.prototype.hide = function() {
  this.mesh.material.uniforms.visible.value = 0;
};

module.exports = SelectionBox;

});

require.register("text_editor", function(exports, require, module) {
"use strict";

var $$        = require('common');

var editor;

function init() {
  $$.editorContainer = $('<div id="editorContainer"/>');
  $('body').append($$.editorContainer);
  var editorDiv = $('<div id="editor"/>')
  $$.editorContainer.append(editorDiv);
  editor = ace.edit("editor");
  editor.setTheme("ace/theme/twilight");
  editor.getSession().setMode("ace/mode/ruby");
  $$.editor = editor;
  editor.setReadOnly(true);

  var noPropagate = function(ev) { ev.stopPropagation(); };
  $$.editorContainer.on('keydown',   noPropagate);
  $$.editorContainer.on('keyup',     noPropagate);
  $$.editorContainer.on('keypress',  noPropagate);
  $$.editorContainer.on('mousedown', noPropagate);
  $$.editorContainer.on('mouseup',   noPropagate);
  $$.editorContainer.on('mousemove', noPropagate);
  $$.editorContainer.on('click',     noPropagate);
  $$.editorContainer.on('dblclick',  noPropagate);
};

function setText(text) {
  editor.setValue(text);
}

module.exports = {
  init: init,
  setText: setText
}

});

;require.register("triangle_port", function(exports, require, module) {
"use strict";

var $$ = require('common');
var vs = require('shaders/triangle_port.vert')();
var fs = require('shaders/triangle_port.frag')();

var inputColor   = new THREE.Vector4(0x00, 0x99, 0x99, 0xAA).divideScalar(0xFF);
var outputColor  = new THREE.Vector4(0xBB, 0x33, 0x00, 0xAA).divideScalar(0xFF);
var colorFar     = new THREE.Vector4(0.2, 0.2, 0.2, 0.6);

var dist = require('geometries/port').dist;

function Port(id, angle, out) {
  var _this = this;
  this.id = id;
  this.out = out;

  var portGeom = out ? require('geometries/port').out  : require('geometries/port').in;
  var color    = out ? outputColor : inputColor;

  this.uniforms = {
    color:     { type: 'v4', value: color },
    colorFar:  { type: 'v4', value: colorFar },
    mouseDist: { type: 'f',  value: 100000.0 }
  };

  Object.keys($$.commonUniforms).forEach(function(k) {
    _this.uniforms[k] = $$.commonUniforms[k];
  });

  this.mesh = new THREE.Mesh(
			portGeom,
      new THREE.ShaderMaterial( {
        uniforms:       this.uniforms,
        vertexShader:   vs,
        attributes:     ['posL', 'posR', 'posB'],
        fragmentShader: fs,
        transparent:    true,
        blending:       THREE.NormalBlending,
        side:           THREE.DoubleSide
      })
	);

  this.mesh.position.z = 0;
  this.setAngle(angle);
}

Port.prototype.setAngle = function(angle) {
  this.angle = angle;

  this.mesh.position.x = Math.cos(angle) * dist;
  this.mesh.position.y = Math.sin(angle) * dist;

  this.mesh.rotation.z = angle;
};

Port.prototype.setColor = function(color) {
  this.uniforms.color.value = color;
};

Port.prototype.updateMouseDist = function(mouseDist) {
  this.uniforms.mouseDist.value = mouseDist;
};

module.exports = Port;

});

require.register("websocket", function(exports, require, module) {
"use strict";

var removeFromArray = function (array, elt) {
  var index = array.indexOf(elt);
  array.splice(index, 1);
};

var mockSocket = function () {
  var listeners = [];

  return {
    addEventListener: function (type, lst) {
      if (type === "message")
        listeners.push(lst);
    },
    removeEventListener: function (type, lst) {
      if (type === "message")
        removeFromArray(listeners, lst);
    },
    send: function (data) {
      var decoded = atob(data);
      var replaced = decoded.replace("request", "fakeres");
      var fakeResponse = { data: btoa(replaced) };
      listeners.forEach(function (listener) {
        listener.call(null, fakeResponse);
      });
    }
  };
};

module.exports = function () {
  var connection = mockSocket();

  var listeners = {
    onOpen: [],
    onMessage: []
  };

  var attachListeners = function () {
    listeners.onOpen.forEach(function (listener) {
      connection.addEventListener("open", listener);
    });
    listeners.onMessage.forEach(function (listener) {
      connection.addEventListener("message", listener);
    });
  };

  return {
    onOpen: function (listener) {
      listeners.onOpen.push(listener);
      connection.addEventListener("open", listener);
    },
    unOnOpen: function (listener) {
      removeFromArray(listeners.onOpen, listener);
      connection.removeEventListener("open", listener);
    },
    onMessage: function (listener) {
      listeners.onMessage.push(listener);
      connection.addEventListener("message", listener);
    },
    unOnMessage: function (listener) {
      removeFromArray(listeners.onMessage, listener);
      connection.removeEventListener("message", listener);
    },
    connect: function (addr) {
      connection = new WebSocket(addr);
      attachListeners();
    },
    send: function (data) {
      connection.send(data);
    }
  };
};

});

require.register("shaders/button.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nuniform vec2 size;\nuniform int state;\nuniform int objectMap;\nuniform vec3 objectId;\n\nvoid main() {\n    if (objectMap == 0) {\n        vec3 borderColor;\n        if (state == 0) {\n            borderColor = vec3(1.0, 0.0, 0.0);\n        } else if (state == 1) {\n            borderColor = vec3(1.0, 1.0, 0.3);\n        } else if (state == 2) {\n            borderColor = vec3(0.3, 0.5, 0.3);\n        } else if (state == 3) {\n            borderColor = vec3(0.3, 0.3, 0.5);\n        }\n\n        vec2 p = vec2(pos.x * size.x, pos.y * size.y);\n\n        if(p.x < 3.0 || p.x > size.x - 3.0 || p.y < 3.0 || p.y > size.y - 3.0) {\n            gl_FragColor = vec4(borderColor, 1.0);\n        } else {\n            gl_FragColor = vec4(0.3*borderColor, 1.0);\n        }\n    } else {\n        gl_FragColor = vec4(objectId, 1.0);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/button.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\n\nvoid main() {\n    pos = uv;\n\tgl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/color.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nuniform vec4 color;\nuniform float visible;\nuniform int objectMap;\nuniform vec3 objectId;\n\nvoid main() {\n    if (visible < 1.0) discard;\n    if (objectMap == 0) {\n        gl_FragColor = color;\n    } else {\n        gl_FragColor = vec4(objectId, 1.0);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/common.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvoid main() {\n\tgl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/connection.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying float distance;\nvarying float distanceV;\n\nuniform vec4 color;\nuniform float visible;\nuniform float camFactor;\nuniform float len;\nuniform int connecting;\n\nuniform int antialias;\n\nuniform int objectMap;\nuniform vec3 objectId;\n\nvoid main() {\n    if (visible < 1.0) discard;\n    if (objectMap == 1 && connecting == 1) discard;\n\n    float origAlpha = color.w;\n    vec3  colorShow = color.xyz;\n    float alphaShow = 1.0;\n\n    float d = abs(distance);\n    float v = abs(distanceV);\n\n    float camFactorDelta = camFactor - 1.0;\n    float rimCamFactor  = 1.0;\n    float blurCamFactor = 1.0;\n    if (camFactorDelta > 0.0) {\n      rimCamFactor  += camFactorDelta / 25.0;\n      blurCamFactor += camFactorDelta / 1.0;\n    } else if (camFactorDelta < 0.0) {\n      rimCamFactor  += camFactorDelta / 5.0;\n      blurCamFactor += camFactorDelta / 1.0;\n    }\n\n    float blurRef = 0.25;\n    float  rimRef = 0.18;\n\n    float blurWidth = blurRef / blurCamFactor;\n    float r1 =         rimRef /  rimCamFactor;\n    float r2 = r1 + blurWidth;\n\n    float alpha  = 1.0;\n    float alphaV = 1.0;\n\n    if (d < r1) {\n        alpha = 1.0;\n    } else if (d < r2 && antialias != 0) {\n        alpha = (r2 - d) / blurWidth;\n        // colorShow = vec3(alpha, 0.0, 0.0); alpha = 1.0; // for test\n    } else {\n        alpha = 0.0;\n        // colorShow = vec3(0.0, 1.0, 0.0); alpha = 1.0; // for test\n    }\n\n    if (antialias != 0) {\n        float sideWidth = 150.0 * blurWidth;\n        float vr = rimRef /  rimCamFactor;\n        float vm = len * (1.0 - v) / sideWidth;\n\n        if (vm <= vr) {\n            float mod = (vr - vm) / vr;\n            alphaV = 1.0 - mod * mod;\n            // colorShow = vec3(alphaV, 0.0, 0.0); alphaV = 1.0; // for test\n        }\n    }\n    alphaShow = alpha * alphaV;\n    if (objectMap == 1) {\n        gl_FragColor = vec4(objectId, 1.0);\n    } else  {\n        gl_FragColor = vec4(colorShow, alphaShow * origAlpha);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/connection.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying float distance;\nvarying float distanceV;\n\nvoid main() {\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n    distance  = uv.y * 2.0 - 1.0;\n    distanceV = uv.x * 2.0 - 1.0;\n}\n';
}
return __p;
};
});

require.register("shaders/expandedNode.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2  pos;\n\nuniform float camFactor;\nuniform vec2  nodeSize;\n\nuniform vec3  expandedColor;\n\nuniform float radiusTop;\nuniform float radiusBottom;\n\nuniform int   antialias;\nuniform int   objectMap;\nuniform vec3  objectId;\n\nvoid main() {\n    vec2  posN         = pos * nodeSize;\n    float dist_squared = dot(posN, posN);\n\n    float r            = min(min(posN.x, posN.y), min(nodeSize.x - posN.x, nodeSize.y - posN.y));\n\n    vec2 posE;\n    if(posN.x < radiusTop && posN.y < radiusTop) { // TOP LEFT\n        posE = posN + vec2(-radiusTop , -radiusTop);\n        r    = radiusTop - sqrt(dot(posE, posE));\n    } else if(posN.x < radiusBottom && posN.y > nodeSize.y - radiusBottom) { // BOTTOM LEFT\n        posE = posN + vec2(-radiusBottom, -nodeSize.y + radiusBottom);\n        r    = radiusBottom - sqrt(dot(posE, posE));\n    } else if(posN.x > nodeSize.x - radiusTop && posN.y < radiusTop) { // TOP RIGHT\n        posE = posN + vec2(-nodeSize.x + radiusTop, - radiusTop);\n        r    = radiusTop - sqrt(dot(posE, posE));\n    } else if(posN.x > nodeSize.x - radiusBottom && posN.y > nodeSize.y - radiusBottom) { // BOTTOM RIGHT\n        posE = posN + vec2(-nodeSize.x + radiusBottom, -nodeSize.y + radiusBottom);\n        r    = radiusBottom - sqrt(dot(posE, posE));\n    }\n\n    float blurCamFactor  = 1.0;\n    float camFactorDelta = camFactor - 1.0;\n\n    if (camFactorDelta > 0.0) {\n        blurCamFactor += camFactorDelta /  1.5;\n    } else if (camFactorDelta < 0.0) {\n        blurCamFactor += camFactorDelta /  1.1;\n    }\n\n\n    float blurWidth  =  1.0;\n    float rimWidth   =  5.0;\n    float r4         =  0.0;\n    float r3         =      blurWidth / blurCamFactor;\n\n    float d_blur_r34 = 1.0;\n\n\n\n    if (antialias != 0) {\n        d_blur_r34 = 1.0 - (r - r3) / (r4 - r3);\n    }\n\n    if (objectMap == 0) {\n        if (r > r4) {\n            gl_FragColor = vec4(expandedColor, 1.0);\n        } else if (r > r3) {\n            gl_FragColor = vec4(expandedColor, d_blur_r34);\n        } else {\n            // colorShow = vec4(0.1, 0.1, 0.0, 1.0);\n            discard;\n        }\n    } else {\n        if (r > r4) {\n            gl_FragColor = vec4(objectId, 1.0);\n        } else {\n            discard;\n        }\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/expandedNode.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nuniform float expanded;\n\nvoid main() {\n    pos = uv;\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/font.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#define SQRT2 1.4142135623730951\n\nuniform float opacity;\nuniform vec3 color;\nuniform sampler2D map;\nuniform float smooth;\nuniform float camFactor;\nvarying float vPage;\nvarying vec2 vUv;\n\nuniform int objectMap;\nuniform vec3 objectId;\n\n\nvoid main() {\n    if (objectMap == 1) discard;\n\n    vec4 texColor = texture2D(map, vUv);\n    float dst = texColor.a;\n    float modFactor = (camFactor - 1.0) * 0.3 + 1.0;\n    float afwidth = smooth/modFactor * SQRT2 / (2.0 * gl_FragCoord.w);\n    float alpha = smoothstep(0.5 - afwidth, 0.5 + afwidth, dst);\n\n    gl_FragColor = vec4(color, opacity * alpha);\n}\n';
}
return __p;
};
});

require.register("shaders/font.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='attribute float page;\nuniform float camFactor;\nuniform float width;\nuniform int zoomScaling;\nvarying vec2 vUv;\nvarying float vPage;\n\nvoid main() {\n    vUv = uv;\n    vPage = page;\n    float modFactor = 1.0;\n    vec3 positionShift = vec3(0.0, 0.0, 0.0);\n\n    if(zoomScaling == 1) {\n      if (camFactor >= 1.0) {\n          modFactor = (camFactor - 1.0) * 0.08 + 1.0;\n      } else {\n          modFactor = (camFactor - 1.0) * 0.9 + 1.0;\n      }\n      float coef = width / 2.0;\n      positionShift = vec3(coef - coef / modFactor, 0.0, 0.0);\n    }\n\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(positionShift + position.xyz / modFactor, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/node.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2  pos;\n\nuniform float camFactor;\nuniform int   selected;\nuniform float mouseDist;\nuniform vec2  nodeSize;\n\nuniform vec3  insideColor;\nuniform vec3  unselectedColor;\nuniform vec3  selectedColor;\nuniform vec3  focusedColor;\n\nuniform float radiusTop;\nuniform float radiusBottom;\n\nuniform int   antialias;\nuniform int   objectMap;\nuniform vec3  objectId;\n\nvoid main() {\n    float bg_gray    = 0.1;\n    vec3  color      = unselectedColor;\n    float brighterBy = 0.7;\n\n    if (selected == 1) {\n        brighterBy = 0.3;\n        color      = selectedColor;\n    } else if (selected == 2) {\n        brighterBy = 0.2;\n        color      = focusedColor;\n    }\n\n    float distMix    =  0.0;\n    float gradRange  = 60.0;\n    float colorRange = 27.0;\n\n    if (mouseDist < colorRange) {\n        distMix = 1.0;\n    } else if (mouseDist < gradRange) {\n        float coef  = (mouseDist - colorRange) / (gradRange - colorRange);\n        float coefR = 1.0 - coef;\n        distMix = coefR * coefR * coefR;\n    }\n    color *= 1.0 + distMix * brighterBy;\n\n    vec4 colorShow = vec4(color, 1.0);\n\n    // node geometry starts here\n\n    float camFactorDelta = camFactor - 1.0;\n    float rimCamFactor   = 1.0;\n    float blurCamFactor  = 1.0;\n\n    if (camFactorDelta > 0.0) {\n        rimCamFactor  += camFactorDelta / 50.0;\n        blurCamFactor += camFactorDelta /  1.5;\n    } else if (camFactorDelta < 0.0) {\n        rimCamFactor  += camFactorDelta / 10.0;\n        blurCamFactor += camFactorDelta /  1.1;\n    }\n\n    vec2  posN         = pos * nodeSize;\n    float dist_squared = dot(posN, posN);\n\n    float r            = min(min(posN.x, posN.y), min(nodeSize.x - posN.x, nodeSize.y - posN.y));\n\n    vec2 posE;\n    if(posN.x < radiusTop && posN.y < radiusTop) { // TOP LEFT\n        posE = posN + vec2(-radiusTop , -radiusTop);\n        r    = radiusTop - sqrt(dot(posE, posE));\n    } else if(posN.x < radiusBottom && posN.y > nodeSize.y - radiusBottom) { // BOTTOM LEFT\n        posE = posN + vec2(-radiusBottom, -nodeSize.y + radiusBottom);\n        r    = radiusBottom - sqrt(dot(posE, posE));\n    } else if(posN.x > nodeSize.x - radiusTop && posN.y < radiusTop) { // TOP RIGHT\n        posE = posN + vec2(-nodeSize.x + radiusTop, - radiusTop);\n        r    = radiusTop - sqrt(dot(posE, posE));\n    } else if(posN.x > nodeSize.x - radiusBottom && posN.y > nodeSize.y - radiusBottom) { // BOTTOM RIGHT\n        posE = posN + vec2(-nodeSize.x + radiusBottom, -nodeSize.y + radiusBottom);\n        r    = radiusBottom - sqrt(dot(posE, posE));\n    }\n\n    float blurWidth  =  1.0;\n    float rimWidth   =  5.0;\n    float r4         =  0.0;\n    float r3         =      blurWidth / blurCamFactor;\n    float r2         = r3 +  rimWidth /  rimCamFactor;\n    float r1         = r2 + blurWidth / blurCamFactor;\n\n    float d_blur_r34 = 1.0;\n    float d_blur_r12 = 0.0;\n\n\n\n    if (antialias != 0) {\n        d_blur_r34 = 1.0 - (r - r3) / (r4 - r3);\n        d_blur_r12 =       (r - r1) / (r2 - r1);\n    }\n\n    if (objectMap == 0) {\n        if (r > r1) {\n            colorShow = vec4(insideColor, 1.0);\n        } else if (r > r2) {\n            vec3 mix = insideColor * (1.0 - d_blur_r12) + color * d_blur_r12;\n            colorShow = vec4(mix, 1.0);\n        } else if (r > r3) {\n            colorShow = vec4(color, 1.0);\n        } else if (r > r4) {\n            colorShow = vec4(color, d_blur_r34);\n        } else {\n            // colorShow = vec4(0.1, 0.1, 0.0, 1.0);\n            discard;\n        }\n    } else {\n        if (r > r4) {\n            colorShow = vec4(objectId, 1.0);\n        } else {\n            discard;\n        }\n    }\n\n    gl_FragColor = colorShow;\n}\n';
}
return __p;
};
});

require.register("shaders/node.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nuniform float expanded;\n\nvoid main() {\n    pos = uv;\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/port.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nvarying vec2 posUV;\n\nuniform float camFactor;\nuniform float mouseDist;\nuniform float nodeSize;\nuniform float portSize;\n\nuniform vec4 colorFar;\nuniform vec4 color;\n\nuniform int antialias;\n\nuniform int objectMap;\nuniform vec3 objectId;\n\n\nvoid main() {\n\n    if (objectMap == 1) {\n        gl_FragColor = vec4(objectId, 1.0);\n        return;\n    }\n\n    float coef = nodeSize / portSize;\n    vec2 posS = pos;\n    vec2 posN = vec2(posS.x * portSize + nodeSize, posS.y * portSize / 2.0);\n    float dist_squared = dot(posN, posN);\n\n    float alpha = 1.0;\n    alpha *= min(1.0, 1.0 - pow(posUV.y, 60.0));\n\n    float gradRange  = 300.0;\n    float colorRange =  60.0;\n    vec4  colorShow  = colorFar;\n    if (mouseDist < colorRange) {\n        colorShow = color;\n    } else if (mouseDist < gradRange) {\n        float coef = (mouseDist - colorRange) / (gradRange - colorRange);\n        float coefR = 1.0 - coef;\n        float distMix = coefR * coefR * coefR;\n        colorShow = distMix * color + (1.0 - distMix) * colorFar;\n    }\n\n    float camFactorDelta = camFactor - 1.0;\n    float rimCamFactor  = 1.0;\n    float blurCamFactor = 1.0;\n    if (camFactorDelta > 0.0) {\n        rimCamFactor  += camFactorDelta / 50.0;\n        blurCamFactor += camFactorDelta / 1.5;\n    } else if (camFactorDelta < 0.0) {\n        rimCamFactor  += camFactorDelta / 10.0;\n        blurCamFactor += camFactorDelta / 1.1;\n    }\n    float blurWidth = 60.0;\n    float rimWidth = 240.0;\n    float size = nodeSize + rimWidth / 48.0;\n    float r4 = dot(size, size);\n    float r3 = r4 - blurWidth / blurCamFactor;\n    float r2 = r3 -  rimWidth /  rimCamFactor;\n    float r1 = r2 - blurWidth / blurCamFactor;\n\n    float d_blur_r34 = 1.0;\n    float d_blur_r12 = 0.0;\n    if (antialias != 0) {\n        d_blur_r34 = 1.0 - (dist_squared - r3) / (r4 - r3);\n        d_blur_r12 = (dist_squared - r1) / (r2 - r1);\n    }\n\n    if (dist_squared < r1) {\n        discard;\n        // alpha *= 0.2;\n    } else if (dist_squared < r2) {\n        alpha *= d_blur_r12;\n    } else if (dist_squared < r3) {\n    } else if (dist_squared < r4) {\n        alpha *= d_blur_r34;\n    } else {\n        discard;\n        // alpha *= 0.2;\n    }\n\n    float disappearE = 0.5;\n    float disappearS = 0.9;\n    if (camFactor < disappearE) {\n        alpha = 0.0;\n    } else if (camFactor < disappearS) {\n       float disappearW = disappearS - disappearE;\n       alpha *= 1.0 - (disappearS - camFactor) / disappearW;\n    }\n\n\n    gl_FragColor = vec4(colorShow.xyz, alpha * colorShow.w);;\n}\n';
}
return __p;
};
});

require.register("shaders/port.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nvarying vec2 posUV;\n\nvoid main() {\n    pos   = vec2(uv.x, uv.y * 2.0 - 1.0);\n    posUV = pos;\n    vec2 posM = vec2(position.x, position.y);\n    if (position.x < 0.0) {\n        pos  = vec2(pos.x,  pos.y  / sqrt(4.0));\n        posM = vec2(posM.x, posM.y / sqrt(4.0));\n    }\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(posM, 0.0, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/select.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nuniform vec4 color;\nuniform float visible;\nuniform float camFactor;\nuniform vec3 size;\n\nvarying vec2 distance;\n\nuniform int antialias;\n\nuniform int objectMap;\n\n\nvoid main() {\n    if (visible < 1.0) discard;\n    if (objectMap == 1) discard;\n\n    float width = 6.0;\n    float alpha = 1.0;\n\n    if (antialias != 0) {\n        float dx = 1.0 - abs(distance.x);\n        float dy = 1.0 - abs(distance.y);\n\n        float factor = camFactor / width;\n        float factorX = factor * abs(size.x);\n        float factorY = factor * abs(size.y);\n\n        float alphaX = min(1.0, factorX * dx);\n        float alphaY = min(1.0, factorY * dy);\n\n\n        float coef = 1.0;\n        float idx = 1.0 - min(1.0, abs(distance.x * coef));\n        float idy = 1.0 - min(1.0, abs(distance.y * coef));\n\n        float ifactor = camFactor / (width * 2.0);\n        float ifactorX = ifactor * abs(size.x * coef);\n        float ifactorY = ifactor * abs(size.y * coef);\n\n        float diffRatio = 0.8;\n        float ialphaX = min(diffRatio, ifactorX * idx);\n        float ialphaY = min(diffRatio, ifactorY * idy);\n\n        float ialpha = 1.0 - (ialphaX * ialphaY);\n        alpha = min(alphaX * alphaY, ialpha);\n    }\n\n    gl_FragColor = vec4(color.xyz, color.w * alpha);\n}\n';
}
return __p;
};
});

require.register("shaders/select.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nuniform vec3 size;\nvarying vec2 distance;\n\nvoid main() {\n\tgl_Position = projectionMatrix * modelViewMatrix * (vec4(position * size, 1.0));\n    distance = uv * 2.0 - vec2(1.0, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/slider.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nuniform vec2 size;\nuniform float value;\nuniform int focus;\nuniform int objectMap;\nuniform vec3 objectId;\n\nvoid main() {\n\n    vec3 background   = vec3(0.18, 0.18, 0.18);\n    vec3 foreground   = vec3(0.25, 0.25, 0.25);\n    vec3 slider       = vec3(0.58, 0.21, 0.05);\n    vec3 sliderFocus  = vec3(0.73, 0.26, 0.07);\n\n    if (objectMap == 0) {\n        vec2 p = vec2(pos.x * size.x, pos.y * size.y);\n\n        float r = size.y / 2.0;\n        if (p.x < r) {\n            vec2 vec = vec2(r - p.x, r - p.y);\n            if (dot(vec, vec) > r * r) discard;\n        }\n\n        if (p.x > size.x - r) {\n            vec2 vec = vec2(size.x - r - p.x, r - p.y);\n            if (dot(vec, vec) > r * r) discard;\n        }\n\n        float val = size.x * value;\n        if (p.x >= val) {\n            gl_FragColor = vec4(background, 1.0);\n        } else if (p.x < val) {\n            gl_FragColor = vec4(foreground, 1.0);\n        }\n    } else {\n        gl_FragColor = vec4(objectId, 1.0);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/slider.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\n\nvoid main() {\n    pos = uv;\n\tgl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/toggle.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\nuniform vec2 size;\nuniform int value;\nuniform int objectMap;\nuniform vec3 objectId;\n\nvoid main() {\n\n    float sliderWidth = 2.0;\n    vec3 background   = vec3(0.15, 0.15, 0.15);\n    vec3 foreground   = vec3(0.25, 0.25, 0.25);\n    vec3 slider       = vec3(0.58, 0.21, 0.05);\n    vec3 sliderFocus  = vec3(0.73, 0.26, 0.07);\n\n\n    if (objectMap == 0) {\n        vec2 p = vec2(pos.x * size.x, pos.y * size.y);\n        float     margin = size.y * 0.1;\n        float  leftBound = 0.7 * size.x - margin;\n        float rightBound = 1.0 * size.x - margin;\n        float     center = (leftBound + rightBound) / 2.0;\n\n        if        (pos.y > 0.2 && pos.y < 0.8 && p.x > (leftBound + margin) && p.x < (rightBound - margin)) {\n            if(p.x > center){\n                gl_FragColor = vec4(value == 1 ? slider : foreground, 1.0);\n            } else {\n                gl_FragColor = vec4(value == 0 ? slider : foreground, 1.0);\n            }\n        } else if (pos.y > 0.1 && pos.y < 0.9 && p.x > leftBound && p.x < rightBound) {\n            gl_FragColor = vec4(foreground, 1.0);\n        } else {\n            gl_FragColor = vec4(background, 1.0);\n        }\n    } else {\n        gl_FragColor = vec4(objectId, 1.0);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/toggle.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec2 pos;\n\nvoid main() {\n    pos = uv;\n\tgl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n}\n';
}
return __p;
};
});

require.register("shaders/triangle_port.frag", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nvarying vec3 distanceL;\nvarying vec3 distanceR;\nvarying vec3 distanceB;\n\nuniform vec4 color;\nuniform vec4 colorFar;\nuniform float visible;\nuniform float camFactor;\nuniform float mouseDist;\n\nuniform int antialias;\n\nuniform int objectMap;\nuniform vec3 objectId;\n\n\nvoid main() {\n    float alpha = 1.0;\n    float disappearE = 0.5;\n    float disappearS = 0.9;\n\n    if (camFactor < disappearE) {\n        alpha = 0.0;\n    } else {\n        if (antialias != 0) {\n            float factor = camFactor * 6.0;\n            float alphaL = min(1.0, factor * distanceL.x);\n            float alphaR = min(1.0, factor * distanceR.x);\n            float alphaB = min(1.0, factor * distanceB.x);\n            alpha = alphaL * alphaR * alphaB;\n        }\n        if (camFactor < disappearS) {\n           float disappearW = disappearS - disappearE;\n           alpha = alpha * (1.0 - (disappearS - camFactor) / disappearW);\n        }\n    }\n\n    float gradRange  = 300.0;\n    float colorRange =  60.0;\n    vec4  colorShow  = colorFar;\n    if (mouseDist < colorRange) {\n        colorShow = color;\n    } else if (mouseDist < gradRange) {\n        float coef = (mouseDist - colorRange) / (gradRange - colorRange);\n        float coefR = 1.0 - coef;\n        float distMix = coefR * coefR * coefR;\n        colorShow = distMix * color + (1.0 - distMix) * colorFar;\n    }\n\n    if (objectMap == 0) {\n        gl_FragColor = vec4(colorShow.xyz, alpha * colorShow.w);\n    } else {\n        gl_FragColor = vec4(objectId, 1.0);\n    }\n}\n';
}
return __p;
};
});

require.register("shaders/triangle_port.vert", function(exports, require, module) {
module.exports = function(obj){
var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
with(obj||{}){
__p+='#ifdef GL_ES\nprecision highp float;\n#endif\n\nattribute vec3 posL;\nattribute vec3 posR;\nattribute vec3 posB;\nvarying vec3 distanceL;\nvarying vec3 distanceR;\nvarying vec3 distanceB;\n\nvoid main() {\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n    distanceL = posL;\n    distanceR = posR;\n    distanceB = posB;\n}\n';
}
return __p;
};
});


//# sourceMappingURL=app.js.map